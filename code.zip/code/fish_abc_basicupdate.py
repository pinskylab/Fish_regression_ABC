 # this script simulates stage-structured population sizes in space and time for given parameters and forcin
# functions
from __future__ import print_function, division
import sys

# NB for EAM: this runs on Mushu in pipenv, so call pipenv run python fish_abc.py

# import dependencies
import numpy as np
import random as random
import math as math
import copy as copy
import itertools
import statsmodels.api as sm
from sklearn import preprocessing
#from numpy.linalg import inv

def compute_weight(t, eps):
    if t <= eps:
        return (1. - (t / eps)**2)/eps
    else:
        return 0.


def beta_defs(alpha,mu):
    """ Takes in an alpha shape parameter and the desired mean and returns a value from the beta
    distribution"""
    beta = alpha/mu - alpha
    val = np.random.beta(alpha, beta)
    return val


def temp_dependence(temperature, T0, theta_0, width):
    """ Takes in a temperature and the location of the parabolic vertex (T0, theta_0) and the width of
    the parabola and returns the associated temperature dependent rate (theta)
    """
    theta = -width*(temperature-T0)*(temperature-T0) + theta_0
    if theta < 0:
        theta = 0

    return theta


def pop_dynamics(N_B, N_J, N_A, params, alpha, alph):
    """ Intakes the numeric population sizes for the three population sizes and a dict structure
    for the parameter values; alpha, fecundity is input separately
    """
    recruits = beta_defs(alph,params["g_B"])
    gJval = beta_defs(alph,params["g_J"])
    nJ_coef = (1 - gJval - beta_defs(alph,params["m_J"]))

    nextN_B = np.random.poisson(alpha)*N_A - recruits*N_B
    nextN_J = recruits*N_B + N_J*nJ_coef
    nextN_A = gJval*N_J + (1 - beta_defs(alph,params["m_A"]))*N_A

    return nextN_B, nextN_J, nextN_A

def movement(pop1, pop2, f_s):
    """ Takes population sizes in two patches, in which a fraction, f_s, of each stays and outputs
    the population sizes in each patch after movement """
    next_pop1 = f_s*(pop1) + (1-f_s)*pop2
    next_pop2 = f_s*(pop2) + (1-f_s)*pop1

    return next_pop1, next_pop2


def simulation_population(N_B0, N_J0, N_A0, params, T_FINAL, temperatures):
    """ Takes in the initial population sizes and simulates the population size moving forward """
    # Set starting numbers for population and allocate space for population sizes
    N_B = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_B[0] = N_B0
    N_J = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_J[0] = N_J0
    N_A = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_A[0] = N_A0

    for t in range(0,T_FINAL):
        alpha1 = temp_dependence(temperatures[t], params["T0"], params["alpha0"], params["width"])
        alpha2 = temp_dependence(temperatures[t] + params["delta_t"], params["T0"], params["alpha0"], params["width"])

        N_B[t+1][0], N_J[t+1][0], N_A1 = pop_dynamics(N_B[t][0], N_J[t][0], N_A[t][0], params, alpha1, 2)
        N_B[t+1][1], N_J[t+1][1], N_A2 = pop_dynamics(N_B[t][1], N_J[t][1], N_A[t][1], params, alpha2, 2)

        N_A[t+1][0], N_A[t+1][1] = movement(N_A1,N_A2, params["f_s"])

    return N_B, N_J, N_A


def calculate_summary_stats(N_B, N_J, N_A):
    """Takes in a matrix of time x place population sizes for each stage and calculates summary statistics"""
    total_adult = N_A.sum(axis=1) # total population in each stage, summed over space
    total_juv   = N_J.sum(axis=1)
    total_larv  = N_B.sum(axis=1)

    #print('total_adult:', total_adult)
    #print('N_A:', N_A)

    total_population = total_adult + total_juv + total_larv # total population size in each time
    proportion_adult = total_adult / total_population
    proportion_p_i   = []

    for i in range(0, len(N_B)):
        proportion_p_i.append((N_B[i,0]+N_J[i,0]+N_A[i,0])/total_population[i])

    proportion_p_i = np.asarray(proportion_p_i)
    return total_population, proportion_adult, proportion_p_i


def euclidean_distance(vec1, vec2):
    """ Takes two vectors of the same dimensions and calculates the Euclidean distance between the elements"""
    d = 0
    if len(vec1) != len(vec2):
        print("Error")
        return

    for i in range(0,len(vec1)):
        d = d + (vec1[i] - vec2[i])**2
    distance = d**0.5
    return distance


def small_percent(vector, percent):
    """ Takes a vector and returns the indexes of the elements within the smallest (percent) percent of the vector"""
    sorted_vector = sorted(vector)
    cutoff = math.floor(len(vector)*percent/100) # finds the value which (percent) percent are below
    indexes = []
    print('cutoff:',cutoff)
    cutoff = int(cutoff)
    for i in range(0,len(vector)):
        if vector[i] <= sorted_vector[cutoff]: # looks for values below the found cutoff
            indexes.append(i)

    return indexes, sorted_vector[cutoff]


def z_score(x):
    """Takes a list and returns a 0 centered, std = 1 scaled version of the list"""
    st_dev = np.std(x,axis=0)
    mu = np.mean(x,axis=0)
    rescaled_values = []
    for element in rang(0,len(x)):
        rescaled_values[element] = (x[element] - mu) / st_dev

    return rescaled_values


# Sets parameters
PARAMS = {"alpha0": 2, "T0": 0, "width": 1, "g_B": .3, "g_J": .4, "m_J": .05, "m_A": .05, "f_s": .9, "delta_t":.1, "lam":1}
T_FINAL = 10
LANDSCAPE_LEN = 2
N0 = 5
NUMBER_SIMS = 1000

print("True parameter values:", PARAMS["g_J"], PARAMS["g_B"],PARAMS["alpha0"], PARAMS["width"], PARAMS["f_s"], PARAMS["T0"], PARAMS["m_J"], PARAMS["m_A"])

# Sets temperatures at each patch over time [FIX THIS]
temperatures = [0,1,2,3,4,5,6,7,8,9]

# Simulates population
N_B, N_J, N_A = simulation_population(N0, N0, N0, PARAMS, T_FINAL, temperatures)

obs_total_pop, obs_prop_ad, obs_prop_p_i= calculate_summary_stats(N_B, N_J, N_A)

RUN_SIM = True
# Pulls parameters from paramater priors
if RUN_SIM:
    print("True parameter values:", PARAMS["g_J"], PARAMS["g_B"],PARAMS["alpha0"], PARAMS["width"], PARAMS["f_s"], PARAMS["T0"], PARAMS["m_J"], PARAMS["m_A"])
    PARAMS_ABC = copy.deepcopy(PARAMS) # copies parameters so new values can be generated; FIX ME! this is a redirect, not a copy?
    print("True parameter values:", PARAMS["g_J"], PARAMS["g_B"],PARAMS["alpha0"], PARAMS["width"], PARAMS["f_s"], PARAMS["T0"], PARAMS["m_J"], PARAMS["m_A"])
    param_save = [] # sets an initial 0; fixed to [] because [[]] made the mean go poorly (averaging in an [] at start?)
    data_sim = []
    dists = []
    for i in range(0,NUMBER_SIMS):
        g_B_theta = np.random.uniform(0,1,size=None)#np.random.beta(2,2)
        g_J_theta =np.random.uniform(0,1,size=None) #np.random.beta(2,2)
        alpha0_theta =np.random.uniform(0,4,size=None)# np.random.lognormal(1,1)
        width_theta = np.random.uniform(0.1,2,size=None)#np.random.lognormal(1,1)
        f_s_theta =np.random.uniform(0,1,size=None) #np.random.uniform()
        T0_theta =np.random.uniform(0,3,size=None) #np.random.normal(0,0.5)
        m_J_theta =np.random.uniform(0,1,size=None) #np.random.beta(2,2)
        m_A_theta = np.random.uniform(0,1,size=None)#np.random.beta(2,2)

        PARAMS_ABC["g_J"] = g_J_theta # sets the g_J parameter to our random guess
        PARAMS_ABC["alpha0"] = alpha0_theta
        PARAMS_ABC["width"] = width_theta
        PARAMS_ABC["f_s"] = f_s_theta
        PARAMS_ABC["g_G"] = g_B_theta
        PARAMS_ABC["T0"] = T0_theta
        PARAMS_ABC["m_J"] = m_J_theta
        PARAMS_ABC["m_A"] = m_A_theta
        print(PARAMS_ABC["g_G"] )
        sys.exit()
        # Simulate population for new parameters
        N_B_sim, N_J_sim, N_A_sim = simulation_population(N0,N0,N0, PARAMS_ABC, T_FINAL, temperatures) # simulates population with g_J value

        # Calculate the summary statistics for the simulation
        sim_total_pop, sim_prop_ad, sim_prop_p_i = calculate_summary_stats(N_B_sim, N_J_sim, N_A_sim)

        # compute the sum of the summary statistics
        # use euclidean
        #vec1 = np.array([sim_total_pop, sim_prop_ad, sim_prop_p_i])
        #vec1 = sim_total_pop + sim_prop_ad + sim_prop_p_i
        #vec1=sim_total_pop
        # normalize the data attributes. using the default 'l2' normalization,  divides each value by sqrt(x1^2 + x2^2 + x3^2)
        
        vec1=preprocessing.normalize([sim_total_pop + sim_prop_ad + sim_prop_p_i])
        vec2=preprocessing.normalize([obs_total_pop + obs_prop_ad + obs_prop_p_i])
        # standardize the data attributes
        #vec11=preprocessing.scale([sim_total_pop])
        # vector of summary statistics for true simulation
        #vec2 = obs_total_pop + obs_prop_ad + obs_prop_p_i
        #vec2 = np.array([obs_total_pop, obs_prop_ad, obs_prop_p_i])
        #vec2=obs_total_pop
        #ZZ=print((sim_total_pop-min(sim_total_pop))/(max(sim_total_pop)-min(sim_total_pop)))
        #CC=print((sim_total_pop-np.mean(sim_total_pop))/(np.std(sim_total_pop)))
        vec1=vec1[0]
        vec2=vec2[0]
            #if BB is not None:
            #BB= float(BB)

        
        #DD=BB[0]
        #DD=print(vec11)
        #AA=print(sim_total_pop)
            #if BB is not None:
            #EE= print(float(BB**2))
                #EE=print(BB**2)
                #FF=print(sum(EE))
                #sys.exit()
        # compute distances
        difference = vec1 - vec2
        #sys.exit()
        #print('difference:', difference.size)
        dist = np.linalg.norm(difference, ord=2)
      
        param_save.append([g_J_theta, g_B_theta, alpha0_theta, width_theta, f_s_theta, T0_theta, m_J_theta, m_A_theta])
        dists.append(dist)
        data_sim.append(difference)

        #data_sim.append([N_B_sim, N_J_sim, N_A_sim]) # stores the simulated date OR summary stats
        # trying to pull out the raw summary stats / data so that I can rescale OUTSIDE the loop and then calculate
        #distances
        # functions z_score and euclidean_distance should be useful here!

    #print('Distances:')
    #print(data_sim)

    # pick the trials that have non-zero weight + compute the weights
    library_index, eps = small_percent(dists,0.01)
    library = []
    weights = []
    stats   = []
    resultmanual=[]
    for i in range(0,len(library_index)):
        j = library_index[i]
        weights.append(compute_weight(dists[j], eps))
        library.append(param_save[j])
        stats.append(data_sim[j])

    # Rejection!!! All we have to do is compute an average
    parameters = np.array(library)
    parameter_estimate = np.average(parameters, axis=0)
    print("True parameter values:", PARAMS["g_J"], PARAMS["g_B"],PARAMS["alpha0"], PARAMS["width"], PARAMS["f_s"], PARAMS["T0"], PARAMS["m_J"], PARAMS["m_A"])
    print("Estimates:", parameter_estimate)
    # This doesn't seem very good yet???
    # break ?
    sys.exit()

    # Local-linear regression starts here

    # try a weighted fit. Assemble the matrix X as in the paper
    X = np.ones((len(stats), 12)
    for i in range(0, len(stats)):
         X[i, 1:12] = stats[i]

    # try to assemble Y as a vector of vectors? Is this correct?
    Y = library
    #compute the wlsw without using the build in function
    X_T=np.transpose(X)
    resultmanual=inv(X_T*weights*X)*X_T*weights*Y
    print(X)
    print(X_T)
    print(Y)
    print(resutmanual)
    sys.exit()
    

            

    # Why is this necessary?
    # X = sm.add_constant(X)

    # Q: How does this work?
    wls_model = sm.WLS(Y, stats, weights=weights**2)
    results = wls_model.fit()
    #print(results) what are these results???
    print('Fit results:')
    print(results.params)

    # Why the hell does this not work?
    #print(results.summary())

    #print('Library:')
    #for i, lib in enumerate(library):
    #    print('\ti: %d: %s' % (i, lib))
    #print(library)




