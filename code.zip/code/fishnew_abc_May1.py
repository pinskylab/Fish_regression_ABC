# this script simulates stage-structured population sizes in space and time for given parameters and forcin
# functions
from __future__ import print_function, division

# NB for EAM: this runs on Mushu in pipenv, so call pipenv run python fish_abc.py

# import dependencies
import numpy as np
import math as math
import sys
import copy as copy
import statsmodels.api as sm
from sklearn.kernel_ridge import KernelRidge
from numpy.linalg import inv
import scipy.stats as sst
from sklearn import preprocessing
#import matplotlib.pyplot as plt
from statsmodels.iolib.table import (SimpleTable, default_txt_fmt)
from sklearn.metrics import mean_squared_error
from sklearn.linear_model import Ridge
import matplotlib.pyplot as plt
def compute_weight(t, eps, CC):
    if t <= eps:
        return (1. - (t / eps)**2)/eps
    else:
        return 0.


def mean_confidence_interval(A, confidence=0.95):
    a = 1.0 * np.array(A)
    n = len(a)
    m, se = np.mean(a, axis=0), sst.sem(a, axis=0, ddof=1)
    h = se * sst.t.ppf((1 + confidence) / 2., n-1)
    return m, h, m-h, m+h

def confidence_interval(library, weights, stats, resultmanual):
    X = sm.add_constant(stats)
    Y = np.array(library)
    X_T=np.transpose(X)
    W=np.diag(np.array((weights/np.array(weights).sum())))
    n=stats.shape[0]
    p=stats.shape[1]
    y_hat=np.array(np.dot(X, resultmanual))
    var_w=(np.dot(np.dot(np.transpose(Y-y_hat), W), Y-y_hat))/(n-p-1)
    var_WS=np.diag(var_w)
    s_error=(Y-y_hat)**2
    ws_error=np.dot(W, s_error)
    ssw_error=(sum(ws_error))/(n-p-1)
#ssw_error=(sum(ws_error))
    WSSE=ssw_error*(inv(np.dot((np.dot(X_T, W)), X))[0][0])
    WSSE1=var_WS*(inv(np.dot((np.dot(X_T, W)), X))[0][0])
    t_critical=sst.t.ppf((1 + 0.95) / 2., n-p-1)
    h=np.sqrt(WSSE)*2
    h1=np.sqrt(WSSE1)*t_critical
    results=resultmanual[0,:]
    # print(results-h1)
    return results,h, results-h, results+h


def confidence_interval_Kridge(library, weights, stats, resul_coef):
    X = sm.add_constant(stats)
    Y = np.array(library)
    X_T=np.transpose(X)
    #W=np.diag(weights/np.std(weights))
    m, d=stats.shape
    nms=np.sum(np.transpose(stats)**2, axis=0)
    print(2*np.std(stats))
    W=np.exp((-np.transpose(np.matrix(nms))*np.ones((1,m))-np.ones((m,1))*np.matrix(nms)+2*np.dot(stats,np.transpose(stats)))/(2*np.std(stats)))
    #W=np.diag(np.array((weights/np.array(weights).sum())))
    # print(X.shape)
    #print(W.shape)
    #print(X_T.shape)
    n=stats.shape[0]
    p=stats.shape[1]
    y_hat=np.array(np.dot(X, resul_coef))
    #print((Y-y_hat).shape)
    var_w=(np.dot(np.dot(np.transpose(Y-y_hat), W), Y-y_hat))/(n-p-1)
    var_WS=np.diag(var_w)
    s_error=(Y-y_hat)**2
    #print(s_error.shape)
    #print(var_w.shape)
    ws_error=np.dot(W, s_error)
    ssw_error=(sum(ws_error))/(n-p-1)
    #ssw_error=(sum(ws_error))
    #print((np.dot(X_T, W)).shape)
    #print((np.dot((np.dot(X_T, W)), X)).shape)
    #print((inv(np.dot((np.dot(X_T, W)), X)).shape))
    AA_inv=np.array(inv(np.dot((np.dot(X_T, W)), X)))
          #print((inv(np.dot((np.dot(X_T, W)), X))[0][0][0)
    #print(inv(np.dot((np.dot(X_T, W)), X)))
    WSSE=ssw_error*(AA_inv[0][0])
    #WSSE1=var_WS*(inv(np.dot((np.dot(X_T, W)), X))[0][0])
    t_critical=sst.t.ppf((1 + 0.95) / 2., n-p-1)
    h=np.sqrt(WSSE)*t_critical
    #h1=np.sqrt(WSSE1)*t_critical
    results=resul_coef[0]
    #print(results-h1)
    return  results-h, results, results+h

def beta_defs(alpha,mu):
    """ Takes in an alpha shape parameter and the desired mean and returns a value from the beta
    distribution. Note that the mean of a beta distribution, mu, is alpha/(alpha+beta). thus given alpha, and the mean of the parameter, we can use this to compute beta. We do not need this if we decide to use uniform priors"""
    beta = alpha/mu - alpha
    val = np.random.beta(alpha, beta)
    return val


def temp_dependence(temperature, Topt, width, kopt):
    """ compute growth rate as a function of temperature, were kopt is the optimal growth rate, Topt, optimal temperature, width, the standard deviation from the optimal temperature.
    """
    #theta = -width*(temperature-Topt)*(temperature-Topt) + kopt
    theta = kopt*np.exp(-0.5*np.square((temperature-Topt)/width))
    #theta=((temperature-Tmin)*(temperature-Tmax))/(((temperature-Tmin)*(temperature-Tmax))-(temperature-Topt))
    return theta


def pop_dynamics(N_J, N_Y, N_A, params, alpha):
    """ Intake population sizes for the three population data structure
        for the parameter values; alph(parameter for beta distribution. With uniform priors, we do not need alph), alpha, the temperature dependent growth rate(output of the temp_dependence), fecudity is input separately. N_B is larvae, N_J is juvenille, and N_A is adults. [N_b(t+1)]=[birth]-[conversion to juvenile]. [N_J(t+1)]=[N_B becoming N_J]-[death]-[coversion to N_A]. [N_A(t+1)]=[fraction(f_s) from N_J and those that did not die that stays]-[fraction that leaves to another patch]
    """
    #recruits = beta_defs(alph,params["g_B"])
    #gJval = beta_defs(alph,params["g_J"])
    #nJ_coef = (1 - gJval - beta_defs(alph,params["m_J"]))
    nextN_J=np.random.poisson(lam=max(0,N_J+alpha*N_A-params["g_J"]*N_J-params["m_J"]*N_J))
    nextN_Y=np.random.poisson(lam=max(0,N_Y+params["g_J"]*N_J-params["g_Y"]*N_Y-params["m_Y"]*N_Y))
    nextN_A=N_A+params["g_Y"]*N_Y-params["m_A"]*N_A
    return nextN_J, nextN_Y, nextN_A


def movement(pop1, pop2, N_A11, N_A12, f_s):
    """ Takes population sizes in two patches, in which a fraction, f_s, of each stays and outputs
    the population sizes in each patch after movement """
    next_pop1 =np.random.poisson(lam=max(0,pop1+f_s*(N_A12-N_A11)))
    next_pop2 =np.random.poisson(lam=max(0,pop2+f_s*(N_A11-N_A12)))

    return next_pop1, next_pop2


def simulation_population(N_J0, N_Y0, N_A0, params, T_FINAL, temperatures):
    """ Takes in the initial population sizes and simulates the population size moving forward """
    # Set starting numbers for population and allocate space for population sizes
    N_J = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_J[0] = N_J0
    N_Y = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_Y[0] = N_Y0
    N_A = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_A[0] = N_A0

    for t in range(0,T_FINAL):
        alpha1 = temp_dependence(temperatures[t], params["Topt"], params["width"], params["kopt"])
        alpha2 = temp_dependence(temperatures[t] + params["delta_t"], params["Topt"], params["width"], params["kopt"])

        N_J[t+1][0], N_Y[t+1][0], N_A1 = pop_dynamics(N_J[t][0], N_Y[t][0], N_A[t][0], params, alpha1)
        N_J[t+1][1], N_Y[t+1][1], N_A2 = pop_dynamics(N_J[t][1], N_Y[t][1], N_A[t][1], params, alpha2)

        N_A[t+1][0], N_A[t+1][1] = movement(N_A1,N_A2,N_A[t][0],N_A[t][1], params["xi"])

    return N_J, N_Y, N_A


def calculate_summary_stats(N_J, N_Y, N_A, T_FINAL):
    """Takes in a matrix of time x place population sizes for each stage and calculates summary statistics"""
    time=range(T_FINAL)
    total_adult = N_A.sum(axis=1) # total population in each stage, summed over space
    total_young = N_Y.sum(axis=1)
    total_juv   = N_J.sum(axis=1)
    #lquartile_adult=np.percentile(total_adult, 25)
    L_Q=np.percentile(time, 25, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    M_Q=np.percentile(time, 50, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    U_Q=np.percentile(time, 75, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    #print('time:', time)
    #print('LQ:', L_Q, ' MQ:', M_Q, ' UQ:', U_Q)
    lquartile_adult=total_adult[L_Q]#np.percentile(total_adult, 25)
    median_adult=total_adult[M_Q]#np.percentile(total_adult, 50)
    uquartile_adult=total_adult[U_Q]#np.percentile(total_adult, 75)
    mean_adult=np.mean(total_adult)
    std_adult=np.std(total_adult)
    lquartile_young=total_young[L_Q]#np.percentile(total_juv, 25)
    median_young=total_young[M_Q]#np.percentile(total_juv, 50)
    uquartile_young=total_young[U_Q]#np.percentile(total_juv, 75)
    mean_young=np.mean(total_young)
    std_young=np.std(total_young)
    lquartile_juv=total_juv[L_Q]#np.percentile(total_larv, 25)
    median_juv=total_juv[M_Q]#np.percentile(total_larv, 50)
    uquartile_juv=total_juv[U_Q]#np.percentile(total_larv, 75)
    mean_juv=np.mean(total_juv)
    std_juv=np.std(total_juv)
    #print('total_adult:', total_adult)
    #print('N_A:', N_A)
    SS_adult=np.hstack((lquartile_adult, median_adult, uquartile_adult))
    SS_young=np.hstack((lquartile_young, median_young, uquartile_young))
    SS_juv=np.hstack((lquartile_juv, median_juv, uquartile_juv))
    SS_adult1=np.hstack((N_A[L_Q], N_A[M_Q], N_A[U_Q]))
    SS_young1=np.hstack((N_Y[L_Q], N_Y[M_Q], N_Y[U_Q]))
    SS_juv1=np.hstack((N_J[L_Q], N_J[M_Q], N_J[U_Q]))
    #total_population = total_adult + total_juv + total_larv # total population size in each time
    #print(total_adult)
    # print(lquartile_adult)
    #print(SS_adult)
    #print(mean_adult)
    #sys.exit()
    return SS_adult1, SS_young1, SS_juv1


def euclidean_distance(vec1, vec2):
    """ Takes two vectors of the same dimensions and calculates the Euclidean distance between the elements"""
    return np.linalg.norm(vec1 - vec2, ord=2)


def small_percent(vector, percent):
    """ Takes a vector and returns the indexes of the elements within the smallest (percent) percent of the vector"""
    sorted_vector = sorted(vector)
    cutoff = math.floor(len(vector)*percent/100) # finds the value which (percent) percent are below
    indexes = []
    print('cutoff:',cutoff)
    cutoff = int(cutoff)
    for i in range(0,len(vector)):
        if vector[i] < sorted_vector[cutoff]: # looks for values below the found cutoff
            indexes.append(i)

    return indexes, sorted_vector[cutoff]


def z_score(x):
    """Takes a list and returns a 0 centered, std = 1 scaled version of the list"""
    st_dev = np.std(x,axis=0)
    mu = np.mean(x,axis=0)
    rescaled_values = []
    for element in range(0,len(x)):
        rescaled_values[element] = (x[element] - mu) / st_dev

    return rescaled_values



def do_kernel_ridge(stats, library,weights):
    #print('X:', X.shape)
    #print('Y:', Y.shape)
    X = sm.add_constant(stats)
    Y=np.array(library)
    clf     = KernelRidge(alpha=1.0, kernel='rbf', coef0=0)
    resul   = clf.fit(X, Y)
    resul_coef=np.dot(X.transpose(), resul.dual_coef_)
    coefficients =resul_coef[0]
    mean_conf=confidence_interval_Kridge(library, weights, stats,resul_coef)
    print(resul_coef.shape)
    print(mean_conf)
    #print('dual :', clf.dual_coef_)
    #print('X    :', X.transpose().shape)
    actual=[0.4, 0.3, 7, 0,15, 0.1, 0.05, 0.05, 0.05]
    #actual=[0.4,0.3,2,1,0.9,1,0.05,0.05]
    NMSE_ridreg=1-(((np.linalg.norm(actual-coefficients , ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print('Estimates from regression abc using Kernel ridge regression is :', coefficients)
    print('NMSE for kernel Ridge regression  is :', NMSE_ridreg)
    #print('coefficients:', coefficients)


def do_ridge(stats, library):
    X = sm.add_constant(stats)
    Y=np.array(library)
    R = Ridge(alpha=1.0, fit_intercept=False)
    resul_R=R.fit(X, Y)
    actual=[0.4, 0.3, 12.5, 5, 27, 0.1, 0.05, 0.05, 0.05]
    #actual=[0.4,0.3,2,1,0.9,1,0.05,0.05]
    NMSE_ridge=1-(((np.linalg.norm(actual-np.transpose(resul_R.coef_)[0], ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print('Estimates from regression abc using  ridge regression is :', np.transpose(resul_R.coef_)[0])
    print('NMSE for Ridge  regression  is :', NMSE_ridge)

def print_parameters(params, prefix=''):
    print('%s parameter values:' % prefix, end=' ')
    for name, value in params.items():
        print('%s = %.2f' % (name, value), end='\t')


def do_rejection(library, PARAMS):
    #print_parameters(PARAMS, 'True')

    # compute parameter estimates
    parameter_estimate = np.average(library, axis=0)
    m, h, lo_b, ub_b=mean_confidence_interval(library, confidence=0.95)
    mean_conf_int_para=m, lo_b, ub_b
    print(m)
    print(mean_conf_int_para)
    #print(mean_conf_int_para)
    colnames = ['mean', 'lower bound', 'upper bound']
    rownames = ['g_J', 'g_Y', 'Topt', 'width','kopt', 'xi', 'm_J', 'm_Y', 'm_A']
    tabl = SimpleTable(np.transpose(mean_conf_int_para), colnames, rownames, txt_fmt=default_txt_fmt)
    print(tabl)
    actual=[0.4, 0.3, 6.5, 2, 0.6, 0.1, 0.04, 0.05, 0.05]
    #actual=[0.4,0.3,2,1,0.9,1,0.05,0.05]
    NMSE_rejection=1-(((np.linalg.norm(actual-parameter_estimate, ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print("Estimates from rejection abc:", parameter_estimate)
    print("True parameter values:", PARAMS["g_J"], PARAMS["g_Y"],PARAMS["Topt"], PARAMS["width"], PARAMS["kopt"], PARAMS["xi"], PARAMS["m_J"], PARAMS["m_Y"], PARAMS["m_A"])
    print('NMSE for rejection abc  is :', NMSE_rejection)
    print('\n')
    return  m, h

def do_regression_online(library, weights, stats):
    X = sm.add_constant(stats)
    # try to assemble Y as a vector of vectors? Is this correct?
    Y = np.array(library)

    weigh=np.diag(weights)
    AA=np.transpose([np.linalg.pinv(weigh[:,i,None] * X).dot(Y[:,i]) for i in range(9)])
    actual=[0.4, 0.3, 4.5, 2, 2, 0.1, 0.07, 0.05, 0.05]
    #actual=[0.4,0.3,2,1,0.9,1,0.05,0.05]
    NMSE_online=1-(((np.linalg.norm(actual-AA[0], ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print("Estimates from formula 1:", AA[0])
    print("True parameter values:", PARAMS["g_J"], PARAMS["g_Y"],PARAMS["Topt"], PARAMS["width"], PARAMS["kopt"], PARAMS["xi"], PARAMS["m_J"], PARAMS["m_Y"], PARAMS["m_A"])
    print('NMSE for online regression  is :', NMSE_online)

def do_regression_manual(library, weights, stats):
    X = sm.add_constant(stats)
    Y = np.array(library)
    X_T=np.transpose(X)
    #print('X:', X.shape, ' ', X)
    #print('Y:', Y.shape, ' ', Y)
    #print('Y:', Y.shape)
    #mmmm = np.mat(X_T)*np.mat(np.diag(np.array((weights/np.array(weights).sum()))))*np.mat(X)
    #print('M:', mmmm)
    inv_X=inv(np.mat(X_T)*np.mat(np.diag(np.array((weights/np.array(weights).sum()))))*np.mat(X))
    resultmanual=inv_X*(X_T*np.mat(np.diag(np.array((weights/np.array(weights).sum()))))*Y)
    results=resultmanual[0,:]
    results,h, lo_b1, u_b1=confidence_interval(library, weights, stats, resultmanual)
    mean_conf=results, lo_b1, u_b1
    # print(mean_conf)
    # print(results)
    #print(confidence_interval(library, weights, stats, resultmanual))
    colnames = ['mean', 'lower bound', 'upper bound']
    rownames = ['g_J', 'g_Y', 'Topt', 'width','kopt', 'xi', 'm_J', 'm_Y', 'm_A']
    tabl = SimpleTable(np.transpose(mean_conf), colnames, rownames, txt_fmt=default_txt_fmt)
    print(tabl)
    actual=[0.4, 0.3, 12.5, 6, 0.6, 0.1, 0.04, 0.05, 0.05]
    #actual=[0.4,0.3,2,1,0.9,1,0.05,0.05]
    NMSE_paper=1-(((np.linalg.norm(actual-results, ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print("Estimates from regression abc-manual computation:", results)
    print("True parameter values:", PARAMS["g_J"], PARAMS["g_Y"],PARAMS["Topt"], PARAMS["width"], PARAMS["kopt"], PARAMS["xi"], PARAMS["m_J"], PARAMS["m_Y"], PARAMS["m_A"])
    print('NMSE for paper  is :', NMSE_paper)
    return results,lo_b1, u_b1
        #def do_regression_manual(library, weights, X):
        # Y = library
        #YY=np.array(Y)
        #mean_conf_int = np.c_[vecZZ,con_int]
        ## rownames = ['g_J', 'g_B', 'alpha0', 'width', 'f_s', 'T0', 'm_J', 'm_A']
        #tabl = SimpleTable(mean_conf_int, colnames, rownames, txt_fmt=default_txt_fmt)
        #print(tabl)
    #print( tabl.as_latex_tabular() )
    # print("True parameter values:", PARAMS["g_J"], PARAMS["g_B"],PARAMS["alpha0"], PARAMS["width"], PARAMS["f_s"], PARAMS["T0"], PARAMS["m_J"], PARAMS["m_A"])
#print("Estimates from manula computation is :", AA[0])

def do_local_linear(stats, library, weights,KK):
    # Local-linear regression starts here
    Y = np.array(library)

    # define some later used vectors
    ZZ = np.ones(9)
    QQ = np.ones(9)
    con_int =np.ones((9,2))
    con_int1=np.ones((9,2))
    # try a weighted fit. Assemble the matrix X as in the paper
    #X = np.ones((len(stats), len(SO)+1))
    #for i in range(0, len(stats)):
        #print('stats:', stats[i])
        #X[i, 1:len(SO)+1] = stats[i]

    X= sm.add_constant(stats)
    XXX = np.mean(stats, axis=1)
    Xtrial=sm.add_constant(XXX)

    for ii in range(0,9):
         y = Y[:,ii]
         
    
         print(X.shape)
         print(stats.shape)
         print(Y[:,ii].shape)
         print(Y.shape)
        
         #w=weigh[:,ii]
         mod_wls  = sm.WLS(y, Xtrial, weights=np.array(weights)**2/np.array(weights).sum()**2)
         mod_wls1 = sm.WLS(y, X, weights=np.array(weights)**2/np.array(weights).sum()**2)
         #print(weights)
         res_wls  = mod_wls.fit()
         res_wls1 = mod_wls1.fit()

         con_in   = res_wls.conf_int()
         con_in1   = res_wls1.conf_int()
         con_int[ii, :] =con_in[0]
         con_int1[ii, :] =con_in1[0]
         ZZ[ii]   = res_wls.params[0]
         QQ[ii]   = res_wls1.params[0]
         print(res_wls1.params.shape)
         print(stats.dot(res_wls1.params[1:]))
         print(np.transpose(stats).dot(np.transpose(res_wls1.params[1:])))
         sys.exit()

    print("with confidence intervals:", con_int)
    print("Estimates from statsmodels.api   with X 1D is:", ZZ)
    actual=[0.4, 0.3, 12.5, 5, 27, 0.1, 0.04, 0.05, 0.05]
#actual=[0.4,0.3,2,1,0.9,1,0.05,0.05]
    NMSE_XoneD=1-(((np.linalg.norm(actual-ZZ, ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print('NMSE python statsmodels.api with X 1D :', NMSE_XoneD)
    print("with confidence intervals:", con_int1)
    print("Estimates from python statsmodels.api with X 2D is:", QQ)
    actual=[0.4, 0.3, 12.5, 5, 27, 0.1, 0.04, 0.05, 0.05]
    NMSE_XtwoD=1-(((np.linalg.norm(actual-QQ, ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print('NMSE python statsmodels.api with X 2D is :', NMSE_XtwoD)
    print("True parameter values:",PARAMS["g_J"], PARAMS["g_Y"],PARAMS["Topt"], PARAMS["width"], PARAMS["kopt"], PARAMS["xi"], PARAMS["m_J"], PARAMS["m_Y"], PARAMS["m_A"])

def run_sim(PARAMS, NUMBER_SIMS):
    PARAMS_ABC = copy.deepcopy(PARAMS) # copies parameters so new values can be generated; FIX ME! this is a redirect, not a copy?
    param_save = [] # sets an initial 0; fixed to [] because [[]] made the mean go poorly (averaging in an [] at start?)

    print_parameters(PARAMS, prefix='True')

    # Sets temperatures at each patch over time [FIX THIS]
    temperatures = np.linspace(5, 25,T_FINAL)
    #temperatures = [3.6,3.8,4,4.2,4.4,4.6,4.8,5,5.2,5.4]
    #temperatures = [0,1,2,3,4,5,6,7,8,9]
    # Simulates population
    N_J, N_Y, N_A = simulation_population(N0, N0, N0, PARAMS, T_FINAL, temperatures)

    SS_adult, SS_young, SS_juv= calculate_summary_stats(N_J, N_Y, N_A, T_FINAL)
    SO=np.hstack((SS_adult, SS_young, SS_juv))
    Obs_Sim=np.zeros((NUMBER_SIMS+1,len(SO)))
    Obs_Sim[0,:]=SO
    for i in range(0,NUMBER_SIMS):
        g_J_theta    = np.random.uniform(0.1,0.6)#np.random.normal(0.4,0.3) #np.random.beta(2,2)
        g_Y_theta    =np.random.uniform(0.1,0.6) #np.random.uniform(0,1)#np.random.beta(2,2)
        Topt_theta =np.random.uniform(10,14)#np.random.normal(6.5,2) #np.random.uniform(1,12) #np.random.lognormal(1,1)
        width_theta  =np.random.uniform(4,8)#np.random.normal(2,1)
        ##np.random.lognormal(1,1)
        kopt_theta    =np.random.uniform(0.4,1)#np.random.normal(0.5,0.4)# np.random.u(0,1)
        xi_theta     =np.random.uniform(0,0.2)#np.random.normal(0.1,0.09) #np.random.normal(0,1)#np.random.normal(0,0.5)
        m_J_theta    =np.random.uniform(0,0.09)#np.random.normal(0.04,0.04) # #np.random.beta(2,2)
        m_Y_theta    =np.random.uniform(0,0.09)#np.random.normal(0.05,0.04) #np.random.uniform(0,1) #np.random.beta(2,2)
        m_A_theta    =np.random.uniform(0,0.09)#np.random.normal(0.05,0.05)# np.random.uniform(0,1)#np.random.beta(2,2)

        PARAMS_ABC["g_J"]    = g_J_theta # sets the g_J parameter to our random guess
        PARAMS_ABC["g_Y"]    = g_Y_theta
        PARAMS_ABC["Topt"] = Topt_theta
        PARAMS_ABC["width"]  = width_theta
        PARAMS_ABC["kopt"]    = kopt_theta
        PARAMS_ABC["xi"]     = xi_theta
        PARAMS_ABC["m_J"]    = m_J_theta
        PARAMS_ABC["m_Y"]    = m_Y_theta
        PARAMS_ABC["m_A"]    = m_A_theta

        # Simulate population for new parameters
        N_J_sim, N_Y_sim, N_A_sim = simulation_population(N0,N0,N0, PARAMS_ABC, T_FINAL, temperatures) # simulates population with g_J value

        # Calculate the summary statistics for the simulation
        Sim_SS_adult, Sim_SS_young, Sim_SS_juv= calculate_summary_stats(N_J_sim, N_Y_sim, N_A_sim, T_FINAL)
        SS=np.hstack((Sim_SS_adult, Sim_SS_young, Sim_SS_juv))
        Obs_Sim[i+1,:]=SS

        param_save.append([g_J_theta, g_Y_theta, Topt_theta, width_theta, kopt_theta, xi_theta, m_J_theta,m_Y_theta, m_A_theta])

    return np.asarray(param_save), Obs_Sim


def compute_scores(dists, param_save, difference, c):
    eps=5
    library_index, eps = small_percent(dists, eps)
    n                = len(library_index)
    library, weights, Ker_vec = np.empty((n, param_save.shape[1])), np.empty(n), np.empty(n)

    
    stats            = np.empty((n, difference.shape[1]))


    for i in range(0,len(library_index)):
        j = library_index[i]
        CC=c[j]
        weights[i] = compute_weight(dists[j], eps, CC)
        library[i] = param_save[j]
        stats[i]   = difference[j]
        Ker_vec[i]=dists[j]
    KK=np.exp(-np.power(Ker_vec,2)/(2*np.std(Ker_vec)**2))
    return library, weights, stats, KK


def sum_stats(Obs_Sim, param_save, NUMBER_SIMS):
    dists = np.zeros((NUMBER_SIMS,1))
    #Obs_Sim_scale=np.nan_to_num(sst.zscore(Obs_Sim, axis=0,ddof=1),copy=True)
    Obs_Sim_scale=np.nan_to_num(preprocessing.normalize(Obs_Sim, axis=0),copy=True)
    #Substract each row of teh array from row 1
    difference=Obs_Sim_scale[1:NUMBER_SIMS+1,: ]-Obs_Sim_scale[0,:]
    c=np.std(Obs_Sim_scale[1:NUMBER_SIMS+1,: ], axis=1)
    # compute the norm 2 of each row
    dists = np.linalg.norm(difference, axis=1)

    library, weights, stats, KK = compute_scores(dists, param_save, difference,c)
    return library, weights, stats, KK


def do_regression(library, stats, PARAMS):

    # REJECTION
    print('\nDo a rejection ABC:')
    do_rejection(library, PARAMS)

    #print('\nStats:', stats.shape)
    #print('\nStats:', stats)
    #print('\nLibar:', library.shape)
    #print('\nLibar:', library)

    do_kernel_ridge(stats, library)
    do_ridge(stats, library)

if __name__ == '__main__':
    # Sets parameters
    PARAMS = {"g_J": 0.4, "g_Y": 0.3, "Topt": 12.5, "width": 6, "kopt": 0.6,"xi":0.1, "m_J": .04, "m_Y": .05, "m_A": .05, "delta_t": 2}
    #PARAMS = {"alpha0": 2, "T0": 1, "width": 1, "g_B": .3, "g_J": .4, "m_J": .05, "m_A": .05, "f_s": .9, "delta_t":.1, "lam":1}
    T_FINAL = 10
    #print(PARAMS["g_J"])
    #LANDSCAPE_LEN = 2
    N0 = 5
    NUMBER_SIMS = 200

    # true parameters
    actual=[0.4, 0.3, 12.5, 6, 0.6, 0.1, 0.04, 0.05, 0.05]
    param_save, Obs_Sim         = run_sim(PARAMS, NUMBER_SIMS)
    library, weights, stats, KK     = sum_stats(Obs_Sim, param_save, NUMBER_SIMS)
    #result, h=do_regression_manual(library, weights, stats)
    do_local_linear(stats, library, weights,KK)
    #result1, h1=do_rejection(library, PARAMS)
    #result,h, lo_b1, u_b1=do_regression_manual(library, weights, stats)
    #AA=result-h
    #BB=result+h
    #print(lo_b1[0][:])
    #print(lo_b1[0][:][1])
    #print(u_b1[0][0][0])
    #print(lo_b1)
    #print(lo_b1[0,1])
    #print(u_b1[0,8])
    sys.exit()

    
    rSize   = len(actual)
    N_REPS  = 100
    results = np.empty((N_REPS, rSize))
    meansquare = np.empty((N_REPS, rSize))
    squar=np.empty((N_REPS, rSize))
    results[:] = np.NaN
    coverage=np.empty((N_REPS, rSize))

    for i in range(N_REPS):
        param_save, Obs_Sim         = run_sim(PARAMS, NUMBER_SIMS)
        library, weights, stats, KK     = sum_stats(Obs_Sim, param_save, NUMBER_SIMS)
        #do_local_linear(stats, library, weights,KK)
        #result, h=do_rejection(library, PARAMS)
        result, lo_b1, u_b1=do_regression_manual(library, weights, stats)
        for j in range(0,len(actual)):
          if lo_b1[0,j]<=actual[j]<=u_b1[0,j]:
            coverage[i,j]=1
          else:
            coverage[i,j]=0
        #result, h1=do_rejection(library, PARAMS)
        #result, h=do_regression_manual(library, weights, stats)
        #result.flatten()
        #print(i)
        results[i,:] = (result - actual)
#print(np.array(np.square(results)).sum()/N_REPS)
# print(mean_squared_error(actual, result))
# nnmeansquare[i,:]=mean_squared_error(actual, result)
    coverage_percen=(np.array(coverage).sum(axis=0)/N_REPS*100)
    meansquare=(np.array(np.square(results)).sum(axis=0))/N_REPS
    squar=np.square(results)
    print("The Coverage probability is:", coverage_percen)
    print("The mean squared error is:", meansquare)
#print(h.shape)
# Create a figure instance
    fig= plt.figure(1, figsize=(9, 6))
# Create an axes instance
    ax = fig.add_subplot(111)
    # Create the boxplot
    bp = ax.boxplot(results, showfliers=0)
    plt.rc('ytick',labelsize=18)
    ## add patch_artist=True option to ax.boxplot()
    ## to get fill color
    bp = ax.boxplot(results, patch_artist=True, showfliers=0)
    for box in bp['boxes']:
        # change outline color
      box.set( color='#7570b3', linewidth=2)
        # change fill color
      box.set( facecolor = '#1b9e77' )
        ## change color and linewidth of the whiskers
    for whisker in bp['whiskers']:
      whisker.set(color='#7570b3', linewidth=2)
    ## change color and linewidth of the caps
    for cap in bp['caps']:
      cap.set(color='#7570b3', linewidth=2)

    ## change color and linewidth of the medians
    for median in bp['medians']:
      median.set(color='#b2df8a', linewidth=2)

## change the style of fliers and their fill
    for flier in bp['fliers']:
      flier.set(marker='o', color='#e7298a', alpha=0.5)
    ax.set_xticklabels([r'$g_j$', r'$g_y$', r'$T_{opt}$', r'$D$', r'$K_{opt}$', r'$\xi$', r'$m_j$', r'$m_y$', r'$m_a$'], fontsize=18)
    ax.get_xaxis().tick_bottom()
    ax.get_yaxis().tick_left()
    ax.tick_params(width = 2, direction = "out")
    for axis in ['top','bottom','left','right']:
      ax.spines[axis].set_linewidth(2)
    ax.set_ylabel('Bias in Parameter Estimation', fontsize=18)
    ax.set_xlabel('Parameters',fontsize=18)
    # Save the figure
    fig.savefig('figbiasMay1.png', bbox_inches='tight')
#print('results:', result

#Create a figure instance
    fig1= plt.figure(2, figsize=(10, 7))
     # Create an axes instance
    ax1 = fig1.add_subplot(111)
    # Create the boxplot
    bp1 = ax1.boxplot(squar, showfliers=0)
    plt.rc('ytick',labelsize=18)
    ## add patch_artist=True option to ax.boxplot()
    ## to get fill color
    bp1 = ax1.boxplot(squar, patch_artist=True, showfliers=0)
    for box in bp1['boxes']:
        # change outline color
      box.set( color='#7570b3', linewidth=2)
        # change fill color
      box.set( facecolor = '#1b9e77' )
        ## change color and linewidth of the whiskers
    for whisker in bp1['whiskers']:
      whisker.set(color='#7570b3', linewidth=2)
    ## change color and linewidth of the caps
    for cap in bp1['caps']:
      cap.set(color='#7570b3', linewidth=2)

    ## change color and linewidth of the medians
    for median in bp1['medians']:
      median.set(color='#b2df8a', linewidth=2)

## change the style of fliers and their fill
    for flier in bp1['fliers']:
      flier.set(marker='o', color='#e7298a', alpha=0.5)
    ax1.set_xticklabels([r'$g_j$', r'$g_y$', r'$T_{opt}$', r'$D$', r'$K_{opt}$', r'$\xi$', r'$m_j$', r'$m_y$', r'$m_a$'], fontsize=18)
    ax1.get_xaxis().tick_bottom()
    ax1.get_yaxis().tick_left()
    ax1.tick_params(width = 2, direction = "out")
    for axis in ['top','bottom','left','right']:
      ax1.spines[axis].set_linewidth(2)
    ax1.set_ylabel('Square Error', fontsize=18)
    ax1.set_xlabel('Parameters',fontsize=18)
    # Save the figure
    fig1.savefig('figsqaureMay1.png', bbox_inches='tight')
#print('results:', result
    sys.exit()
    regression_gj = np.linspace(results[0,0] - 3*h[0], results[0,0] + 3*h[0], 1000)
    regression_gy =np.linspace(results[0,1] - 3*h[1], results[0,1] + 3*h[1], 1000)
    regression_Topt =np.linspace(results[0,2] - 3*h[2], results[0,2] + 3*h[2], 1000)
    regression_Tmin =np.linspace(results[0,3] - 3*h[3], results[0,3] + 3*h[3], 1000)
    regression_Tmax =np.linspace(results[0,4] - 3*h[4], results[0,4] + 3*h[4], 1000)
    regression_xi = np.linspace(results[0,5] - 3*h[5], results[0,5] + 3*h[5], 1000)
    regression_mj =np.linspace(results[0,6] - 3*h[6], results[0,6] + 3*h[6], 1000)
    regression_my =np.linspace(results[0,7] - 3*h[7], results[0,7] + 3*h[7], 1000)
    regression_ma =np.linspace(results[0,8] - 3*h[8], results[0,8] + 3*h[8], 1000)
                                  #rejection_gj = np.linspace(min(library[:,0]), max(library[:,0]), 1000)#(m[0] - 3*h1[0], m[0] + 3*h1[0], 1000)
    fgj, axgj1 = plt.subplots(1, 1, sharey=True)
    fgy, axgy1 = plt.subplots(1, 1, sharey=True)
    fTopt, axTopt1 = plt.subplots(1, 1, sharey=True)
    fTmin, axTmin1 = plt.subplots(1, 1, sharey=True)
    fTmax, axTmax1 = plt.subplots(1, 1, sharey=True)
    fxi, axxi1 = plt.subplots(1, 1, sharey=True)
    fmj, axmj1 = plt.subplots(1, 1, sharey=True)
    fmy, axmy1 = plt.subplots(1, 1, sharey=True)
    fma, axma1= plt.subplots(1, 1, sharey=True)
    axgj1.plot(regression_gj,sst.norm.pdf(regression_gj, results[0,0], h[0]),'k-', linewidth=4 )
    axgb1.plot(regression_gy,sst.norm(results[0,1], h[1]).pdf(regression_gy),'k-', linewidth=4 )
    axTopt1.plot(regression_Topt,sst.norm(results[0,2], h[2]).pdf(regression_Topt),'k-', linewidth=4 )
    axTmin1.plot(regression_Tmin,sst.norm(results[0,3], h[3]).pdf(regression_Tmin),'k-', linewidth=4 )
    axTmax1.plot(regression_Tmax,sst.norm(results[0,4], h[4]).pdf(regression_Tmax),'k-', linewidth=4 )
    axxi1.plot(regression_xi,sst.norm(results[0,5], h[5]).pdf(regression_xi),'k-', linewidth=4 )
    axmj1.plot(regression_mj,sst.norm(results[0,6], h[6]).pdf(regression_mj),'k-', linewidth=4 )
    axmy1.plot(regression_my,sst.norm(results[0,7], h[7]).pdf(regression_my),'k-', linewidth=4 )
    axma1.plot(regression_ma,sst.norm(results[0,8], h[8]).pdf(regression_ma),'k-', linewidth=4 )
    ubgj1=results[0,0]+h[0]
    lbgj1=results[0,0]-h[0]
    ubgy1=results[0,1]+h[1]
    lbgy1=results[0,1]-h[1]
    ubTopt1=results[0,2]+h[2]
    lbTopt1=results[0,2]-h[2]
    ubTmin1=results[0,3]+h[3]
    lbTmin1=results[0,3]-h[3]
    ubTmax1=results[0,4]+h[4]
    lbTmax1=results[0,4]-h[4]
    ubxi1=results[0,5]+h[5]
    lbxi1=results[0,5]-h[5]
    ubmj1=results[0,6]+h[6]
    lbmj1=results[0,6]-h[6]
    ubmy1=results[0,7]+h[7]
    lbmy1=results[0,7]-h[7]
    ubma1=results[0,8]+h[8]
    lbma1=results[0,8]-h[8]
    axgj1.fill_between(regression_gj, 0, sst.norm(results[0,0], h[0]).pdf(regression_gj), where = (regression_gj<=ubgj1) & (regression_gj>=lbgj1))
    axgj1.vlines(PARAMS["g_J"], 0,sst.norm(results[0,0], h[0]).pdf(PARAMS["g_J"]) , colors='r', linewidth=4)
    axgj1.set_ylabel('Probability density', fontsize=18)
    axgj1.set_xlabel(r'$g_j$',fontsize=18)
    axgj1.tick_params(width = 2, direction = "out")
    axgj1.set_ylim(0,)
    for axis in ['top','bottom','left','right']:
      axgj1.spines[axis].set_linewidth(2)

    axgy1.fill_between(regression_gy, 0, sst.norm(results[0,1], h[1]).pdf(regression_gy), where = (regression_gy<=ubgy1) & (regression_gb>=lbgy1))
    axgy1.vlines(PARAMS["g_Y"], 0,sst.norm(results[0,1], h[1]).pdf(PARAMS["g_Y"]) , colors='r', linewidth=4)
    axgy1.set_ylabel('Probability density', fontsize=18)
    axgy1.set_xlabel(r'$g_y$', fontsize=18)
    axgy1.set_ylim(0,)
    for axis in ['top','bottom','left','right']:
      axgy1.spines[axis].set_linewidth(2)
    axgy1.tick_params(width = 2, direction = "out")
    axTopt1.fill_between(regression_Topt, 0, sst.norm(results[0,2], h[2]).pdf(regression_Topt), where = (regression_Topt<=ubTopt1) & (regression_Topt>=lbTopt1))
    axTopt1.vlines(PARAMS["Topt"], 0,sst.norm(results[0,2], h[2]).pdf(PARAMS["Topt"]) , colors='r', linewidth=4)
    axTopt1.set_ylabel('Probability density', fontsize=18)
    axTopt1.set_xlabel(r'$T_{opt}$', fontsize=18)
    axalpha01.set_ylim(0,)
    for axis in ['top','bottom','left','right']:
      axTopt1.spines[axis].set_linewidth(2)
    axTopt1.tick_params(width = 2, direction = "out")
    axTmin1.fill_between(regression_Tmin, 0, sst.norm(results[0,3], h[3]).pdf(regression_Tmin), where = (regression_Tmin<=ubTmin1) & (regression_Tmin>=lbTmin1))
    axTmin1.vlines(PARAMS["Tmin"], 0,sst.norm(results[0,3], h[3]).pdf(PARAMS["Tmin"]) , colors='r', linewidth=4)
    axw1.set_ylabel('Probability density', fontsize=18)
    axw1.set_ylim(0,)
    for axis in ['top','bottom','left','right']:
      axTmin1.spines[axis].set_linewidth(2)
    axTmin1.set_xlabel(r'$T_{min}$', fontsize=18)
    axTmin1.tick_params(length = 4, width = 1, direction = "out")
    axTmax1.fill_between(regression_Tmax, 0, sst.norm(results[0,4], h[4]).pdf(regression_Tmax), where = (regression_Tmax<=ubTmax1) & (regression_Tmax>=lbTmax1))
    axTmax1.vlines(PARAMS["Tmax"], 0,sst.norm(results[0,4], h[4]).pdf(PARAMS["Tmax"]) , colors='r', linewidth=4)
    axTmax1.set_ylabel('Probability density', fontsize=18)
    axTmax1.set_xlabel(r'$T_{max}$', fontsize=18)
    for axis in ['top','bottom','left','right']:
      axTmax1.spines[axis].set_linewidth(2)
    axTmax1.set_ylim(0,)
    axTmax1.tick_params(width = 2, direction = "out")
    axxi1.fill_between(regression_xi, 0, sst.norm(results[0,5], h[5]).pdf(regression_xi), where = (regression_xi<=ubxi1) & (regression_xi>=lbxi1))
    axxi1.vlines(PARAMS["xi"], 0,sst.norm(results[0,5], h[5]).pdf(PARAMS["xi"]) , colors='r', linewidth=4)
    axxi1.set_ylabel('Probability density', fontsize=18)
    axxi1.set_xlabel(r'$\xi$', fontsize=18)
    axxi1.set_ylim(0,)
    for axis in ['top','bottom','left','right']:
      axxi1.spines[axis].set_linewidth(2)
    axxi1.tick_params(length = 4, width = 1, direction = "out")
    axmj1.fill_between(regression_mj, 0, sst.norm(results[0,6], h[6]).pdf(regression_mj), where = (regression_mj<=ubmj1) & (regression_mj>=lbmj1))
    axmj1.vlines(PARAMS["m_J"], 0,sst.norm(results[0,6], h[6]).pdf(PARAMS["m_J"]) , colors='r', linewidth=4)
    axmj1.set_ylabel('Probability density', fontsize=18)
    axmj1.set_xlabel(r'$m_j$', fontsize=18)
    axmj1.set_ylim(0,)
    for axis in ['top','bottom','left','right']:
      axmj1.spines[axis].set_linewidth(2)
    axmj1.tick_params(width = 2, direction = "out")
    axmy1.fill_between(regression_my, 0, sst.norm(results[0,7], h[7]).pdf(regression_my), where = (regression_my<=ubmy1) & (regression_my>=lbmy1))
    axmy1.vlines(PARAMS["m_Y"], 0,sst.norm(results[0,7], h[7]).pdf(PARAMS["m_Y"]) , colors='r', linewidth=4)
    axmy1.set_ylabel('Probability density', fontsize=18)
    axmy1.set_xlabel(r'$m_y$', fontsize=18)
    axmy1.set_ylim(0,)
    for axis in ['top','bottom','left','right']:
      axmy1.spines[axis].set_linewidth(2)
    axmy1.tick_params(width = 2, direction = "out")
    axma1.fill_between(regression_ma, 0, sst.norm(results[0,8], h[8]).pdf(regression_ma), where = (regression_ma<=ubma1) & (regression_ma>=lbma1))
    axma1.vlines(PARAMS["m_A"], 0,sst.norm(results[0,8], h[8]).pdf(PARAMS["m_A"]) , colors='r', linewidth=4)
    axma1.set_ylabel('Probability density', fontsize=18)
    axma1.set_xlabel(r'$m_a$', fontsize=18)
    axma1.set_ylim(0,)
    for axis in ['top','bottom','left','right']:
      axma1.spines[axis].set_linewidth(2)
    axma1.tick_params(width = 2, direction = "out")
    fgj.savefig('fgj.eps')
    fgy.savefig('fgy.eps')
    fTopt.savefig('fTopt.eps')
    fTmin.savefig('fTmin.eps')
    fTmax.savefig('fTmax.eps')
    fxi.savefig('fxi.eps')
    fmj.savefig('fmj.eps')
    fmy.savefig('fmj.eps')
    fma.savefig('fma.eps')
