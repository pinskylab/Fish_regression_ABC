# this script simulates stage-structured population sizes in space and time for given parameters and forcin
# functions
from __future__ import print_function, division

# NB for EAM: this runs on Mushu in pipenv, so call pipenv run python fish_abc.py

# import dependencies
import numpy as np
import math as math
import sys
import copy as copy
import statsmodels.api as sm
from sklearn.kernel_ridge import KernelRidge
from numpy.linalg import inv
import scipy.stats as sst
from sklearn import preprocessing
#import matplotlib.pyplot as plt
from statsmodels.iolib.table import (SimpleTable, default_txt_fmt)
from sklearn.linear_model import Ridge
import matplotlib.pyplot as plt

def compute_weight(t, eps, CC):
    if t <= eps:
        return (1. - (t / eps)**2)/eps
    else:
        return 0.


def mean_confidence_interval(A, confidence=0.95):
    a = 1.0 * np.array(A)
    n = len(a)
    m, se = np.mean(a, axis=0), sst.sem(a, axis=0, ddof=1)
    h = se * sst.t.ppf((1 + confidence) / 2., n-1)
    return m, h, m-h, m+h

def confidence_interval(library, weights, stats, resultmanual):
    X = sm.add_constant(stats)
    Y = np.array(library)
    X_T=np.transpose(X)
    W=np.diag(np.array((weights/np.array(weights).sum())))
    n=stats.shape[0]
    p=stats.shape[1]
    y_hat=np.array(np.dot(X, resultmanual))
    var_w=(np.dot(np.dot(np.transpose(Y-y_hat), W), Y-y_hat))/(n-p-1)
    var_WS=np.diag(var_w)
    s_error=(Y-y_hat)**2
    ws_error=np.dot(W, s_error)
    ssw_error=(sum(ws_error))/(n-p-1)
#ssw_error=(sum(ws_error))
    WSSE=ssw_error*(inv(np.dot((np.dot(X_T, W)), X))[0][0])
    WSSE1=var_WS*(inv(np.dot((np.dot(X_T, W)), X))[0][0])
    t_critical=sst.t.ppf((1 + 0.95) / 2., n-p-1)
    h=np.sqrt(WSSE)*t_critical
    h1=np.sqrt(WSSE1)*t_critical
    results=resultmanual[0,:]
    # print(results-h1)
    return results,h, results-h, results+h


def confidence_interval_Kridge(library, weights, stats, resul_coef):
    X = sm.add_constant(stats)
    Y = np.array(library)
    X_T=np.transpose(X)
    #W=np.diag(weights/np.std(weights))
    m, d=stats.shape
    nms=np.sum(np.transpose(stats)**2, axis=0)
    print(2*np.std(stats))
    W=np.exp((-np.transpose(np.matrix(nms))*np.ones((1,m))-np.ones((m,1))*np.matrix(nms)+2*np.dot(stats,np.transpose(stats)))/(2*np.std(stats)))
    #W=np.diag(np.array((weights/np.array(weights).sum())))
    # print(X.shape)
    #print(W.shape)
    #print(X_T.shape)
    n=stats.shape[0]
    p=stats.shape[1]
    y_hat=np.array(np.dot(X, resul_coef))
    #print((Y-y_hat).shape)
    var_w=(np.dot(np.dot(np.transpose(Y-y_hat), W), Y-y_hat))/(n-p-1)
    var_WS=np.diag(var_w)
    s_error=(Y-y_hat)**2
    #print(s_error.shape)
    #print(var_w.shape)
    ws_error=np.dot(W, s_error)
    ssw_error=(sum(ws_error))/(n-p-1)
    #ssw_error=(sum(ws_error))
    #print((np.dot(X_T, W)).shape)
    #print((np.dot((np.dot(X_T, W)), X)).shape)
    #print((inv(np.dot((np.dot(X_T, W)), X)).shape))
    AA_inv=np.array(inv(np.dot((np.dot(X_T, W)), X)))
          #print((inv(np.dot((np.dot(X_T, W)), X))[0][0][0)
    #print(inv(np.dot((np.dot(X_T, W)), X)))
    WSSE=ssw_error*(AA_inv[0][0])
    #WSSE1=var_WS*(inv(np.dot((np.dot(X_T, W)), X))[0][0])
    t_critical=sst.t.ppf((1 + 0.95) / 2., n-p-1)
    h=np.sqrt(WSSE)*t_critical
    #h1=np.sqrt(WSSE1)*t_critical
    results=resul_coef[0]
    #print(results-h1)
    return  results-h, results, results+h

def beta_defs(alpha,mu):
    """ Takes in an alpha shape parameter and the desired mean and returns a value from the beta
    distribution. Note that the mean of a beta distribution, mu, is alpha/(alpha+beta). thus given alpha, and the mean of the parameter, we can use this to compute beta. We do not need this if we decide to use uniform priors"""
    beta = alpha/mu - alpha
    val = np.random.beta(alpha, beta)
    return val


def temp_dependence(temperature, T0, theta_0, width):
    """ Takes in a temperature and the location of the parabolic vertex (T0, theta_0) and the width of
    the parabola and returns the associated temperature dependent rate (theta). Ensure that T0>sqrt of theta0/width
    """
    theta = -width*(temperature-T0)*(temperature-T0) + theta_0
    if theta < 0:
        theta = 0

    return theta


def pop_dynamics(N_B, N_J, N_A, params, alpha, alph):
    """ Intake population sizes for the three population data structure
        for the parameter values; alph(parameter for beta distribution. With uniform priors, we do not need alph), alpha, the temperature dependent growth rate(output of the temp_dependence), fecudity is input separately. N_B is larvae, N_J is juvenille, and N_A is adults. [N_b(t+1)]=[birth]-[conversion to juvenile]. [N_J(t+1)]=[N_B becoming N_J]-[death]-[coversion to N_A]. [N_A(t+1)]=[fraction(f_s) from N_J and those that did not die that stays]-[fraction that leaves to another patch]
    """
    #recruits = beta_defs(alph,params["g_B"])
    #gJval = beta_defs(alph,params["g_J"])
    #nJ_coef = (1 - gJval - beta_defs(alph,params["m_J"]))
    N_J = max(0, N_J)
    N_B = max(0, N_B)
    N_A = max(0, N_A)

    g_B1  = max(0, params["g_B"]*N_B)
    g_J1  = max(0, params["g_J"]*N_J)
    m_J1  = max(0, params["m_J"]*N_J)
    m_A1  = max(0, params["m_A"]*N_A)
    #apha1 = max(0, alpha*N_A)

    #g_alpha1=np.random.poisson(lam=apha1)
    g_B2=np.random.poisson(lam=g_B1)
    g_J2=np.random.poisson(lam=g_J1)
    m_J2=np.random.poisson(lam=m_J1)
    m_A2=np.random.poisson(lam=m_A1)

    g_B2 = min(N_B, g_B2)
    m_J2 = min(N_J, m_J2)
    g_J2 = min(N_J-m_J2, g_J2)
    m_A2 = min(N_A, m_A2)

    nextN_B = N_B -g_B2
    nextN_J = g_B2 + (N_J - g_J2 -m_J2)
    nextN_A = g_J2 + (N_A - m_A2)
    nextN_B = max(0, nextN_B)
    nextN_J = max(0, nextN_J)
    nextN_A = max(0, nextN_A)
    return nextN_B, nextN_J, nextN_A


def movementmovement(pop1,pop2,N_A1,N_A2,alpha1,alpha2, params["f_s"]):
    """ Takes population sizes in two patches, in which a fraction, f_s, of each stays and outputs
    the population sizes in each patch after movement """
    apha1 = max(0, alpha1*N_A1)
    apha2 = max(0, alpha2*N_A2)
    g_alpha1=np.random.poisson(lam=apha1)
    g_alpha2=np.random.poisson(lam=apha2)
    next_pop1 = f_s*(g_alpha1) + (1-f_s)*g_alpha2 + pop1
    next_pop2 = f_s*(g_alpha2) + (1-f_s)*g_alpha1 + pop2

    return next_pop1, next_pop2


def simulation_population(N_B0, N_J0, N_A0, params, T_FINAL, temperatures):
    """ Takes in the initial population sizes and simulates the population size moving forward """
    # Set starting numbers for population and allocate space for population sizes
    N_B = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_B[0] = N_B0
    N_J = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_J[0] = N_J0
    N_A = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_A[0] = N_A0

    for t in range(0,T_FINAL):
        alpha1 = temp_dependence(temperatures[t], params["T0"], params["alpha0"], params["width"])
        alpha2 = temp_dependence(temperatures[t] + params["delta_t"], params["T0"], params["alpha0"], params["width"])

        N_B1, N_J[t+1][0], N_A[t+1][0] = pop_dynamics(N_B[t][0], N_J[t][0], N_A[t][0], params, alpha1, 2)
        N_B2, N_J[t+1][1], N_A[t+1][1] = pop_dynamics(N_B[t][1], N_J[t][1], N_A[t][1], params, alpha2, 2)

        #N_A[t+1][0], N_A[t+1][1] = movement(N_A1,N_A2, params["f_s"])
        N_B[t+1][0], N_B[t+1][1] = movement(N_B1,N_B2,N_A[t][0],N_A[t][1],alpha1,alpha2, params["f_s"])
    
    return N_B, N_J, N_A


def calculate_summary_stats(N_B, N_J, N_A, T_FINAL):
    """Takes in a matrix of time x place population sizes for each stage and calculates summary statistics"""
    time=range(T_FINAL)
    total_adult = N_A.sum(axis=1) # total population in each stage, summed over space
    total_juv   = N_J.sum(axis=1)
    total_larv  = N_B.sum(axis=1)
    #lquartile_adult=np.percentile(total_adult, 25)
    L_Q=np.percentile(time, 25, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    M_Q=np.percentile(time, 50, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    U_Q=np.percentile(time, 75, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    lquartile_adult=total_adult[L_Q]#np.percentile(total_adult, 25)
    median_adult=total_adult[M_Q]#np.percentile(total_adult, 50)
    uquartile_adult=total_adult[U_Q]#np.percentile(total_adult, 75)
    mean_adult=np.mean(total_adult)
    std_adult=np.std(total_adult)
    lquartile_juv=total_juv[L_Q]#np.percentile(total_juv, 25)
    median_juv=total_juv[M_Q]#np.percentile(total_juv, 50)
    uquartile_juv=total_juv[U_Q]#np.percentile(total_juv, 75)
    mean_juv=np.mean(total_juv)
    std_juv=np.std(total_juv)
    lquartile_larv=total_larv[L_Q]#np.percentile(total_larv, 25)
    median_larv=total_larv[M_Q]#np.percentile(total_larv, 50)
    uquartile_larv=total_larv[U_Q]#np.percentile(total_larv, 75)
    mean_larv=np.mean(total_larv)
    std_larv=np.std(total_larv)
    #print('total_adult:', total_adult)
    #print('N_A:', N_A)
    SS_adult=np.hstack((lquartile_adult, median_adult, uquartile_adult))
    SS_juv=np.hstack((lquartile_juv, median_juv, uquartile_juv))
    SS_larv=np.hstack((lquartile_larv, median_larv, uquartile_larv))
    #total_population = total_adult + total_juv + total_larv # total population size in each time
    #print(total_adult)
    # print(lquartile_adult)
    #print(SS_adult)
    #print(mean_adult)
    #sys.exit()
    return SS_adult, SS_juv, SS_larv


def euclidean_distance(vec1, vec2):
    """ Takes two vectors of the same dimensions and calculates the Euclidean distance between the elements"""
    return np.linalg.norm(vec1 - vec2, ord=2)


def small_percent(vector, percent):
    """ Takes a vector and returns the indexes of the elements within the smallest (percent) percent of the vector"""
    sorted_vector = sorted(vector)
    cutoff = math.floor(len(vector)*percent/100) # finds the value which (percent) percent are below
    indexes = []
    print('cutoff:',cutoff)
    cutoff = int(cutoff)
    for i in range(0,len(vector)):
        if vector[i] < sorted_vector[cutoff]: # looks for values below the found cutoff
            indexes.append(i)

    return indexes, sorted_vector[cutoff]


def z_score(x):
    """Takes a list and returns a 0 centered, std = 1 scaled version of the list"""
    st_dev = np.std(x,axis=0)
    mu = np.mean(x,axis=0)
    rescaled_values = []
    for element in range(0,len(x)):
        rescaled_values[element] = (x[element] - mu) / st_dev

    return rescaled_values



def do_kernel_ridge(stats, library,weights):
    #print('X:', X.shape)
    #print('Y:', Y.shape)
    X = sm.add_constant(stats)
    Y=np.array(library)
    clf     = KernelRidge(alpha=1.0, kernel='rbf', coef0=0)
    resul   = clf.fit(X, Y)
    resul_coef=np.dot(X.transpose(), resul.dual_coef_)
    coefficients =resul_coef[0]
    mean_conf=confidence_interval_Kridge(library, weights, stats,resul_coef)
    print(resul_coef.shape)
    print(mean_conf)
    #print('dual :', clf.dual_coef_)
    #print('X    :', X.transpose().shape)
    actual=[0.4, 0.3, 2, 2, 0.9, 4.5, 0.05, 0.05]
    NMSE_ridreg=1-(((np.linalg.norm(actual-coefficients , ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print('Estimates from regression abc using Kernel ridge regression is :', coefficients)
    print('NMSE for kernel Ridge regression  is :', NMSE_ridreg)
    #print('coefficients:', coefficients)


def do_ridge(stats, library):
    X = sm.add_constant(stats)
    Y=np.array(library)
    R = Ridge(alpha=1.0, fit_intercept=False)
    resul_R=R.fit(X, Y)
    actual=[0.4, 0.3, 2, 2, 0.9, 4.5, 0.05, 0.05]
    NMSE_ridge=1-(((np.linalg.norm(actual-np.transpose(resul_R.coef_)[0], ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print('Estimates from regression abc using  ridge regression is :', np.transpose(resul_R.coef_)[0])
    print('NMSE for Ridge  regression  is :', NMSE_ridge)

def print_parameters(params, prefix=''):
    print('%s parameter values:' % prefix, end=' ')
    for name, value in params.items():
        print('%s = %.2f' % (name, value), end='\t')


def do_rejection(library, PARAMS):
    #print_parameters(PARAMS, 'True')

    # compute parameter estimates
    parameter_estimate = np.average(library, axis=0)
    m, h, lo_b, ub_b=mean_confidence_interval(library, confidence=0.95)
    mean_conf_int_para=m, lo_b, ub_b
    print(m)
    print(mean_conf_int_para)
    #print(mean_conf_int_para)
    colnames = ['mean', 'lower bound', 'upper bound']
    rownames = ['g_J', 'g_B', 'alpha0', 'width', 'f_s', 'T0', 'm_J', 'm_A']
    tabl = SimpleTable(np.transpose(mean_conf_int_para), colnames, rownames, txt_fmt=default_txt_fmt)
    print(tabl)
    actual=[0.4, 0.3, 2, 2, 0.9, 4.5, 0.05, 0.05]
    NMSE_rejection=1-(((np.linalg.norm(actual-parameter_estimate, ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print("Estimates from rejection abc:", parameter_estimate)
    print("True parameter values:", PARAMS["g_J"], PARAMS["g_B"],PARAMS["alpha0"], PARAMS["width"], PARAMS["f_s"], PARAMS["T0"], PARAMS["m_J"], PARAMS["m_A"])
    print('NMSE for rejection abc  is :', NMSE_rejection)
    print('\n')
    return  m, h

def do_regression_online(library, weights, stats):
    X = sm.add_constant(stats)
    # try to assemble Y as a vector of vectors? Is this correct?
    Y = np.array(library)

    weigh=np.diag(weights)
    AA=np.transpose([np.linalg.pinv(weigh[:,i,None] * X).dot(Y[:,i]) for i in range(8)])
    actual=[0.4, 0.3, 2, 2, 0.9, 4.5, 0.05, 0.05]
    NMSE_online=1-(((np.linalg.norm(actual-AA[0], ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print("Estimates from formula 1:", AA[0])
    print("True parameter values:", PARAMS["g_J"], PARAMS["g_B"],PARAMS["alpha0"], PARAMS["width"], PARAMS["f_s"], PARAMS["T0"], PARAMS["m_J"], PARAMS["m_A"])
    print('NMSE for online regression  is :', NMSE_online)
def do_regression_manual(library, weights, stats):
    X = sm.add_constant(stats)
    Y = np.array(library)
    X_T=np.transpose(X)
    inv_X=inv(np.mat(X_T)*np.mat(np.diag(np.array((weights/np.array(weights).sum()))))*np.mat(X))
    resultmanual=inv_X*(X_T*np.mat(np.diag(np.array((weights/np.array(weights).sum()))))*Y)
    results=resultmanual[0,:]
    results,h, lo_b1, u_b1=confidence_interval(library, weights, stats, resultmanual)
    mean_conf=results, lo_b1, u_b1
    # print(mean_conf)
    # print(results)
    #print(confidence_interval(library, weights, stats, resultmanual))
    colnames = ['mean', 'lower bound', 'upper bound']
    rownames = ['g_J', 'g_B', 'alpha0', 'width', 'f_s', 'T0', 'm_J', 'm_A']
    tabl = SimpleTable(np.transpose(mean_conf), colnames, rownames, txt_fmt=default_txt_fmt)
    print(tabl)
    actual=[0.4, 0.3, 2, 2, 0.9, 4.5, 0.05, 0.05]
    NMSE_paper=1-(((np.linalg.norm(actual-results, ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print("Estimates from regression abc-manual computation:", results)
    print("True parameter values:", PARAMS["g_J"], PARAMS["g_B"],PARAMS["alpha0"], PARAMS["width"], PARAMS["f_s"], PARAMS["T0"], PARAMS["m_J"], PARAMS["m_A"])
    print('NMSE for paper  is :', NMSE_paper)
    return results,h
        #def do_regression_manual(library, weights, X):
        # Y = library
        #YY=np.array(Y)
        #mean_conf_int = np.c_[vecZZ,con_int]
        ## rownames = ['g_J', 'g_B', 'alpha0', 'width', 'f_s', 'T0', 'm_J', 'm_A']
        #tabl = SimpleTable(mean_conf_int, colnames, rownames, txt_fmt=default_txt_fmt)
        #print(tabl)
    #print( tabl.as_latex_tabular() )
    # print("True parameter values:", PARAMS["g_J"], PARAMS["g_B"],PARAMS["alpha0"], PARAMS["width"], PARAMS["f_s"], PARAMS["T0"], PARAMS["m_J"], PARAMS["m_A"])
#print("Estimates from manula computation is :", AA[0])

def do_local_linear(stats, library, weights,KK):
    # Local-linear regression starts here
    Y = np.array(library)
   
    # define some later used vectors
    ZZ = np.ones(8)
    QQ = np.ones(8)
    con_int =np.ones((8,2))
    con_int1=np.ones((8,2))
    # try a weighted fit. Assemble the matrix X as in the paper
    #X = np.ones((len(stats), len(SO)+1))
    #for i in range(0, len(stats)):
        #print('stats:', stats[i])
        #X[i, 1:len(SO)+1] = stats[i]

    X= sm.add_constant(stats)
    XXX = np.mean(stats, axis=1)
    Xtrial=sm.add_constant(XXX)

    for ii in range(0,8):
         y = Y[:,ii]
         #w=weigh[:,ii]
         mod_wls  = sm.WLS(y, Xtrial, weights=np.array(weights)**2/np.array(weights).sum()**2)
         mod_wls1 = sm.WLS(y, X, weights=np.array(weights)**2/np.array(weights).sum()**2)
         #print(weights)
         res_wls  = mod_wls.fit()
         res_wls1 = mod_wls1.fit()

         con_in   = res_wls.conf_int()
         con_in1   = res_wls1.conf_int()
         con_int[ii, :] =con_in[0]
         con_int1[ii, :] =con_in1[0]
         ZZ[ii]   = res_wls.params[0]
         QQ[ii]   = res_wls1.params[0]


    print("with confidence intervals:", con_int)
    print("Estimates from statsmodels.api   with X 1D is:", ZZ)
    actual=[0.4, 0.3, 2, 2, 0.9, 4.5, 0.05, 0.05]
    NMSE_XoneD=1-(((np.linalg.norm(actual-ZZ, ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print('NMSE python statsmodels.api with X 1D :', NMSE_XoneD)
    print("with confidence intervals:", con_int1)
    print("Estimates from python statsmodels.api with X 2D is:", QQ)
    actual=[0.4, 0.3, 2, 2, 0.9, 4.5, 0.05, 0.05]
    NMSE_XtwoD=1-(((np.linalg.norm(actual-QQ, ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print('NMSE python statsmodels.api with X 2D is :', NMSE_XtwoD)
    print("True parameter values:", PARAMS["g_J"], PARAMS["g_B"],PARAMS["alpha0"], PARAMS["width"], PARAMS["f_s"], PARAMS["T0"], PARAMS["m_J"], PARAMS["m_A"])

def run_sim(PARAMS, NUMBER_SIMS):
    PARAMS_ABC = copy.deepcopy(PARAMS) # copies parameters so new values can be generated; FIX ME! this is a redirect, not a copy?
    param_save = [] # sets an initial 0; fixed to [] because [[]] made the mean go poorly (averaging in an [] at start?)

    print_parameters(PARAMS, prefix='True')

    # Sets temperatures at each patch over time [FIX THIS]
    temperatures = [3.6,3.8,4,4.2,4.4,4.6,4.8,5,5.2,5.4]

    # Simulates population
    N_B, N_J, N_A = simulation_population(N0, N0, N0, PARAMS, T_FINAL, temperatures)

    SS_adult, SS_juv, SS_larv= calculate_summary_stats(N_B, N_J, N_A, T_FINAL)
    SO=np.hstack((SS_adult, SS_juv, SS_larv))
    Obs_Sim=np.zeros((NUMBER_SIMS+1,len(SO)))
    Obs_Sim[0,:]=SO

    for i in range(0,NUMBER_SIMS):
        g_B_theta    = np.random.uniform(0,1) #np.random.beta(2,2)
        g_J_theta    = np.random.uniform(0,1)#np.random.beta(2,2)
        alpha0_theta = np.random.uniform(0,4) #np.random.lognormal(1,1)
        width_theta  = np.random.uniform(1,5)#np.random.lognormal(1,1)
        f_s_theta    = np.random.uniform(0,1)
        T0_theta     = np.random.uniform(3.5,5.5)#np.random.normal(0,0.5)
        m_J_theta    = np.random.uniform(0,1) #np.random.beta(2,2)
        m_A_theta    = np.random.uniform(0,1)#np.random.beta(2,2)

        PARAMS_ABC["g_J"]    = g_J_theta # sets the g_J parameter to our random guess
        PARAMS_ABC["alpha0"] = alpha0_theta
        PARAMS_ABC["width"]  = width_theta
        PARAMS_ABC["f_s"]    = f_s_theta
        PARAMS_ABC["g_G"]    = g_B_theta
        PARAMS_ABC["T0"]     = T0_theta
        PARAMS_ABC["m_J"]    = m_J_theta
        PARAMS_ABC["m_A"]    = m_A_theta

        # Simulate population for new parameters
        N_B_sim, N_J_sim, N_A_sim = simulation_population(N0,N0,N0, PARAMS_ABC, T_FINAL, temperatures) # simulates population with g_J value

        # Calculate the summary statistics for the simulation
        Sim_SS_adult, Sim_SS_juv, Sim_SS_larv= calculate_summary_stats(N_B_sim, N_J_sim, N_A_sim, T_FINAL)
        SS=np.hstack((Sim_SS_adult, Sim_SS_juv, Sim_SS_larv))
        Obs_Sim[i+1,:]=SS

        param_save.append([g_J_theta, g_B_theta, alpha0_theta, width_theta, f_s_theta, T0_theta, m_J_theta, m_A_theta])

    return np.asarray(param_save), Obs_Sim


def compute_scores(dists, param_save, difference, c):
    eps=0.01
    library_index, eps = small_percent(dists, eps)
    n                = len(library_index)
    library, weights, Ker_vec = np.empty((n, param_save.shape[1])), np.empty(n), np.empty(n)
    stats            = np.empty((n, difference.shape[1]))
    

    for i in range(0,len(library_index)):
        j = library_index[i]
        CC=c[j]
        weights[i] = compute_weight(dists[j], eps, CC)
        library[i] = param_save[j]
        stats[i]   = difference[j]
        Ker_vec[i]=dists[j]
    KK=np.exp(-np.power(Ker_vec,2)/(2*np.std(Ker_vec)**2))
    return library, weights, stats, KK


def sum_stats(Obs_Sim, param_save, NUMBER_SIMS):
    dists = np.zeros((NUMBER_SIMS,1))
    #Obs_Sim_scale=np.nan_to_num(sst.zscore(Obs_Sim, axis=0,ddof=1),copy=True)
    Obs_Sim_scale=np.nan_to_num(preprocessing.normalize(Obs_Sim, axis=0),copy=True)
    #Substract each row of teh array from row 1
    difference=Obs_Sim_scale[1:NUMBER_SIMS+1,: ]-Obs_Sim_scale[0,:]
    c=np.std(Obs_Sim_scale[1:NUMBER_SIMS+1,: ], axis=1)
    # compute the norm 2 of each row
    dists = np.linalg.norm(difference, axis=1)

    library, weights, stats, KK = compute_scores(dists, param_save, difference,c)
    return library, weights, stats, KK


def do_regression(library, stats, PARAMS):

    # REJECTION
    print('\nDo a rejection ABC:')
    do_rejection(library, PARAMS)

    #print('\nStats:', stats.shape)
    #print('\nStats:', stats)
    #print('\nLibar:', library.shape)
    #print('\nLibar:', library)

    do_kernel_ridge(stats, library)
    do_ridge(stats, library)


if __name__ == '__main__':
    # Sets parameters
    PARAMS = {"alpha0": 2, "T0": 4.5, "width": 2, "g_B": .3, "g_J": .4, "m_J": .05, "m_A": .05, "f_s": .9, "delta_t":2, "lam":1}
    T_FINAL = 10
    LANDSCAPE_LEN = 2
    N0 = 5
    NUMBER_SIMS = 200000

    param_save, Obs_Sim         = run_sim(PARAMS, NUMBER_SIMS)
    library, weights, stats, KK     = sum_stats(Obs_Sim, param_save, NUMBER_SIMS)
    m, h1=do_rejection(library, PARAMS)
    results,h=do_regression_manual(library, weights, stats)
    
    regression_gj = np.linspace(results[0,0] - 3*h[0], results[0,0] + 3*h[0], 1000)
    regression_gb = np.linspace(results[0,1] - 3*h[1], results[0,1] + 3*h[1], 1000)
    regression_apha0 = np.linspace(results[0,2] - 3*h[2], results[0,2] + 3*h[2], 1000)
    regression_w = np.linspace(results[0,3] - 3*h[3], results[0,3] + 3*h[3], 1000)
    regression_fs = np.linspace(results[0,4] - 3*h[4], results[0,4] + 3*h[4], 1000)
    regression_T0 = np.linspace(results[0,5] - 3*h[5], results[0,5] + 3*h[5], 1000)
    regression_mj = np.linspace(results[0,6] - 3*h[6], results[0,6] + 3*h[6], 1000)
    regression_ma = np.linspace(results[0,7] - 3*h[7], results[0,7] + 3*h[7], 1000)
    rejection_gj = np.linspace(m[0] - 3*h1[0], m[0] + 3*h1[0], 1000)
    rejection_gb = np.linspace(m[1] - 3*h1[1], m[1] + 3*h1[1], 1000)
    rejection_apha0 = np.linspace(m[2] - 3*h1[2], m[2] + 3*h1[2], 1000)
    rejection_w = np.linspace(m[3] - 3*h1[3], m[3] + 3*h1[3], 1000)
    rejection_fs = np.linspace(m[4] - 3*h1[4], m[4] + 3*h1[4], 1000)
    rejection_T0 = np.linspace(m[5] - 3*h1[5], m[5] + 3*h1[5], 1000)
    rejection_mj = np.linspace(m[6] - 3*h1[6], m[6] + 3*h1[6], 1000)
    rejection_ma = np.linspace(m[7] - 3*h1[7], m[7] + 3*h1[7], 1000)
    fgj, (axgj1, axgj2) = plt.subplots(1, 2, sharey=True)
    fgb, (axgb1, axgb2) = plt.subplots(1, 2, sharey=True)
    falpha0, (axalpha01, axalpha02) = plt.subplots(1, 2, sharey=True)
    fw, (axw1, axw2) = plt.subplots(1, 2, sharey=True)
    ffs, (axfs1, axfs2) = plt.subplots(1, 2, sharey=True)
    fT0, (axT1, axT2) = plt.subplots(1, 2, sharey=True)
    fmj, (axmj1, axmj2) = plt.subplots(1, 2, sharey=True)
    fma, (axma1, axma2) = plt.subplots(1, 2, sharey=True)
    axgj1.plot(regression_gj,sst.norm(results[0,0], h[0]).pdf(regression_gj),'k-', linewidth=4 )
    axgj2.plot(rejection_gj,sst.norm(m[0], h1[0]).pdf(rejection_gj),'k-', linewidth=4 )
    axgb1.plot(regression_gb,sst.norm(results[0,1], h[1]).pdf(regression_gb),'k-', linewidth=4 )
    axgb2.plot(rejection_gb,sst.norm(m[1], h1[1]).pdf(rejection_gb),'k-', linewidth=4 )
    axalpha01.plot(regression_apha0,sst.norm(results[0,2], h[2]).pdf(regression_apha0),'k-', linewidth=4 )
    axalpha02.plot(rejection_apha0,sst.norm(m[2], h1[2]).pdf(rejection_apha0),'k-', linewidth=4 )
    axw1.plot(regression_w,sst.norm(results[0,3], h[3]).pdf(regression_w),'k-', linewidth=4 )
    axw2.plot(rejection_w,sst.norm(m[3], h1[3]).pdf(rejection_w),'k-', linewidth=4 )
    axfs1.plot(regression_fs,sst.norm(results[0,4], h[4]).pdf(regression_fs),'k-', linewidth=4 )
    axfs2.plot(rejection_fs,sst.norm(m[4], h1[4]).pdf(rejection_fs),'k-', linewidth=4 )
    axT1.plot(regression_T0,sst.norm(results[0,5], h[5]).pdf(regression_T0),'k-', linewidth=4 )
    axT2.plot(rejection_T0,sst.norm(m[5], h1[5]).pdf(rejection_T0),'k-', linewidth=4 )
    axmj1.plot(regression_mj,sst.norm(results[0,6], h[6]).pdf(regression_mj),'k-', linewidth=4 )
    axmj2.plot(rejection_mj,sst.norm(m[6], h1[6]).pdf(rejection_mj),'k-', linewidth=4 )
    axma1.plot(regression_ma,sst.norm(results[0,7], h[7]).pdf(regression_ma),'k-', linewidth=4 )
    axma2.plot(rejection_ma,sst.norm(m[7], h1[7]).pdf(rejection_ma),'k-', linewidth=4 )
    ubgj1=results[0,0]+h[0]
    lbgj1=results[0,0]-h[0]
    ubgj2=m[0]+h1[0]
    lbgj2=m[0]-h1[0]
    ubgb1=results[0,1]+h[1]
    lbgb1=results[0,1]-h[1]
    ubgb2=m[1]+h1[1]
    lbgb2=m[1]-h1[1]
    ubal1=results[0,2]+h[2]
    lbal1=results[0,2]-h[2]
    ubal2=m[2]+h1[2]
    lbal2=m[2]-h1[2]
    ubw1=results[0,3]+h[3]
    lbw1=results[0,3]-h[3]
    ubw2=m[3]+h1[3]
    lbw2=m[3]-h1[3]
    ubfs1=results[0,4]+h[4]
    lbfs1=results[0,4]-h[4]
    ubfs2=m[4]+h1[4]
    lbfs2=m[4]-h1[4]
    ubT1=results[0,5]+h[5]
    lbT1=results[0,5]-h[5]
    ubT2=m[5]+h1[5]
    lbT2=m[5]-h1[5]
    ubmj1=results[0,6]+h[6]
    lbmj1=results[0,6]-h[6]
    ubmj2=m[6]+h1[6]
    lbmj2=m[6]-h1[6]
    ubma1=results[0,7]+h[7]
    lbma1=results[0,7]-h[7]
    ubma2=m[7]+h1[7]
    lbma2=m[7]-h1[7]
    axgj1.fill_between(regression_gj, 0, sst.norm(results[0,0], h[0]).pdf(regression_gj), where = (regression_gj<=ubgj1) & (regression_gj>=lbgj1))
    axgj1.vlines(PARAMS["g_J"], 0,sst.norm(results[0,0], h[0]).pdf(PARAMS["g_J"]) , colors='r', linewidth=4)
    axgj1.set_ylabel('Probability density')
    axgj1.set_xlabel(r'$g_J$')
    axgj2.fill_between(rejection_gj, 0, sst.norm(m[0], h1[0]).pdf(rejection_gj), where = (rejection_gj<=ubgj2) & (rejection_gj>=lbgj2))
    axgj2.vlines(PARAMS["g_J"], 0,sst.norm(m[0], h1[0]).pdf(PARAMS["g_J"]) , colors='r', linewidth=4)
    axgj2.set_xlabel(r'$g_J$')

    axgb1.fill_between(regression_gb, 0, sst.norm(results[0,1], h[1]).pdf(regression_gb), where = (regression_gb<=ubgb1) & (regression_gb>=lbgb1))
    axgb1.vlines(PARAMS["g_B"], 0,sst.norm(results[0,1], h[1]).pdf(PARAMS["g_B"]) , colors='r', linewidth=4)
    axgb1.set_ylabel('Probability density')
    axgb1.set_xlabel(r'$g_B$')
    axgb2.fill_between(rejection_gb, 0, sst.norm(m[1], h1[1]).pdf(rejection_gb), where = (rejection_gb<=ubgb2) & (rejection_gb>=lbgb2))
    axgb2.vlines(PARAMS["g_B"], 0,sst.norm(m[1], h1[1]).pdf(PARAMS["g_B"]) , colors='r', linewidth=4)
    axgb2.set_xlabel(r'$g_B$')

    axalpha01.fill_between(regression_apha0, 0, sst.norm(results[0,2], h[2]).pdf(regression_apha0), where = (regression_apha0<=ubal1) & (regression_apha0>=lbal1))
    axalpha01.vlines(PARAMS["alpha0"], 0,sst.norm(results[0,2], h[2]).pdf(PARAMS["alpha0"]) , colors='r', linewidth=4)
    axalpha01.set_ylabel('Probability density')
    axalpha01.set_xlabel(r'$\alpha_0$')
    axalpha02.fill_between(rejection_apha0, 0, sst.norm(m[2], h1[2]).pdf(rejection_apha0), where = (rejection_apha0<=ubal2) & (rejection_apha0>=lbal2))
    axalpha02.vlines(PARAMS["alpha0"], 0,sst.norm(m[2], h1[2]).pdf(PARAMS["alpha0"]) , colors='r', linewidth=4)
    axalpha02.set_xlabel(r'$\alpha_0$')

    axw1.fill_between(regression_w, 0, sst.norm(results[0,3], h[3]).pdf(regression_w), where = (regression_w<=ubw1) & (regression_w>=lbw1))
    axw1.vlines(PARAMS["width"], 0,sst.norm(results[0,3], h[3]).pdf(PARAMS["width"]) , colors='r', linewidth=4)
    axw1.set_ylabel('Probability density')
    axw1.set_xlabel(r'$w$')
    axw2.fill_between(rejection_w, 0, sst.norm(m[3], h1[3]).pdf(rejection_w), where = (rejection_w<=ubw2) & (rejection_w>=lbw2))
    axw2.vlines(PARAMS["width"], 0,sst.norm(m[3], h1[3]).pdf(PARAMS["width"]) , colors='r', linewidth=4)
    axw2.set_xlabel(r'$w$')

    axfs1.fill_between(regression_fs, 0, sst.norm(results[0,4], h[4]).pdf(regression_fs), where = (regression_fs<=ubfs1) & (regression_fs>=lbfs1))
    axfs1.vlines(PARAMS["f_s"], 0,sst.norm(results[0,4], h[4]).pdf(PARAMS["f_s"]) , colors='r', linewidth=4)
    axfs1.set_ylabel('Probability density')
    axfs1.set_xlabel(r'$f_s$')
    axfs2.fill_between(rejection_fs, 0, sst.norm(m[4], h1[4]).pdf(rejection_fs), where = (rejection_fs<=ubfs2) & (rejection_gb>=lbfs2))
    axfs2.vlines(PARAMS["f_s"], 0,sst.norm(m[4], h1[4]).pdf(PARAMS["f_s"]) , colors='r', linewidth=4)
    axfs2.set_xlabel(r'$f_s$')

    axT1.fill_between(regression_T0, 0, sst.norm(results[0,5], h[5]).pdf(regression_T0), where = (regression_T0<=ubT1) & (regression_T0>=lbT1))
    axT1.vlines(PARAMS["T0"], 0,sst.norm(results[0,5], h[5]).pdf(PARAMS["T0"]) , colors='r', linewidth=4)
    axT1.set_ylabel('Probability density')
    axT1.set_xlabel(r'$T_0$')
    axT2.fill_between(rejection_T0, 0, sst.norm(m[5], h1[5]).pdf(rejection_T0), where = (rejection_T0<=ubT2) & (rejection_T0>=lbT2))
    axT2.vlines(PARAMS["T0"], 0,sst.norm(m[5], h1[5]).pdf(PARAMS["T0"]) , colors='r', linewidth=4)
    axT2.set_xlabel(r'$T_0$')

    axmj1.fill_between(regression_mj, 0, sst.norm(results[0,6], h[6]).pdf(regression_mj), where = (regression_mj<=ubmj1) & (regression_mj>=lbmj1))
    axmj1.vlines(PARAMS["m_J"], 0,sst.norm(results[0,6], h[6]).pdf(PARAMS["m_J"]) , colors='r', linewidth=4)
    axmj1.set_ylabel('Probability density')
    axmj1.set_xlabel(r'$m_J$')
    axmj2.fill_between(rejection_mj, 0, sst.norm(m[6], h1[6]).pdf(rejection_mj), where = (rejection_mj<=ubmj2) & (rejection_mj>=lbmj2))
    axmj2.vlines(PARAMS["m_J"], 0,sst.norm(m[6], h1[6]).pdf(PARAMS["m_J"]) , colors='r', linewidth=4)
    axmj2.set_xlabel(r'$m_J$')

    axma1.fill_between(regression_ma, 0, sst.norm(results[0,7], h[7]).pdf(regression_ma), where = (regression_ma<=ubma1) & (regression_ma>=lbma1))
    axma1.vlines(PARAMS["m_A"], 0,sst.norm(results[0,7], h[7]).pdf(PARAMS["m_A"]) , colors='r', linewidth=4)
    axma1.set_ylabel('Probability density')
    axma1.set_xlabel(r'$m_A$')
    axma2.fill_between(rejection_ma, 0, sst.norm(m[7], h1[7]).pdf(rejection_ma), where = (rejection_ma<=ubma2) & (rejection_ma>=lbma2))
    axma2.vlines(PARAMS["m_A"], 0,sst.norm(m[7], h1[7]).pdf(PARAMS["m_A"]) , colors='r', linewidth=4)
    axma2.set_xlabel(r'$m_A$')

    fgj.savefig('fgj.eps')
    fgb.savefig('fgb.eps')
    falpha0.savefig('falpha0.eps')
    fw.savefig('fwidth.eps')
    ffs.savefig('ffs.eps')
    fT0.savefig('fT0.eps')
    fmj.savefig('fmj.eps')
    fma.savefig('fma.eps')

