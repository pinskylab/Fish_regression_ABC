# this script simulates stage-structured population sizes in space and time for given parameters and forcin
# functions
from __future__ import print_function, division

import numpy as np
import math as math
import random as random
import sys
import copy as copy
from scipy.stats import norm
import statsmodels.api as sm
from scipy import stats
from numpy.linalg import inv
import pymc3
import scipy.stats as sst
from sklearn import preprocessing
#import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.kernel_ridge import KernelRidge
############################################################################################
######################


def temp_dependence(temperature, Topt, width, kopt):
    """ compute growth rate as a function of temperature, were kopt is the optimal growth rate, Topt, optimal temperature, width, the standard deviation from the optimal temperature.
        """
    #theta = -width*(temperature-Topt)*(temperature-Topt) + kopt
    theta = kopt*np.exp(-0.5*np.square((temperature-Topt)/width))
    #theta=((temperature-Tmin)*(temperature-Tmax))/(((temperature-Tmin)*(temperature-Tmax))-(temperature-Topt))
    return theta
#############################################################################

def simulation_population(params):
    """ Takes in the initial population sizes and simulates the population size moving forward """
    # Set starting numbers for population and allocate space for population sizes
    N_JS = np.ndarray(shape=(rows, cols), dtype=float, order='F')
    alpha=N_JS.copy()
    N_YS=N_JS.copy()
    N_AS=N_JS.copy()
    for x in range(0, cols):
        alpha[:,x]=temp_dependence(tempA[:,x],  params["Topt"], params["width"], params["kopt"])
    N_JS[0,:]=N_J[0,:]
    N_YS[0,:]=N_Y[0,:]
    N_AS[0,:]=N_A[0,:]
    #N_Y = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    #N_Y[0] = N_Y0
    #N_A = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    #N_A[0] = N_A0
    L_bJ=params["L_inf"]-(params["L_inf"]-params["L_J"])*np.exp(alpha)
    L_bY=params["L_inf"]-(params["L_inf"]-params["L_Y"])*np.exp(alpha)
    g_J=(params["L_J"]-L_bJ)/(params["L_J"]-params["L_0"])
    g_Y=(params["L_Y"]-L_bY)/(params["L_Y"]-params["L_J"])
    for t in range(0,rows-1):
        #boundary values
        N_JS[t+1,0]=max(0,(1-params["m_J"])*N_JS[t,0]+N_AS[t,0]*np.exp(params["r"]*(1-N_AS[t,0]/params["K"]))-g_J[t,0]*N_JS[t,0])
        N_JS[t+1,cols-1]=max(0,(1-params["m_J"])*N_JS[t,cols-1]+N_AS[t,cols-1]*np.exp(params["r"]*(1-N_AS[t,cols-1]/params["K"]))-g_J[t,cols-1]*N_JS[t,cols-1])
        N_YS[t+1, 0] = max(0,(1-params["m_Y"])*N_YS[t,0]+g_J[t,0]*N_JS[t,0]-g_Y[t,0]*N_YS[t,0])
        N_YS[t+1, cols-1] = max(0,(1-params["m_Y"])*N_YS[t,cols-1]+g_J[t, cols-1]*N_JS[t,cols-1]-g_Y[t,cols-1]*N_YS[t,cols-1])
        
        N_AS[t+1, 0]=max(0,(1-params["m_A"])*N_AS[t,0]+g_Y[t,0]*N_YS[t,0]-params["xi"]*N_AS[t,0]+ params["xi"]*N_AS[t,1])
        N_AS[t+1, cols-1]=max(0,(1-params["m_A"])*N_AS[t,cols-1]+g_Y[t,cols-1]*N_YS[t,cols-1]-params["xi"]*N_AS[t,cols-1]+ params["xi"]*N_AS[t,cols-2])
        for x in range(1, cols-1):
            N_JS[t+1, x]=max(0,(1-params["m_J"])*N_JS[t,x]+N_AS[t,x]*np.exp(params["r"]*(1-N_AS[t,x]/params["K"]))-g_J[t,x]*N_JS[t,x])
            N_YS[t+1, x] = max(0,(1-params["m_Y"])*N_YS[t,x]+g_J[t,x]*N_JS[t,x]-g_Y[t,x]*N_YS[t,x])
            N_AS[t+1, x]=max(0,(1-params["m_A"])*N_AS[t,x]+g_Y[t,x]*N_YS[t,x]-2*params["xi"]*N_AS[t,x]+ params["xi"]*N_AS[t,x+1]+params["xi"]*N_AS[t,x-1])
    return N_JS, N_YS, N_AS


##################################################################################################################################################################

def calculate_summary_stats(N_J, N_Y, N_A):
    """Takes in a matrix of time x place population sizes for each stage and calculates summary statistics"""
    time=range(T_FINAL)
    L_Q1=np.percentile(time, 5, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    L_Q=np.percentile(time, 25, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    M_Q=np.percentile(time, 50, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    M_Q1=np.percentile(time,60, axis=None, out=None, overwrite_input=False,interpolation='nearest')
    U_Q=np.percentile(time, 75, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    U_Q1=np.percentile(time, 80, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    U_Q2=np.percentile(time, 85, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    U_Q3=np.percentile(time, 90, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    U_Q4=np.percentile(time,95, axis=None, out=None, overwrite_input=False,interpolation='nearest')
    U_Q5=np.percentile(time, 97, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    U_Q6=np.percentile(time, 99, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    SS_adult1=np.hstack((N_A[L_Q1], N_A[L_Q], N_A[M_Q],N_A[M_Q1], N_A[U_Q],N_A[U_Q1],N_A[U_Q2],N_A[U_Q3],N_A[U_Q4], N_A[U_Q5], N_A[U_Q6]))#np.std(N_A, axis=0), np.mean(N_A, axis=0), sst.skew(N_A, axis=0, bias=True),
    SS_young1=np.hstack((N_Y[L_Q1], N_Y[L_Q], N_Y[M_Q],N_Y[M_Q1], N_Y[U_Q],N_Y[U_Q1], N_Y[U_Q2], N_Y[U_Q3], N_Y[U_Q4], N_Y[U_Q5], N_Y[U_Q6]))#np.std(N_Y, axis=0), np.mean(N_Y, axis=0), bias=True),
    SS_juv1=np.hstack((N_J[L_Q1], N_J[L_Q], N_J[M_Q],N_J[M_Q1], N_J[U_Q],N_J[U_Q1], N_J[U_Q2], N_J[U_Q3], N_J[U_Q4], N_J[U_Q5], N_J[U_Q6]))#np.std(N_J, axis=0), np.mean(N_J, axis=0), axis=0, bias=True),
    #SS_adult1=np.hstack((N_A[L_Q1], N_A[L_Q], N_A[M_Q],N_A[M_Q1], N_A[U_Q], N_A[U_Q4]))
    #SS_young1=np.hstack((N_Y[L_Q1], N_Y[L_Q], N_Y[M_Q],N_Y[M_Q1], N_Y[U_Q], N_Y[U_Q4]))
    #SS_juv1=np.hstack(( N_Y[L_Q1], N_Y[L_Q], N_Y[M_Q],N_Y[M_Q1], N_Y[U_Q], N_Y[U_Q4]))
    return SS_adult1, SS_young1, SS_juv1
##############################################################################################################################

def small_percent(vector, percent):
    """ Takes a vector and returns the indexes of the elements within the smallest (percent) percent of the vector"""
    sorted_vector = sorted(vector)
    cutoff = math.floor(len(vector)*percent/100) # finds the value which (percent) percent are below
    indexes = []
    #print('cutoff:',cutoff)
    cutoff = int(cutoff)
    for i in range(0,len(vector)):
        if vector[i] < sorted_vector[cutoff]: # looks for values below the found cutoff
            indexes.append(i)

    return indexes, sorted_vector[cutoff]


def z_score(x):
    """Takes a list and returns a 0 centered, std = 1 scaled version of the list"""
    st_dev = np.std(x,axis=0)
    mu = np.mean(x,axis=0)
    rescaled_values = []
    for element in range(0,len(x)):
        rescaled_values[element] = (x[element] - mu) / st_dev

    return rescaled_values

############################
# this function transform the paramters using logit function. the aim is to ensure that we do not end up with a parameter out of the prior
def do_logit_transformation(library, param_bound):
    for i in range(len(library[0,:])):
        library[:,i]=(library[:,i]-param_bound[i,0])/(param_bound[i,1]-param_bound[i,0])
        library[:,i]=np.log(library[:,i]/(1-library[:,i]))
    return library
###########################
#this function back transform parameter values
def do_ivlogit_transformation(para_reg, param_bound):
    for i in range(len(library[0,:])):
        para_reg[:,i]=np.exp(para_reg[:,i])/(1+np.exp(para_reg[:,i]))
        para_reg[:,i]=para_reg[:,i]*(param_bound[i,1]-param_bound[i,0])+param_bound[i,0]
    return para_reg
############################

def do_kernel_ridge(stats, library, param_bound):
    #print('X:', X.shape)
    #print('Y:', Y.shape)
    #'rbf'
    X = sm.add_constant(stats)
    Y=library
    clf     = KernelRidge(alpha=1.0, kernel='rbf', coef0=1)
    resul   = clf.fit(X, Y)
    resul_coef=np.dot(X.transpose(), resul.dual_coef_)
    coefficients =resul_coef[1:]
    #mean_conf=confidence_interval_Kridge(logit(library), weights, stats,resul_coef)
    para_reg   =Y- stats.dot(coefficients)
    para_reg=do_ivlogit_transformation(para_reg, param_bound)
    #param_SS[:,ii]   =Y[:,ii]- inv_logit(res_wls_SS.params[1:])+inv_logit(res_wls_OS.params[1:])
    parameter_estimate = np.average(para_reg, axis=0)
    HPDR=pymc3.stats.hpd(para_reg)
    return parameter_estimate, HPDR
    #NMSE_ridreg=1-(((np.linalg.norm(actual-coefficients , ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    #print('Estimates from regression abc using Kernel ridge regression is :', parameter_estimate)
#print('Estimates HPDR using Kernel ridge regression is :', HPDR)
# print('NMSE for kernel Ridge regression  is :', NMSE_ridreg)
    #print('coefficients:', coefficients)
##############################################################################################
def do_rejection(library):
    parameter_estimate = np.average(library, axis=0)
    HPDR=pymc3.stats.hpd(library)
    return parameter_estimate, HPDR
    # print('library is:', library)
    #print('Estimates from rejection is:', parameter_estimate)
#print('Estimates HPDR from rejection is :', HPDR)

    #####################################################################################
#return all the observe summaery statitics (OS)and simulated summary statistics (SS) in a matrix with first row corresponding to OS and the rest of the rows to SS
def run_sim():
    PARAMS_ABC = {}# copies parameters so new values can be generated; FIX ME! this is a redirect, not a copy?
    param_save = [] # sets an initial 0; fixed to [] because [[]] made the mean go poorly (averaging in an [] at start?)
    
    #print_parameters(PARAMS, prefix='True')
    # N_J, N_Y, N_A = abc_example.species3(param_actual,temp1, T_FINAL, no_patches,N_J0, N_Y0,N_A0)
    SS_adult, SS_young, SS_juv= calculate_summary_stats(N_J, N_Y, N_A)
    SO=np.hstack((SS_adult, SS_young, SS_juv))
    Obs_Sim=np.zeros((NUMBER_SIMS+1,len(SO)))
    Obs_Sim[0,:]=SO
    for i in range(0,NUMBER_SIMS):
        L_0_theta    = np.random.uniform(0,1)#np.random.normal(0.4,0.3) #np.random.beta(2,2)
        #L_inf_theta    =np.random.uniform(18,23)
        #L_J_theta=np.random.uniform(4, 6)
        #L_Y_theta=np.random.uniform(8, 12)
        #np.random.uniform(0,1)#np.random.beta(2,2)
        Topt_theta =np.random.uniform(4,9)#np.random.normal(6.5,2) #np.random.uniform(1,12) #np.random.lognormal(1,1)
        width_theta  =np.random.uniform(1,4)#np.random.normal(2,1)
        ##np.random.lognormal(1,1)
        kopt_theta    =np.random.uniform(0,1)#np.random.normal(0.5,0.4)# np.random.u(0,1)
        xi_theta     =np.random.uniform(0,0.5)#np.random.normal(0.1,0.09) #np.random.normal(0,1)#np.random.normal(0,0.5)
        r_theta     =np.random.uniform(0,1)
        m_J_theta    =np.random.uniform(0,1)#np.random.normal(0.04,0.04) # #np.random.beta(2,2)
        m_Y_theta    =np.random.uniform(0,1)#np.random.normal(0.05,0.04) #np.random.uniform(0,1) #np.random.beta(2,2)
        m_A_theta    =np.random.uniform(0,1)#np.random.normal(0.05,0.05)# np.random.uniform(0,1)#np.random.beta(2,2)
        K_theta= np.random.uniform(100,10000)
        PARAMS_ABC["L_0"]    = L_0_theta # sets the g_J parameter to our random guess
        PARAMS_ABC["L_inf"]    = 76
        PARAMS_ABC["L_J"]    = 12
        PARAMS_ABC["L_Y"]    = 23
        PARAMS_ABC["Topt"] = Topt_theta
        PARAMS_ABC["width"]  = width_theta
        PARAMS_ABC["kopt"]    = kopt_theta
        PARAMS_ABC["xi"]     = xi_theta
        PARAMS_ABC["r"]     = r_theta
        PARAMS_ABC["m_J"]    = m_J_theta
        PARAMS_ABC["m_Y"]    = m_Y_theta
        PARAMS_ABC["m_A"]    = m_A_theta
        PARAMS_ABC["K"]    = K_theta
        # Simulate population for new parameters
        N_J_sim, N_Y_sim, N_A_sim = simulation_population(PARAMS_ABC) # simulates population with g_J value
        
        # Calculate the summary statistics for the simulation
        Sim_SS_adult, Sim_SS_young, Sim_SS_juv= calculate_summary_stats(N_J_sim, N_Y_sim, N_A_sim)
        SS=np.hstack((Sim_SS_adult, Sim_SS_young, Sim_SS_juv))
        Obs_Sim[i+1,:]=SS
        
        param_save.append([L_0_theta, Topt_theta, width_theta, kopt_theta, xi_theta, r_theta, m_J_theta,m_Y_theta, m_A_theta, K_theta])
    
    return np.asarray(param_save), Obs_Sim
#########################################################################################
#return all  all parameters (library) and simulated  NSS (stats) corresponding to d ≤ δ(eps).
def compute_scores(dists, param_save, difference,Sim_SS):
    eps=0.001
    library_index, NSS_cutoff = small_percent(dists, eps)
    n                = len(library_index)
    library = np.empty((n, param_save.shape[1]))
    stats            = np.empty((n, difference.shape[1]))
    stats_SS            = np.empty((n, difference.shape[1]))
    

    for i in range(0,len(library_index)):
        j = library_index[i]
        library[i] = param_save[j]
        stats[i]   = difference[j]
        stats_SS[i]   = Sim_SS[j]
    return library, stats, NSS_cutoff, library_index, stats_SS
##########################################################################################
#computes weights for local regression

def compute_weight(kernel,t, eps, index):
     weights=np.empty(len(index))
     if (kernel == "epanechnikov"):
         for i in range(0,len(library_index)):
             j = library_index[i]
     #weights[i]= (1. - (t[j] / eps)**2)
             weights[i]=(1. - (t[j] / eps)**2)
     elif(kernel == "rectangular"):
          for i in range(0,len(library_index)):
              j = library_index[i]
              weights[i]=t[j] / eps
     elif (kernel == "gaussian"):
          for i in range(0,len(library_index)):
              j = library_index[i]
              weights[i]= 1/np.sqrt(2*np.pi)*np.exp(-0.5*(t[j]/(eps/2))**2)
            
     elif (kernel == "triangular"):
          for i in range(0,len(library_index)):
              j = library_index[i]
              weights[i]= 1 - np.abs(t[j]/eps)
     elif (kernel == "biweight"):
          for i in range(0,len(library_index)):
              j = library_index[i]
              weights[i]=(1 - (t[j]/eps)**2)**2
     else:
          for i in range(0,len(library_index)):
              j = library_index[i]
              weights[i]= np.cos(np.pi/2*t[j]/eps)
     return weights
###########################################################################################

def sum_stats(Obs_Sim, param_save):
    dists = np.zeros((NUMBER_SIMS,1))
    #Obs_Sim_scale=np.nan_to_num(sst.zscore(Obs_Sim, axis=0,ddof=1),copy=True)
    Obs_Sim_scale=np.nan_to_num(preprocessing.normalize(Obs_Sim, axis=0),copy=True)
    #Substract each row of teh array from row 1
    Sim_SS=Obs_Sim_scale[1:NUMBER_SIMS+1,: ]
    Obs_SS=Obs_Sim_scale[0,:]
    difference=Obs_Sim_scale[1:NUMBER_SIMS+1,: ]-Obs_Sim_scale[0,:]
    #c=np.std(Obs_Sim_scale[1:NUMBER_SIMS+1,: ], axis=1)
    # compute the norm 2 of each row
    dists = np.linalg.norm(difference, axis=1)

    library, stats, NSS_cutoff, library_index, stats_SS = compute_scores(dists, param_save, difference,Sim_SS)
    # print(library)
    return library, dists, stats,stats_SS,   NSS_cutoff, library_index
###################################################################################################

def do_regression(library, stats, PARAMS):

    # REJECTION
    print('\nDo a rejection ABC:')
    do_rejection(library, PARAMS)
    do_local_linear(stats, library, weights,KK)
    #print('\nStats:', stats.shape)
    #print('\nStats:', stats)
    #print('\nLibar:', library.shape)
    #print('\nLibar:', library)

    do_kernel_ridge(stats, library)
    do_ridge(stats, library)
##################################################################################################
def do_goodness_fit(result,HPDR, actual, n, i):
    for j in range(0,n):
        if HPDR[j][0]<=actual[j]<=HPDR[j][1]:
           coverage[i,j]=1
        else:
           coverage[i,j]=0
    resultsbias[i,:] = (result - actual)/actual
    return coverage,resultsbias

#############################################################################################

if __name__ == '__main__':
    ############################################################################################
    # exact parameter values
    import survdataSS2
    T_FINAL = len(survdataSS2.D1['J_patch1'][:,0])
    print(T_FINAL)
    NUMBER_SIMS = 1000000
    #no_patches=5
    no_patches=2
    rows=T_FINAL
    cols=no_patches
    #param_bound=np.array([[0,1],[0,1],[3,6],[1,4],[0,1],[0,0.5],[0,1],[0,1],[0,1],[100, 500]])
    N_J=np.ndarray(shape=(rows, cols), dtype=float, order='F')
    N_Y=np.ndarray(shape=(rows, cols), dtype=float, order='F')
    N_A=np.ndarray(shape=(rows, cols), dtype=float, order='F')
    tempA = np.ndarray(shape=(rows, cols), dtype=float, order='F')
    for q in range(1,no_patches+1):
        i=q-1
        p=7+q
        N_J[:,i]=survdataSS2.D1['J_patch'+ str(p)][:,2]
        #tempJ[:,i]=surfdata.D1['J_patch'+ str(q)][0,1]
        N_Y[:,i]=survdataSS2.D1['Y_patch'+ str(p)][:,2]
        #tempY[:,i]=surfdata.D1['Y_patch'+ str(q)][0,1]
        N_A[:,i]=survdataSS2.D1['A_patch'+ str(p)][:,2]
        tempA[:,i]=survdataSS2.D1['A_patch'+ str(p)][:,1]
    #Number of iteration
    # param_save, Obs_Sim         = run_sim()
    ######################################################################################################
#normalize the rows of Obs_sim to have NOS in row 1 and NSS in the remaining rows. Substract rows i=2:NUMBER_SIMS from row 1 of Obs_sim (whic contain OS).Compute the eucleadean distance (d) between NSS and NOS then use it along side tolerance (δ), to determine all parameters and NSS corresponding to d ≤ δ.Choose δ such that δ × 100% of the NUMBER_SIMS simulated parameters and NSS are selected. retain the parameters that made this threshold (library), the weights ot be used in local linear regression and the NSS that meets the threshold (stats)
#library, dists, stats,stats_SS,  NSS_cutoff, library_index   = sum_stats(Obs_Sim, param_save)
# result, HPDR=do_rejection(library)
# print('Estimates from rejection is:', result)
# print('Estimated HPDR from rejection is :', HPDR)
        #library_reg=do_logit_transformation(library, param_bound)
        #result_reg, HPDR_reg=do_kernel_ridge(stats, library_reg, param_bound)
    PARAMS1={}
    PARAMS1 = {"L_0":4.19724601e-01 , "L_inf": 63.2,"L_J": 12,"L_Y": 23, "Topt": 6.91162720e+00, "width": 1.48673462e+00, "kopt": 8.51676420e-01,"xi":3.30512880e-01,"r":4.83842810e-01, "m_J": 1.84111681e-01, "m_Y":7.74250205e-02 , "m_A": 4.96434309e-01, "K": 9.08024583e+03}
        #[4.19724601e-01 6.91162720e+00 1.48673462e+00 8.51676420e-01
        #3.30512880e-01 4.83842810e-01 1.84111681e-01 7.74250205e-02
#4.96434309e-01 9.08024583e+03]

    N_J1, N_Y1, N_A1 = simulation_population(PARAMS1)
        #N_J2, N_Y2, N_A2 = abc_example.species3(PARAMS2,temperatures, T_forcast, no_patches,N_J0, N_Y0,N_A0)
    import plot
    for q in range(1,no_patches+1):
        i=q-1
        p=q+7
        plot.do_realdata(N_J1[:,i], N_J[:,i],  'J_abun_rej'+ str(p))
        plot.do_scatter(N_J1[:,i], N_J[:,i],  'J_abun_scatter'+ str(p))
        plot.do_realdata(N_Y1[:,i], N_Y[:,i],  'Y_abun_rej'+ str(p))
        plot.do_scatter(N_Y1[:,i], N_Y[:,i],  'Y_abun_scatter'+ str(p))
        plot.do_realdata(N_A1[:,i], N_A[:,i],  'A_abun_rej'+ str(p))
        plot.do_scatter(N_A1[:,i], N_A[:,i],  'A_abun_scatter'+ str(p))

