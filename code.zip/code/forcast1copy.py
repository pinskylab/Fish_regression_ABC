# this script simulates stage-structured population sizes in space and time for given parameters and forcin
# functions
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sys


def temp_dependence(temperature, Topt, width, kopt):
    """ compute growth rate as a function of temperature, were kopt is the optimal growth rate, Topt, optimal temperature, width, the standard deviation from the optimal temperature.
    """
    #theta = -width*(temperature-Topt)*(temperature-Topt) + kopt
    theta = kopt*np.exp(-0.5*np.square((temperature-Topt)/width))
    #theta=((temperature-Tmin)*(temperature-Tmax))/(((temperature-Tmin)*(temperature-Tmax))-(temperature-Topt))
    return theta


def pop_dynamics(N_J, N_Y, N_A, params, alpha):
    """ Intake population sizes for the three population data structure
        for the parameter values; alph(parameter for beta distribution. With uniform priors, we do not need alph), alpha, the temperature dependent growth rate(output of the temp_dependence), fecudity is input separately. N_B is larvae, N_J is juvenille, and N_A is adults. [N_b(t+1)]=[birth]-[conversion to juvenile]. [N_J(t+1)]=[N_B becoming N_J]-[death]-[coversion to N_A]. [N_A(t+1)]=[fraction(f_s) from N_J and those that did not die that stays]-[fraction that leaves to another patch]
    """
    #recruits = beta_defs(alph,params["g_B"])
    #gJval = beta_defs(alph,params["g_J"])
    #nJ_coef = (1 - gJval - beta_defs(alph,params["m_J"]))
    nextN_J=max(0,N_J+alpha*N_A-params["g_J"]*N_J-params["m_J"]*N_J+np.random.normal(0,1))
    nextN_Y=max(0,N_Y+params["g_J"]*N_J-params["g_Y"]*N_Y-params["m_Y"]*N_Y+np.random.normal(0,1))
    nextN_A=max(0,N_A+params["g_Y"]*N_Y-params["m_A"]*N_A+np.random.normal(0,1))
    return nextN_J, nextN_Y, nextN_A


def movement(pop1, pop2, N_A11, N_A12, f_s):
    """ Takes population sizes in two patches, in which a fraction, f_s, of each stays and outputs
    the population sizes in each patch after movement """
    next_pop1 =max(0,pop1+f_s*(N_A12-N_A11))
    next_pop2 =max(0,pop2+f_s*(N_A11-N_A12))

    return next_pop1, next_pop2


def simulation_population(N_J0, N_Y0, N_A0, params, T_FINAL, temperatures):
    """ Takes in the initial population sizes and simulates the population size moving forward """
    # Set starting numbers for population and allocate space for population sizes
    N_J = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_J[0] = N_J0
    N_Y = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_Y[0] = N_Y0
    N_A = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_A[0] = N_A0

    for t in range(10,T_FINAL):
        alpha1 = temp_dependence(temperatures[t], params["Topt"], params["width"], params["kopt"])
        alpha2 = temp_dependence(temperatures[t] + params["delta_t"], params["Topt"], params["width"], params["kopt"])

        N_J[t+1][0], N_Y[t+1][0], N_A1 = pop_dynamics(N_J[t][0], N_Y[t][0], N_A[t][0], params, alpha1)
        N_J[t+1][1], N_Y[t+1][1], N_A2 = pop_dynamics(N_J[t][1], N_Y[t][1], N_A[t][1], params, alpha2)

        N_A[t+1][0], N_A[t+1][1] = movement(N_A1,N_A2,N_A[t][0],N_A[t][1], params["d_A"])

    return N_J, N_Y, N_A


######################################################
if __name__ == '__main__':
    # Sets parameters
    PARAMS = {"g_J": 1, "g_Y": 1, "Topt": 6.5, "width": 2, "kopt": 1,"d_A":0.1, "m_J": .04, "m_Y": .05, "m_A": .05, "delta_t": 2}
    PARAMS1 = {"g_J": 1, "g_Y": 1, "Topt": 6.5, "width": 2, "kopt": 1,"d_A":0.1, "m_J": .04, "m_Y": .05, "m_A": .05, "delta_t": 2}
    #LB = {"g_J": 0.30243331, "g_Y": 0.21545318, "Topt": 5.66631524, "width": 1.59812797, "kopt": 0.60363592,"d_A":0.07494251, "m_J": 0.03974884, "m_Y": 0.03768717, "m_A": 0.03024419, "delta_t": 2}
    #UB = {"g_J": 0.65890741, "g_Y": 0.56338085, "Topt": 6.41671799, "width": 2.4423295, "kopt": 0.83533993,"d_A":0.11567576, "m_J": 0.05712863, "m_Y": 0.05930339, "m_A": 0.06062492, "delta_t": 2}
    #PARAMS = {"alpha0": 2, "T0": 1, "width": 1, "g_B": .3, "g_J": .4, "m_J": .05, "m_A": .05, "f_s": .9, "delta_t":.1, "lam":1}
    T_FINAL = 19
    #print(PARAMS["g_J"])
    #LANDSCAPE_LEN = 2
    N0 = 5
    temperatures = np.linspace(0, 13,T_FINAL)
    N_J, N_Y, N_A = simulation_population(N0, N0, N0, PARAMS, T_FINAL, temperatures)
    N_J1, N_Y1, N_A1 = simulation_population(N0, N0, N0, PARAMS1, T_FINAL, temperatures)
    #N_J1, N_Y1, N_A1 = simulation_population(N0, N0, N0, LB, T_FINAL, temperatures)
    #N_J2, N_Y2, N_A2 = simulation_population(N0, N0, N0, UB, T_FINAL, temperatures)
    
    
    
    ######################
    #######################
    #total_adult = N_A.sum(axis=1)[10:] # total population in each stage, summed over space
    #total_young = N_Y.sum(axis=1)[10:]
    #total_juv   = N_J.sum(axis=1)[10:]
    #total_adult1 = N_A1.sum(axis=1)[10:]  # total population in each stage, summed over space
    #total_young1 = N_Y1.sum(axis=1)[10:]
    #total_juv1   = N_J1.sum(axis=1)[10:]
    #total_adult2 = N_A2.sum(axis=1)[10:]  # total population in each stage, summed over space
    # total_young2 = N_Y2.sum(axis=1)[10:]
    #total_juv2   = N_J2.sum(axis=1)[10:]
    #############################
    ###############################
    #Obs_adult=pd.Series(total_adult,index=pd.Series(range(10,21)))
    Obs_adult1=pd.Series(N_A[:,0],index=pd.Series(range(1,21)))
    Obs_adult2=pd.Series(N_A[:,1],index=pd.Series(range(1,21)))
    Obs_young1=pd.Series(N_Y[:,0],index=pd.Series(range(1,21)))
    Obs_young2=pd.Series(N_Y[:,1],index=pd.Series(range(1,21)))
    Obs_juv1=pd.Series(N_J[:,0],index=pd.Series(range(1,21)))
    Obs_juv2=pd.Series(N_J[:,1],index=pd.Series(range(1,21)))
    pre_adult1=pd.Series(N_A1[:,0][10:],index=pd.Series(range(11,21)))
    pre_adult2=pd.Series(N_A1[:,1][10:],index=pd.Series(range(11,21)))
    pre_young1=pd.Series(N_Y1[:,0][10:],index=pd.Series(range(11,21)))
    pre_young2=pd.Series(N_Y1[:,1][10:],index=pd.Series(range(11,21)))
    pre_juv1=pd.Series(N_J1[:,0][10:],index=pd.Series(range(11,21)))
    pre_juv2=pd.Series(N_J1[:,1][10:],index=pd.Series(range(11,21)))
    
    #######################
    #####################
    fig, ax=plt.subplots()
    plt.plot(Obs_adult1.index, Obs_adult1, 'k', linewidth=2)
    plt.plot(pre_adult1.index, pre_adult1, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax.set_ylabel('Number of adults in patch 1', fontsize=18)
    ax.set_xlabel('Time (years)',fontsize=18)
    ax.tick_params(width = 2, direction = "out")
    fig.savefig('adult_patch1sp1.png')
    plt.close()
    ##############################
    fig1, ax1=plt.subplots()
    plt.plot(Obs_young1.index, Obs_young1, 'k', linewidth=2)
    plt.plot(pre_young1.index, pre_young1, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax1.set_ylabel('Number of large juveniles in patch 1', fontsize=18)
    ax1.set_xlabel('Time (years)',fontsize=18)
    ax1.tick_params(width = 2, direction = "out")
    fig1.savefig('young_patch1spe1.png')
    plt.close()
    ##########################
    ###########################
    fig2, ax2=plt.subplots()
    plt.plot(Obs_juv1.index, Obs_juv1, 'k', linewidth=2)
    plt.plot(pre_juv1.index, pre_juv1, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax2.set_ylabel('Number of juveniles in patch 1', fontsize=18)
    ax2.set_xlabel('Time (years)',fontsize=18)
    ax2.tick_params(width = 2, direction = "out")
    fig2.savefig('juv_patch1spe1.png')
    plt.close()
    #################################
    ####################################
    fig3, ax3=plt.subplots()
    plt.plot(Obs_adult2.index, Obs_adult2, 'k', linewidth=2)
    plt.plot(pre_adult2.index, pre_adult2, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax3.set_ylabel('Number of adults in patch 2', fontsize=18)
    ax3.set_xlabel('Time (years)',fontsize=18)
    ax3.tick_params(width = 2, direction = "out")
    fig3.savefig('adult_patch2spe1.png')
    plt.close()
    ##############################
    fig4, ax4=plt.subplots()
    plt.plot(Obs_young2.index, Obs_young2, 'k', linewidth=2)
    plt.plot(pre_young2.index, pre_young2, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax4.set_ylabel('Number of large juveniles in patch 2', fontsize=18)
    ax4.set_xlabel('Time (years)',fontsize=18)
    ax4.tick_params(width = 2, direction = "out")
    fig4.savefig('young_patch2spe1.png')
    plt.close()
    ##########################
    ###########################
    fig5, ax5=plt.subplots()
    plt.plot(Obs_juv2.index, Obs_juv2, 'k', linewidth=2)
    plt.plot(pre_juv2.index, pre_juv2, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax5.set_ylabel('Number of juveniles in patch 2', fontsize=18)
    ax5.set_xlabel('Time (years)',fontsize=18)
    ax5.tick_params(width = 2, direction = "out")
    fig5.savefig('juv_patch2spe1.png')
    plt.close()

