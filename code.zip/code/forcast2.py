# this script simulates stage-structured population sizes in space and time for given parameters and forcin
# functions

# NB for EAM: this runs on Mushu in pipenv, so call pipenv run python fish_abc.py

# import dependencies
import numpy as np

import sys
import pandas as pd
#import matplotlib.pyplot as plt
import matplotlib.pyplot as plt
def temp_dependence(temperature, Topt, width, kopt):
    """ compute growth rate as a function of temperature, were kopt is the optimal growth rate, Topt, optimal temperature, width, the standard deviation from the optimal temperature.
        """
    #theta = -width*(temperature-Topt)*(temperature-Topt) + kopt
    theta = kopt*np.exp(-0.5*np.square((temperature-Topt)/width))
    #theta=((temperature-Tmin)*(temperature-Tmax))/(((temperature-Tmin)*(temperature-Tmax))-(temperature-Topt))
    return theta



def pop_dynamics(N_J, N_Y, N_A, params, alpha):
    """ Intake population sizes for the three population data structure
        for the parameter values; alph(parameter for beta distribution. With uniform priors, we do not need alph), alpha, the temperature dependent growth rate(output of the temp_dependence), fecudity is input separately. N_B is larvae, N_J is juvenille, and N_A is adults. [N_b(t+1)]=[birth]-[conversion to juvenile]. [N_J(t+1)]=[N_B becoming N_J]-[death]-[coversion to N_A]. [N_A(t+1)]=[fraction(f_s) from N_J and those that did not die that stays]-[fraction that leaves to another patch]
    """
    #recruits = beta_defs(alph,params["g_B"])
    #gJval = beta_defs(alph,params["g_J"])
    #nJ_coef = (1 - gJval - beta_defs(alph,params["m_J"]))
    
    nextN_J=N_J-params["g_J"]*N_J-params["m_J"]*N_J
    nextN_Y=np.random.poisson(lam=max(0,N_Y+params["g_J"]*N_J-params["g_Y"]*N_Y-params["m_Y"]*N_Y))
    nextN_A=np.random.poisson(lam=max(0,N_A+params["g_Y"]*N_Y-params["m_A"]*N_A))
    return nextN_J, nextN_Y, nextN_A



def movement(pop1,pop2,N_A1,N_A2,alpha1,alpha2, f_s):
    """ Takes population sizes in two patches, in which a fraction, f_s, of each stays and outputs
    the population sizes in each patch after movement """
    next_pop1 =np.random.poisson(lam=max(0,pop1+(1-f_s)*alpha1*N_A1+f_s*(alpha2*N_A2)))
    next_pop2 =np.random.poisson(lam=max(0,pop2+(1-f_s)*alpha2*N_A2+f_s*alpha1*N_A1))
    return next_pop1, next_pop2


def simulation_population(N_J0, N_Y0, N_A0, params, T_FINAL, temperatures):
    """ Takes in the initial population sizes and simulates the population size moving forward """
    # Set starting numbers for population and allocate space for population sizes
    N_J = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_J[0] = N_J0
    N_Y = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_Y[0] = N_Y0
    N_A = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_A[0] = N_A0

    for t in range(0,T_FINAL):
        alpha1 = temp_dependence(temperatures[t], params["Topt"], params["width"], params["kopt"])
        alpha2 = temp_dependence(temperatures[t] + params["delta_t"], params["Topt"], params["width"], params["kopt"])
        N_J1, N_Y[t+1][0], N_A[t+1][0] = pop_dynamics(N_J[t][0], N_Y[t][0], N_A[t][0], params, alpha1)
        N_J2, N_Y[t+1][1], N_A[t+1][1] = pop_dynamics(N_J[t][1], N_Y[t][1], N_A[t][1], params, alpha2)

        #N_A[t+1][0], N_A[t+1][1] = movement(N_A1,N_A2, params["f_s"])
        N_J[t+1][0], N_J[t+1][1] = movement(N_J1,N_J2,N_A[t][0],N_A[t][1],alpha1,alpha2, params["xi"])
    
    return N_J, N_Y, N_A


#################################################################

#July 28, 2019
#[0.44737616 0.33172456 6.01355114 1.91655788 0.67484173 0.0990185 0.05255441 0.0494733  0.05038927]
# [[0.29512947 0.61906533][0.14698337 0.4979534 ][5.45362621 6.65787558][1.48919807 2.48410269][0.52721359 0.78979192][0.07268951 0.12752656][0.03592095 0.06936256][0.03409392 0.06236003][0.0343376  0.06367435]]
#[0.44786493 0.3319451  6.01044519 1.92122334 0.6759964  0.09759275
#0.05005164 0.05029329 0.04904537]
#Estimated highest probability density region is: [[0.31178193 0.5999997 ]
#                                           [0.1976241  0.47514173]
#                                               [5.54564688 6.62861774]
#                                                 [1.52538553 2.35042729]
#                                                 [0.53292031 0.83960921]
#                                                 [0.05806624 0.13228847]
#                                                  [0.03229133 0.06296649]
#                                                 [0.03933463 0.07158869]
#        [0.03199457 0.06349324]]
#[0.43794432 0.32807515 5.99068554 1.97131688 0.68582109 0.09782945
# 0.05156776 0.04982296 0.04931732]
#Estimated highest probability density region is: [[0.24966776 0.59064458]
#                                                [0.1576847  0.45859344]
#                                                [5.52820792 6.43612939]
#                                                [1.55016961 2.48477815]
#                                                [0.53931684 0.84185928]
#                                                [0.06530397 0.13079127]
#                                                [0.03470417 0.06379972]
#                                                [0.03155258 0.06503931]
#                                               [0.02721347 0.06478219]]
#end of july 29
#August 02, 2019
#[0.43499351 0.32833745 5.97939058 1.9829714  0.70222172 0.09773575
#0.05096213 0.04940465 0.04853018]
#[[0.26319504 0.60191287][0.15011867 0.51843552][5.45324476 6.30828994][1.6257194  2.34626275][0.58398838 0.84177605][0.06390878 0.12897521][0.03997189 0.06579591][0.03546196 0.0644113 ][0.03121187 0.06369833]]

if __name__ == '__main__':
    # Sets parameters
    PARAMS = {"g_J": 0.4, "g_Y": 0.3, "Topt": 6, "width": 2, "kopt": 0.6,"xi":0.1, "m_J": .04, "m_Y": .05, "m_A": .05, "delta_t": 2}
    PARAMS1 = {"g_J": 0.44737616, "g_Y":0.33172456, "Topt":6.01355114, "width": 1.91655788, "kopt": 0.67484173,"xi":0.0990185, "m_J": 0.05255441, "m_Y": 0.0494733, "m_A": 0.05038927, "delta_t": 2}
    #LB = {"g_J": 0.31785777, "g_Y": 0.18332368, "Topt": 5.3848027, "width": 1.470136, "kopt": 0.55949881,"xi":0.0716938, "m_J": 0.03497441, "m_Y": 0.0341232, "m_A": 0.03260552, "delta_t": 2}
    #UB = {"g_J": 0.63504851, "g_Y": 0.48144746, "Topt": 6.46861121, "width": 2.43031917, "kopt": 0.8289444,"xi":0.13208011, "m_J": 0.06777483, "m_Y": 0.0644725, "m_A": 0.06558457, "delta_t": 2}
    T_FINAL = 19
    #print(PARAMS["g_J"])
    #LANDSCAPE_LEN = 2
    N0 = 5
    temperatures = np.linspace(0, 13,T_FINAL)
    N_J, N_Y, N_A = simulation_population(N0, N0, N0, PARAMS, T_FINAL, temperatures)
    N_J1, N_Y1, N_A1 = simulation_population(N0, N0, N0, PARAMS1, T_FINAL, temperatures)
    #N_J1, N_Y1, N_A1 = simulation_population(N0, N0, N0, LB, T_FINAL, temperatures)
    #N_J2, N_Y2, N_A2 = simulation_population(N0, N0, N0, UB, T_FINAL, temperatures)
    
    
    
    ######################
    #######################
    #total_adult = N_A.sum(axis=1)[10:] # total population in each stage, summed over space
    #total_young = N_Y.sum(axis=1)[10:]
    #total_juv   = N_J.sum(axis=1)[10:]
    #total_adult1 = N_A1.sum(axis=1)[10:]  # total population in each stage, summed over space
    #total_young1 = N_Y1.sum(axis=1)[10:]
    #total_juv1   = N_J1.sum(axis=1)[10:]
    #total_adult2 = N_A2.sum(axis=1)[10:]  # total population in each stage, summed over space
    # total_young2 = N_Y2.sum(axis=1)[10:]
    #total_juv2   = N_J2.sum(axis=1)[10:]
    #############################
    ###############################
    #Obs_adult=pd.Series(total_adult,index=pd.Series(range(10,21)))
    Obs_adult1=pd.Series(N_A[:,0],index=pd.Series(range(1,21)))
    Obs_adult2=pd.Series(N_A[:,1],index=pd.Series(range(1,21)))
    Obs_young1=pd.Series(N_Y[:,0],index=pd.Series(range(1,21)))
    Obs_young2=pd.Series(N_Y[:,1],index=pd.Series(range(1,21)))
    Obs_juv1=pd.Series(N_J[:,0],index=pd.Series(range(1,21)))
    Obs_juv2=pd.Series(N_J[:,1],index=pd.Series(range(1,21)))
    pre_adult1=pd.Series(N_A1[:,0][10:],index=pd.Series(range(11,21)))
    pre_adult2=pd.Series(N_A1[:,1][10:],index=pd.Series(range(11,21)))
    pre_young1=pd.Series(N_Y1[:,0][10:],index=pd.Series(range(11,21)))
    pre_young2=pd.Series(N_Y1[:,1][10:],index=pd.Series(range(11,21)))
    pre_juv1=pd.Series(N_J1[:,0][10:],index=pd.Series(range(11,21)))
    pre_juv2=pd.Series(N_J1[:,1][10:],index=pd.Series(range(11,21)))

    #######################
    #####################
    fig, ax=plt.subplots()
    plt.plot(Obs_adult1.index, Obs_adult1, 'k', linewidth=2)
    plt.plot(pre_adult1.index, pre_adult1, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax.set_ylabel('Number of adults in patch 1', fontsize=18)
    ax.set_xlabel('Time (years)',fontsize=18)
    ax.tick_params(width = 2, direction = "out")
    fig.savefig('adult_patch1sp2.png')
    plt.close()
    ##############################
    fig1, ax1=plt.subplots()
    plt.plot(Obs_young1.index, Obs_young1, 'k', linewidth=2)
    plt.plot(pre_young1.index, pre_young1, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax1.set_ylabel('Number of large juveniles in patch 1', fontsize=18)
    ax1.set_xlabel('Time (years)',fontsize=18)
    ax1.tick_params(width = 2, direction = "out")
    fig1.savefig('young_patch1spe2.png')
    plt.close()
    ##########################
    ###########################
    fig2, ax2=plt.subplots()
    plt.plot(Obs_juv1.index, Obs_juv1, 'k', linewidth=2)
    plt.plot(pre_juv1.index, pre_juv1, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax2.set_ylabel('Number of juveniles in patch 1', fontsize=18)
    ax2.set_xlabel('Time (years)',fontsize=18)
    ax2.tick_params(width = 2, direction = "out")
    fig2.savefig('juv_patch1spe2.png')
    plt.close()
    #################################
    ####################################
    fig3, ax3=plt.subplots()
    plt.plot(Obs_adult2.index, Obs_adult2, 'k', linewidth=2)
    plt.plot(pre_adult2.index, pre_adult2, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax3.set_ylabel('Number of adults in patch 2', fontsize=18)
    ax3.set_xlabel('Time (years)',fontsize=18)
    ax3.tick_params(width = 2, direction = "out")
    fig3.savefig('adult_patch2sp2.png')
    plt.close()
    ##############################
    fig4, ax4=plt.subplots()
    plt.plot(Obs_young2.index, Obs_young2, 'k', linewidth=2)
    plt.plot(pre_young2.index, pre_young2, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax4.set_ylabel('Number of large juveniles in patch 2', fontsize=18)
    ax4.set_xlabel('Time (years)',fontsize=18)
    ax4.tick_params(width = 2, direction = "out")
    fig4.savefig('young_patch2spe2.png')
    plt.close()
    ##########################
    ###########################
    fig5, ax5=plt.subplots()
    plt.plot(Obs_juv2.index, Obs_juv2, 'k', linewidth=2)   
    plt.plot(pre_juv2.index, pre_juv2, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax5.set_ylabel('Number of juveniles in patch 2', fontsize=18)
    ax5.set_xlabel('Time (years)',fontsize=18)
    ax5.tick_params(width = 2, direction = "out")
    fig5.savefig('juv_patch2spe2.png')
    plt.close()

