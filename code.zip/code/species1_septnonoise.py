# this script simulates stage-structured population sizes in space and time for given parameters and forcin
# functions
from __future__ import print_function, division

# NB for EAM: this runs on Mushu in pipenv, so call pipenv run python fish_abc.py

# import dependencies
import numpy as np
import math as math
import random as random
import sys
import copy as copy
from scipy.stats import norm
import statsmodels.api as sm
from scipy import stats
from numpy.linalg import inv
import pymc3
import scipy.stats as sst
from sklearn import preprocessing
#import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
import seaborn as sns
def compute_weight(t, eps, CC):
    if t <= eps:
        return (1. - (t / eps)**2)/eps
    else:
        return 0.


def mean_confidence_interval(A, confidence=0.95):
    a = 1.0 * np.array(A)
    n = len(a)
    m, se = np.mean(a, axis=0), sst.sem(a, axis=0, ddof=1)
    h = se * sst.t.ppf((1 + confidence) / 2., n-1)
    return m, h, m-h, m+h



def temp_dependence(temperature, Topt, width, kopt):
    """ compute growth rate as a function of temperature, were kopt is the optimal growth rate, Topt, optimal temperature, width, the standard deviation from the optimal temperature.
    """
    #theta = -width*(temperature-Topt)*(temperature-Topt) + kopt
    theta = kopt*np.exp(-0.5*np.square((temperature-Topt)/width))
    #theta=((temperature-Tmin)*(temperature-Tmax))/(((temperature-Tmin)*(temperature-Tmax))-(temperature-Topt))
    return theta


def pop_dynamics(N_J, N_Y, N_A, params, alpha):
    """ Intake population sizes for the three population data structure
        for the parameter values; alph(parameter for beta distribution. With uniform priors, we do not need alph), alpha, the temperature dependent growth rate(output of the temp_dependence), fecudity is input separately. N_B is larvae, N_J is juvenille, and N_A is adults. [N_b(t+1)]=[birth]-[conversion to juvenile]. [N_J(t+1)]=[N_B becoming N_J]-[death]-[coversion to N_A]. [N_A(t+1)]=[fraction(f_s) from N_J and those that did not die that stays]-[fraction that leaves to another patch]
    """
    #recruits = beta_defs(alph,params["g_B"])
    #gJval = beta_defs(alph,params["g_J"])
    #nJ_coef = (1 - gJval - beta_defs(alph,params["m_J"]))
    nextN_J=max(0,N_J+alpha*N_A-params["g_J"]*N_J-params["m_J"]*N_J)
    nextN_Y=max(0,N_Y+params["g_J"]*N_J-params["g_Y"]*N_Y-params["m_Y"]*N_Y)
    nextN_A=N_A+params["g_Y"]*N_Y-params["m_A"]*N_A
    return nextN_J, nextN_Y, nextN_A


def movement(pop1, pop2, N_A11, N_A12, f_s):
    """ Takes population sizes in two patches, in which a fraction, f_s, of each stays and outputs
    the population sizes in each patch after movement """
    next_pop1 =max(0,pop1+f_s*(N_A12-N_A11))
    next_pop2 =max(0,pop2+f_s*(N_A11-N_A12))

    return next_pop1, next_pop2


def simulation_population(N_J0, N_Y0, N_A0, params, T_FINAL, temperatures):
    """ Takes in the initial population sizes and simulates the population size moving forward """
    # Set starting numbers for population and allocate space for population sizes
    N_J = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_J[0] = N_J0
    N_Y = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_Y[0] = N_Y0
    N_A = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_A[0] = N_A0

    for t in range(0,T_FINAL):
        alpha1 = temp_dependence(temperatures[t], params["Topt"], params["width"], params["kopt"])
        alpha2 = temp_dependence(temperatures[t] + params["delta_t"], params["Topt"], params["width"], params["kopt"])

        N_J[t+1][0], N_Y[t+1][0], N_A1 = pop_dynamics(N_J[t][0], N_Y[t][0], N_A[t][0], params, alpha1)
        N_J[t+1][1], N_Y[t+1][1], N_A2 = pop_dynamics(N_J[t][1], N_Y[t][1], N_A[t][1], params, alpha2)

        N_A[t+1][0], N_A[t+1][1] = movement(N_A1,N_A2,N_A[t][0],N_A[t][1], params["d_A"])

    return N_J, N_Y, N_A


def calculate_summary_stats(N_J, N_Y, N_A, T_FINAL):
    """Takes in a matrix of time x place population sizes for each stage and calculates summary statistics"""
    time=range(T_FINAL)
    total_adult = N_A.sum(axis=1) # total population in each stage, summed over space
    total_young = N_Y.sum(axis=1)
    total_juv   = N_J.sum(axis=1)
    #lquartile_adult=np.percentile(total_adult, 25)
    L_Q=np.percentile(time, 25, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    M_Q=np.percentile(time, 50, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    U_Q=np.percentile(time, 75, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    #print('time:', time)
    #print('LQ:', L_Q, ' MQ:', M_Q, ' UQ:', U_Q)
    lquartile_adult=total_adult[L_Q]#np.percentile(total_adult, 25)
    median_adult=total_adult[M_Q]#np.percentile(total_adult, 50)
    uquartile_adult=total_adult[U_Q]#np.percentile(total_adult, 75)
    mean_adult=np.mean(total_adult)
    std_adult=np.std(total_adult)
    lquartile_young=total_young[L_Q]#np.percentile(total_juv, 25)
    median_young=total_young[M_Q]#np.percentile(total_juv, 50)
    uquartile_young=total_young[U_Q]#np.percentile(total_juv, 75)
    mean_young=np.mean(total_young)
    std_young=np.std(total_young)
    lquartile_juv=total_juv[L_Q]#np.percentile(total_larv, 25)
    median_juv=total_juv[M_Q]#np.percentile(total_larv, 50)
    uquartile_juv=total_juv[U_Q]#np.percentile(total_larv, 75)
    mean_juv=np.mean(total_juv)
    std_juv=np.std(total_juv)
    #print('total_adult:', total_adult)
    #print('N_A:', N_A)
    SS_adult=np.hstack((lquartile_adult, median_adult, uquartile_adult))
    SS_young=np.hstack((lquartile_young, median_young, uquartile_young))
    SS_juv=np.hstack((lquartile_juv, median_juv, uquartile_juv))
    SS_adult1=np.hstack((N_A[L_Q], N_A[M_Q], N_A[U_Q]))
    SS_young1=np.hstack((N_Y[L_Q], N_Y[M_Q], N_Y[U_Q]))
    SS_juv1=np.hstack((N_J[L_Q], N_J[M_Q], N_J[U_Q]))
    #total_population = total_adult + total_juv + total_larv # total population size in each time
    #print(total_adult)
    # print(lquartile_adult)
    #print(SS_adult)
    #print(mean_adult)
    #sys.exit()
    return SS_adult1, SS_young1, SS_juv1


def euclidean_distance(vec1, vec2):
    """ Takes two vectors of the same dimensions and calculates the Euclidean distance between the elements"""
    return np.linalg.norm(vec1 - vec2, ord=2)


def small_percent(vector, percent):
    """ Takes a vector and returns the indexes of the elements within the smallest (percent) percent of the vector"""
    sorted_vector = sorted(vector)
    cutoff = math.floor(len(vector)*percent/100) # finds the value which (percent) percent are below
    indexes = []
    #print('cutoff:',cutoff)
    cutoff = int(cutoff)
    for i in range(0,len(vector)):
        if vector[i] < sorted_vector[cutoff]: # looks for values below the found cutoff
            indexes.append(i)

    return indexes, sorted_vector[cutoff]


def z_score(x):
    """Takes a list and returns a 0 centered, std = 1 scaled version of the list"""
    st_dev = np.std(x,axis=0)
    mu = np.mean(x,axis=0)
    rescaled_values = []
    for element in range(0,len(x)):
        rescaled_values[element] = (x[element] - mu) / st_dev

    return rescaled_values
def print_parameters(params, prefix=''):
    print('%s parameter values:' % prefix, end=' ')
    for name, value in params.items():
        print('%s = %.2f' % (name, value), end='\t')



def do_regression_manual(library, weights, stats):
    X = sm.add_constant(stats)
    Y = np.array(library)
    X_T=np.transpose(X)
    #print('X:', X.shape, ' ', X)
    #print('Y:', Y.shape, ' ', Y)
    #print('Y:', Y.shape)
    #mmmm = np.mat(X_T)*np.mat(np.diag(np.array((weights/np.array(weights).sum()))))*np.mat(X)
    #print('M:', mmmm)
    try:
      inv_X=inv(np.mat(X_T)*np.mat(np.diag(np.array((weights/np.array(weights).sum()))))*np.mat(X))
      resultmanual=inv_X*(X_T*np.mat(np.diag(np.array((weights/np.array(weights).sum()))))*Y)
      results=resultmanual[0,:]
    except:
      results=[param_actual["g_J"], param_actual["g_Y"], param_actual["Topt"], param_actual["width"], param_actual["kopt"],param_actual["d_A"], param_actual["m_J"], param_actual["m_Y"], param_actual["m_A"]]
    return results
        #def do_regression_manual(library, weights, X):
        # Y = library
        #YY=np.array(Y)
        #mean_conf_int = np.c_[vecZZ,con_int]
        ## rownames = ['g_J', 'g_B', 'alpha0', 'width', 'f_s', 'T0', 'm_J', 'm_A']
        #tabl = SimpleTable(mean_conf_int, colnames, rownames, txt_fmt=default_txt_fmt)
        #print(tabl)
    #print( tabl.as_latex_tabular() )
    # print("True parameter values:", PARAMS["g_J"], PARAMS["g_B"],PARAMS["alpha0"], PARAMS["width"], PARAMS["f_s"], PARAMS["T0"], PARAMS["m_J"], PARAMS["m_A"])
#print("Estimates from manula computation is :", AA[0])

def run_sim(PARAMS, NUMBER_SIMS):
    PARAMS_ABC = copy.deepcopy(PARAMS) # copies parameters so new values can be generated; FIX ME! this is a redirect, not a copy?
    param_save = [] # sets an initial 0; fixed to [] because [[]] made the mean go poorly (averaging in an [] at start?)

    #print_parameters(PARAMS, prefix='True')

    # Sets temperatures at each patch over time [FIX THIS]
    temperatures = np.linspace(0, 13,T_FINAL)
    #temperatures = [3.6,3.8,4,4.2,4.4,4.6,4.8,5,5.2,5.4]
    #temperatures = [0,1,2,3,4,5,6,7,8,9]
    # Simulates population
    N_J, N_Y, N_A = simulation_population(N0, N0, N0, PARAMS, T_FINAL, temperatures)

    SS_adult, SS_young, SS_juv= calculate_summary_stats(N_J, N_Y, N_A, T_FINAL)
    SO=np.hstack((SS_adult, SS_young, SS_juv))
    Obs_Sim=np.zeros((NUMBER_SIMS+1,len(SO)))
    Obs_Sim[0,:]=SO
    for i in range(0,NUMBER_SIMS):
        g_J_theta    = np.random.uniform(0,1)#np.random.normal(0.4,0.3) #np.random.beta(2,2)
        g_Y_theta    =np.random.uniform(0,1) #np.random.uniform(0,1)#np.random.beta(2,2)
        Topt_theta =np.random.uniform(5,9)#np.random.normal(6.5,2) #np.random.uniform(1,12) #np.random.lognormal(1,1)
        width_theta  =np.random.uniform(1,4)#np.random.normal(2,1)
        ##np.random.lognormal(1,1)
        kopt_theta    =np.random.uniform(0,1)#np.random.normal(0.5,0.4)# np.random.u(0,1)
        xi_theta     =np.random.uniform(0,0.5)#np.random.normal(0.1,0.09) #np.random.normal(0,1)#np.random.normal(0,0.5)
        m_J_theta    =np.random.uniform(0,1)#np.random.normal(0.04,0.04) # #np.random.beta(2,2)
        m_Y_theta    =np.random.uniform(0,1)#np.random.normal(0.05,0.04) #np.random.uniform(0,1) #np.random.beta(2,2)
        m_A_theta    =np.random.uniform(0,1)#np.random.normal(0.05,0.05)# np.random.uniform(0,1)#np.random.beta(2,2)

        PARAMS_ABC["g_J"]    = g_J_theta # sets the g_J parameter to our random guess
        PARAMS_ABC["g_Y"]    = g_Y_theta
        PARAMS_ABC["Topt"] = Topt_theta
        PARAMS_ABC["width"]  = width_theta
        PARAMS_ABC["kopt"]    = kopt_theta
        PARAMS_ABC["d_A"]     = xi_theta
        PARAMS_ABC["m_J"]    = m_J_theta
        PARAMS_ABC["m_Y"]    = m_Y_theta
        PARAMS_ABC["m_A"]    = m_A_theta

        # Simulate population for new parameters
        N_J_sim, N_Y_sim, N_A_sim = simulation_population(N0,N0,N0, PARAMS_ABC, T_FINAL, temperatures) # simulates population with g_J value

        # Calculate the summary statistics for the simulation
        Sim_SS_adult, Sim_SS_young, Sim_SS_juv= calculate_summary_stats(N_J_sim, N_Y_sim, N_A_sim, T_FINAL)
        SS=np.hstack((Sim_SS_adult, Sim_SS_young, Sim_SS_juv))
        Obs_Sim[i+1,:]=SS

        param_save.append([g_J_theta, g_Y_theta, Topt_theta, width_theta, kopt_theta, xi_theta, m_J_theta,m_Y_theta, m_A_theta])

    return np.asarray(param_save), Obs_Sim


def compute_scores(dists, param_save, difference, c):
    eps=25
    library_index, ep = small_percent(dists, eps)
    n                = len(library_index)
    library, weights, Ker_vec = np.empty((n, param_save.shape[1])), np.empty(n), np.empty(n)
    stats            = np.empty((n, difference.shape[1]))


    for i in range(0,len(library_index)):
        j = library_index[i]
        CC=c[j]
        weights[i] = compute_weight(dists[j], eps, CC)
        library[i] = param_save[j]
        stats[i]   = difference[j]
        Ker_vec[i]=dists[j]
    KK=np.exp(-np.power(Ker_vec,2)/(2*np.std(Ker_vec)**2))
    return library, weights, stats, KK


def sum_stats(Obs_Sim, param_save, NUMBER_SIMS):
    dists = np.zeros((NUMBER_SIMS,1))
    #Obs_Sim_scale=np.nan_to_num(sst.zscore(Obs_Sim, axis=0,ddof=1),copy=True)
    Obs_Sim_scale=np.nan_to_num(preprocessing.normalize(Obs_Sim, axis=0),copy=True)
    #Substract each row of teh array from row 1
    difference=Obs_Sim_scale[1:NUMBER_SIMS+1,: ]-Obs_Sim_scale[0,:]
    c=np.std(Obs_Sim_scale[1:NUMBER_SIMS+1,: ], axis=1)
    # compute the norm 2 of each row
    dists = np.linalg.norm(difference, axis=1)

    library, weights, stats, KK = compute_scores(dists, param_save, difference,c)
    return library, weights, stats, KK
#####################################

def do_sampling(N_SAM,PARAMS,NUMBER_SIMS):
    for i in range(N_SAM):
        param_save, Obs_Sim = run_sim(PARAMS, NUMBER_SIMS)
        library, weights, stats, KK     = sum_stats(Obs_Sim, param_save, NUMBER_SIMS)
        result_SAM[i,:]=do_regression_manual(library, weights, stats)
    parameter_estimate = np.average(result_SAM, axis=0)
    HPDR=pymc3.stats.hpd(result_SAM)
    print("Estimates from regression abc-manual computation:", parameter_estimate)
    print("Estimated highest probability density region is:", HPDR)
# do_probability_desity_plot(result_SAM, HPDR)
    #print("True parameter values:", PARAMS["g_J"], PARAMS["g_Y"],PARAMS["Topt"], PARAMS["width"], PARAMS["kopt"], PARAMS["d_A"], PARAMS["m_J"], PARAMS["m_Y"], PARAMS["m_A"])
    return parameter_estimate, HPDR
#############################################################################
def actual_params(PARAMS):
    PARAMS["g_J"]   = np.random.uniform(0,1)#np.random.normal(0.4,0.3) #np.random.beta(2,2)
    PARAMS["g_Y"]    =np.random.uniform(0,1) #np.random.uniform(0,1)#np.random.beta(2,2)
    PARAMS["Topt"]  =np.random.uniform(5,9)#np.random.normal(6.5,2) #np.random.uniform(1,12) #np.random.lognormal(1,1)
    PARAMS["width"]  =np.random.uniform(1,4)#np.random.normal(2,1)
    ##np.random.lognormal(1,1)
    PARAMS["kopt"]     =np.random.uniform(0,1)#np.random.normal(0.5,0.4)# np.random.u(0,1)
    PARAMS["d_A"]     =np.random.uniform(0,0.5)#np.random.normal(0.1,0.09) #np.random.normal(0,1)#np.random.normal(0,0.5)
    PARAMS["m_J"]     =np.random.uniform(0,1)#np.random.normal(0.04,0.04) # #np.random.beta(2,2)
    PARAMS["m_Y"]   =np.random.uniform(0,1)#np.random.normal(0.05,0.04) #np.random.uniform(0,1) #np.random.beta(2,2)
    PARAMS["m_A"]   =np.random.uniform(0,1)#np.random.normal(0.05,0.05)# np.random.uniform(0,1)#np.random.beta(2,2)
    PARAMS["delta_t"]   =np.random.uniform(0,4)
    return PARAMS

##############################################################################
def do_BiasBoxplot(results):
    fig= plt.figure(1, figsize=(9, 6))
# Create an axes instance
    ax = fig.add_subplot(111)
# Create the boxplot
    bp = ax.boxplot(results, showfliers=0)
    plt.rc('ytick',labelsize=18)
    ## add patch_artist=True option to ax.boxplot()
    ## to get fill color
    bp = ax.boxplot(results, patch_artist=True, showfliers=0)
    for box in bp['boxes']:
        # change outline color
        box.set( color='#7570b3', linewidth=2)
        # change fill color
        box.set( facecolor = '#1b9e77' )
    ## change color and linewidth of the whiskers
    for whisker in bp['whiskers']:
        whisker.set(color='#7570b3', linewidth=2)
## change color and linewidth of the caps
    for cap in bp['caps']:
        cap.set(color='#7570b3', linewidth=2)
    
    ## change color and linewidth of the medians
    for median in bp['medians']:
        median.set(color='#b2df8a', linewidth=2)

    ## change the style of fliers and their fill
    for flier in bp['fliers']:
        flier.set(marker='o', color='#e7298a', alpha=0.5)
    ax.set_xticklabels([r'$g_J$', r'$g_Y$', r'$T_{opt}$', r'$s$', r'$R_0$', r'$d_A$', r'$m_J$', r'$m_Y$', r'$m_A$'], fontsize=18)
    ax.get_xaxis().tick_bottom()
    ax.get_yaxis().tick_left()
    ax.tick_params(width = 2, direction = "out")
    for axis in ['top','bottom','left','right']:
        ax.spines[axis].set_linewidth(2)
    ax.set_ylabel('Bias in Parameter Estimation', fontsize=18)
    ax.set_xlabel('Parameters',fontsize=18)
    # Save the figure
    fig.savefig('figbiasspecies1_sept.png', bbox_inches='tight')


##################################################################
if __name__ == '__main__':
    # Sets parameters
    PARAMS = {"g_J": 0.4, "g_Y": 0.3, "Topt": 6, "width": 2, "kopt": 0.6,"d_A":0.1, "m_J": .04, "m_Y": .05, "m_A": .05, "delta_t": 2}
    #PARAMS = {"alpha0": 2, "T0": 1, "width": 1, "g_B": .3, "g_J": .4, "m_J": .05, "m_A": .05, "f_s": .9, "delta_t":.1, "lam":1}
    T_FINAL = 10
    #print(PARAMS["g_J"])
    #LANDSCAPE_LEN = 2
    N0 = 5
    NUMBER_SIMS = 2000


    
    rSize   = len(PARAMS)-1
    N_REPS  = 100#samples toto run and determine coverage probability
    N_SAM=100#sample to run for teh average. 100 implies we will compute 100 values for each param, and then determien teh average
    Param_MCMC=np.empty((N_SAM, rSize))
    resultsbias = np.empty((N_REPS, rSize))
    meansquare = np.empty((N_REPS, rSize))
    squar=np.empty((N_REPS, rSize))
    #resultsbias[:] = np.NaN
    coverage=np.empty((N_REPS, rSize))
    result_SAM=np.empty((N_SAM, rSize))
    #peforming MCMC-like simulation
    for i in range(N_REPS):
        param_actual=actual_params(PARAMS)
        actual=[param_actual["g_J"], param_actual["g_Y"], param_actual["Topt"], param_actual["width"], param_actual["kopt"],param_actual["d_A"], param_actual["m_J"], param_actual["m_Y"], param_actual["m_A"]]
        result, HPDR =do_sampling(N_SAM,param_actual,NUMBER_SIMS)
        for j in range(0,len(PARAMS)-1):
            if HPDR[j][0]<=actual[j]<=HPDR[j][1]:
                coverage[i,j]=1
            else:
                coverage[i,j]=0
        resultsbias[i,:] = (result - actual)/actual
    coverage_percen=(np.array(coverage).sum(axis=0)/N_REPS*100)
    meansquare=(np.array(np.square(resultsbias)).sum(axis=0))/N_REPS
    print("The Coverage probability is:", coverage_percen)
    print("The mean squared error is:", meansquare)
    do_BiasBoxplot(resultsbias)
