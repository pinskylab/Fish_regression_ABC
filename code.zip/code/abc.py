# this script simulates stage-structured population sizes in space and time for given parameters and forcin
# functions
from __future__ import print_function, division

import numpy as np
import math as math
import random as random
import sys
import copy as copy
from scipy.stats import norm
import statsmodels.api as sm
from scipy import stats
from numpy.linalg import inv
import pymc3
import scipy.stats as sst
from sklearn import preprocessing
#import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.kernel_ridge import KernelRidge
############################################################################################
######################


def temp_dependence(temperature, Topt, width, kopt):
    """ compute growth rate as a function of temperature, were kopt is the optimal growth rate, Topt, optimal temperature, width, the standard deviation from the optimal temperature.
        """
    #theta = -width*(temperature-Topt)*(temperature-Topt) + kopt
    theta = kopt*np.exp(-0.5*np.square((temperature-Topt)/width))
    #theta=((temperature-Tmin)*(temperature-Tmax))/(((temperature-Tmin)*(temperature-Tmax))-(temperature-Topt))
    return theta


def pop_dynamics(N_J, N_Y, N_A, params, alpha):
    """ Intake population sizes for the three population data structure
        for the parameter values; alph(parameter for beta distribution. With uniform priors, we do not need alph), alpha, the temperature dependent growth rate(output of the temp_dependence), fecudity is input separately. N_B is larvae, N_J is juvenille, and N_A is adults. [N_b(t+1)]=[birth]-[conversion to juvenile]. [N_J(t+1)]=[N_B becoming N_J]-[death]-[coversion to N_A]. [N_A(t+1)]=[fraction(f_s) from N_J and those that did not die that stays]-[fraction that leaves to another patch]
        """
    #recruits = beta_defs(alph,params["g_B"])
    #gJval = beta_defs(alph,params["g_J"])
    #nJ_coef = (1 - gJval - beta_defs(alph,params["m_J"]))
    
    nextN_J=(1-params["m_J"])*N_J-params["g_J"]*N_J
    nextN_Y=max(0,(1-params["m_Y"])*N_Y+params["g_J"]*N_J-params["g_Y"]*N_Y)
    nextN_A=max(0,(1-params["m_A"])*N_A+params["g_Y"]*N_Y)
    return nextN_J, nextN_Y, nextN_A


def movement(pop1,pop2,N_A1,N_A2,alpha1,alpha2, f_s, K):
    """ Takes population sizes in two patches, in which a fraction, f_s, of each stays and outputs
        the population sizes in each patch after movement """
    next_pop1 =max(0,pop1+(1-f_s)*N_A1*np.exp(alpha1*(1-N_A1/K))+ f_s*N_A2*np.exp(alpha2*(1-N_A2/K)))
    next_pop2 =max(0,pop2+(1-f_s)*N_A2*np.exp(alpha2*(1-N_A2/K))+ f_s*N_A1*np.exp(alpha1*(1-N_A1/K)))
    return next_pop1, next_pop2


def simulation_population(N_J0, N_Y0, N_A0, params, T_FINAL, temperatures):
    """ Takes in the initial population sizes and simulates the population size moving forward """
    # Set starting numbers for population and allocate space for population sizes
    N_J = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_J[0] = N_J0
    N_Y = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_Y[0] = N_Y0
    N_A = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_A[0] = N_A0
    
    for t in range(0,T_FINAL):
        alpha1 = temp_dependence(temperatures[t], params["Topt"], params["width"], params["kopt"])
        alpha2 = temp_dependence(temperatures[t] + params["delta_t"], params["Topt"], params["width"], params["kopt"])
        N_J1, N_Y[t+1][0], N_A[t+1][0] = pop_dynamics(N_J[t][0], N_Y[t][0], N_A[t][0], params, alpha1)
        N_J2, N_Y[t+1][1], N_A[t+1][1] = pop_dynamics(N_J[t][1], N_Y[t][1], N_A[t][1], params, alpha2)
        
        #N_A[t+1][0], N_A[t+1][1] = movement(N_A1,N_A2, params["f_s"])
        N_J[t+1][0], N_J[t+1][1] = movement(N_J1,N_J2,N_A[t][0],N_A[t][1],alpha1,alpha2, params["xi"], params["K"])
    
    return N_J, N_Y, N_A



def calculate_summary_stats(N_J, N_Y, N_A, T_FINAL):
    """Takes in a matrix of time x place population sizes for each stage and calculates summary statistics"""
    time=range(T_FINAL)
    total_adult = N_A.sum(axis=1) # total population in each stage, summed over space
    total_young = N_Y.sum(axis=1)
    total_juv   = N_J.sum(axis=1)
    #lquartile_adult=np.percentile(total_adult, 25)
    L_Q1=np.percentile(time, 5, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    L_Q=np.percentile(time, 25, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    M_Q=np.percentile(time, 50, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    U_Q=np.percentile(time, 75, axis=None, out=None, overwrite_input=False, interpolation='nearest')
    #print('time:', time)
    #print('LQ:', L_Q, ' MQ:', M_Q, ' UQ:', U_Q)
    lquartile_adult=total_adult[L_Q]#np.percentile(total_adult, 25)
    median_adult=total_adult[M_Q]#np.percentile(total_adult, 50)
    uquartile_adult=total_adult[U_Q]#np.percentile(total_adult, 75)
    mean_adult=np.mean(total_adult)
    std_adult=np.std(total_adult)
    lquartile_young=total_young[L_Q]#np.percentile(total_juv, 25)
    median_young=total_young[M_Q]#np.percentile(total_juv, 50)
    uquartile_young=total_young[U_Q]#np.percentile(total_juv, 75)
    mean_young=np.mean(total_young)
    std_young=np.std(total_young)
    lquartile_juv=total_juv[L_Q]#np.percentile(total_larv, 25)
    median_juv=total_juv[M_Q]#np.percentile(total_larv, 50)
    uquartile_juv=total_juv[U_Q]#np.percentile(total_larv, 75)
    mean_juv=np.mean(total_juv)
    std_juv=np.std(total_juv)
    #print('total_adult:', total_adult)
    #print('N_A:', N_A)
    SS_adult=np.hstack((lquartile_adult, median_adult, uquartile_adult))
    SS_young=np.hstack((lquartile_young, median_young, uquartile_young))
    SS_juv=np.hstack((lquartile_juv, median_juv, uquartile_juv))
    SS_adult1=np.hstack((N_A[L_Q1], N_A[L_Q], N_A[M_Q], N_A[U_Q]))
    SS_young1=np.hstack((N_Y[L_Q1], N_Y[L_Q], N_Y[M_Q], N_Y[U_Q]))
    SS_juv1=np.hstack((N_J[L_Q1], N_J[L_Q], N_J[M_Q], N_J[U_Q]))
    #total_population = total_adult + total_juv + total_larv # total population size in each time
    #print(total_adult)
    # print(lquartile_adult)
    #print(SS_adult)
    #print(mean_adult)
    #sys.exit()
    return SS_adult1, SS_young1, SS_juv1

def euclidean_distance(vec1, vec2):
    """ Takes two vectors of the same dimensions and calculates the Euclidean distance between the elements"""
    return np.linalg.norm(vec1 - vec2, ord=2)


def small_percent(vector, percent):
    """ Takes a vector and returns the indexes of the elements within the smallest (percent) percent of the vector"""
    sorted_vector = sorted(vector)
    cutoff = math.floor(len(vector)*percent/100) # finds the value which (percent) percent are below
    indexes = []
    print('cutoff:',cutoff)
    cutoff = int(cutoff)
    for i in range(0,len(vector)):
        if vector[i] < sorted_vector[cutoff]: # looks for values below the found cutoff
            indexes.append(i)

    return indexes, sorted_vector[cutoff]


def z_score(x):
    """Takes a list and returns a 0 centered, std = 1 scaled version of the list"""
    st_dev = np.std(x,axis=0)
    mu = np.mean(x,axis=0)
    rescaled_values = []
    for element in range(0,len(x)):
        rescaled_values[element] = (x[element] - mu) / st_dev

    return rescaled_values

############################
# this function transform the paramters using logit function. the aim is to ensure that we do not end up with a parameter out of the prior
def do_logit_transformation(library, param_bound):
    for i in range(len(library[0,:])):
        library[:,i]=(library[:,i]-param_bound[i,0])/(param_bound[i,1]-param_bound[i,0])
        library[:,i]=np.log(library[:,i]/(1-library[:,i]))
    return library
###########################
#this function back transform parameter values
def do_ivlogit_transformation(para_reg, param_bound):
    for i in range(len(library[0,:])):
        para_reg[:,i]=np.exp(para_reg[:,i])/(1+np.exp(para_reg[:,i]))
        para_reg[:,i]=para_reg[:,i]*(param_bound[i,1]-param_bound[i,0])+param_bound[i,0]
    return para_reg
############################

def do_kernel_ridge(stats, library, param_bound):
    #print('X:', X.shape)
    #print('Y:', Y.shape)
    #'rbf'
    X = sm.add_constant(stats)
    Y=library
    clf     = KernelRidge(alpha=1.0, kernel='rbf', coef0=1)
    resul   = clf.fit(X, Y)
    resul_coef=np.dot(X.transpose(), resul.dual_coef_)
    coefficients =resul_coef[1:]
    #mean_conf=confidence_interval_Kridge(logit(library), weights, stats,resul_coef)
    para_reg   =Y- stats.dot(coefficients)
    para_reg=do_ivlogit_transformation(para_reg, param_bound)
    #param_SS[:,ii]   =Y[:,ii]- inv_logit(res_wls_SS.params[1:])+inv_logit(res_wls_OS.params[1:])
    parameter_estimate = np.average(para_reg, axis=0)
    HPDR=pymc3.stats.hpd(para_reg)
    return parameter_estimate, HPDR
    #NMSE_ridreg=1-(((np.linalg.norm(actual-coefficients , ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    #print('Estimates from regression abc using Kernel ridge regression is :', parameter_estimate)
#print('Estimates HPDR using Kernel ridge regression is :', HPDR)
# print('NMSE for kernel Ridge regression  is :', NMSE_ridreg)
    #print('coefficients:', coefficients)

def do_rejection(library):
    parameter_estimate = np.average(library, axis=0)
    HPDR=pymc3.stats.hpd(library)
    return parameter_estimate, HPDR
    # print('library is:', library)
    #print('Estimates from rejection is:', parameter_estimate)
#print('Estimates HPDR from rejection is :', HPDR)


def do_regression_online(library, weights, stats, param_bound):
    X = sm.add_constant(stats)
    # try to assemble Y as a vector of vectors? Is this correct?
    Y = np.array(library)

    weigh=np.diag(weights)
    AA=np.transpose([np.linalg.pinv(weigh[:,i,None] * X).dot(Y[:,i]) for i in range(8)])
    coefficients =AA[1:]
    #mean_conf=confidence_interval_Kridge(logit(library), weights, stats,resul_coef)
    para_reg   =Y- stats.dot(coefficients)
    para_reg=do_ivlogit_transformation(para_reg)
    #param_SS[:,ii]   =Y[:,ii]- inv_logit(res_wls_SS.params[1:])+inv_logit(res_wls_OS.params[1:])
    parameter_estimate = np.average(para_reg, axis=0)
    HPDR=pymc3.stats.hpd(para_reg)
    #NMSE_ridreg=1-(((np.linalg.norm(actual-coefficients , ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print('Estimates from regression online :', parameter_estimate)
    print('Estimates HPDR using online regression is :', HPDR)
    # print('NMSE for kernel Ridge regression  is :', NMSE_ridreg)
    #print('coefficients:', coefficients)
    

def do_regression_manual(library, weights, stats, param_bound):
    weights='rbf'
    X = sm.add_constant(stats)
    Y = np.array(library)
    X_T=np.transpose(X)
    inv_X=inv(np.mat(X_T)*np.mat(np.diag(np.array(weights)))*np.mat(X))
    resultmanual=inv_X*(X_T*np.mat(np.diag(np.array(weights)))*Y)
    results=resultmanual[1:]
    para_reg   =Y- stats.dot(results)
    para_reg=do_ivlogit_transformation(para_reg, param_bound)
    #param_SS[:,ii]   =Y[:,ii]- inv_logit(res_wls_SS.params[1:])+inv_logit(res_wls_OS.params[1:])
    parameter_estimate = np.average(para_reg, axis=0)
    HPDR=pymc3.stats.hpd(para_reg)
    #NMSE_ridreg=1-(((np.linalg.norm(actual-coefficients , ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print('Estimates from regression abc using manual regression is :', parameter_estimate)
    print('Estimates HPDR using manual regression is :', HPDR)
    
    


def do_local_linear(stats, library, weights,stats_SS, param_bound):
    n=len(library[0,:])
    m=len(library[:,0])
    Y = np.array(library)
    
    #QQ = np.ones(n)
    X= sm.add_constant(stats, has_constant='add')
    X_SS=sm.add_constant(stats_SS, has_constant='add')
    #X_OS=sm.add_constant(Obs_SS, has_constant='add')
    # print(X.shape)
    # print(X_SS.shape)
    #print(stats_SS.shape)
    # print(stats_SS.shape)
    # print(Obs_SS.shape)
    
    # XXX = np.mean(stats, axis=1)
    #Xtrial=sm.add_constant(XXX)
    param=np.empty((m, n))
    param_SS=np.empty((m, n))

    for ii in range(0,n):
        #theta_ij,i=0:10, j=0:n. for each parameter and do a regression. and there are n parameters. We are using a differnet regression equation for each parameter
         y = Y[:,ii]
         #mod_wls  = sm.WLS(y, Xtrial, weights=np.array(weights)**2/np.array(weights).sum()**2)
         mod_wls = sm.WLS(y, X)
         #mod_wls_SS = sm.WLS(y, X_SS, weights**2)
         #mod_wls_OS = sm.WLS(y, X_OS, weights**2)
         #print(weights)
         res_wls  = mod_wls.fit()
         #res_wls_SS  = mod_wls_SS.fit()
         #res_wls_OS  = mod_wls_OS.fit()
         #res_wls1 = mod_wls1.fit()

         #con_in   = res_wls.conf_int()
         #con_in1   = res_wls1.conf_int()
         #con_int[ii, :] =con_in[0]
         #con_int1[ii, :] =con_in1[0]
         param[:,ii]   =Y[:,ii]- stats.dot(res_wls.params[1:])
    # param_SS[:,ii]   =Y[:,ii]- res_wls_SS.params[1:]+res_wls_SS.params[0]
    param=do_ivlogit_transformation(param, param_bound)
#param_SS=do_ivlogit_transformation(param_SS, param_bound)
         #param_SS[:,ii]   =Y[:,ii]- inv_logit(res_wls_SS.params[1:])+inv_logit(res_wls_OS.params[1:])
    parameter_estimate = np.average(param, axis=0)
    HPDR=pymc3.stats.hpd(param)
    #parameter_estimate_SS = np.average(param_SS, axis=0)
    #HPDR_SS=pymc3.stats.hpd(param_SS)
#NMSE_ridreg=1-(((np.linalg.norm(actual-coefficients , ord=2))**2)/((np.linalg.norm(actual- np.mean(actual), ord=2))**2))
    print('Estimates from regression abc using S-SO regression is :', parameter_estimate)
    print('Estimates HPDR using S-OS regression is :', HPDR)
    #print('Estimates from regression abc using S regression is :', parameter_estimate_SS)
#print('Estimates HPDR using S regression is :', HPDR)
    #####################################################################################
#return all the observe summaery statitics (OS)and simulated summary statistics (SS) in a matrix with first row corresponding to OS and the rest of the rows to SS
def run_sim(PARAMS):
    PARAMS_ABC = copy.deepcopy(PARAMS) # copies parameters so new values can be generated; FIX ME! this is a redirect, not a copy?
    param_save = [] # sets an initial 0; fixed to [] because [[]] made the mean go poorly (averaging in an [] at start?)
    #print_parameters(PARAMS, prefix='True')
    # Sets temperatures at each patch over time [FIX THIS]
    temperatures = np.linspace(0, 10,T_FINAL)
    #temperatures = [3.6,3.8,4,4.2,4.4,4.6,4.8,5,5.2,5.4]
    #temperatures = [0,1,2,3,4,5,6,7,8,9]
    # Simulates population
    N_J, N_Y, N_A = simulation_population(N0, N0, N0, PARAMS, T_FINAL, temperatures)
    SS_adult, SS_young, SS_juv= calculate_summary_stats(N_J, N_Y, N_A, T_FINAL)
    SO=np.hstack((SS_adult, SS_young, SS_juv))
    Obs_Sim=np.zeros((NUMBER_SIMS+1,len(SO)))
    Obs_Sim[0,:]=SO
    for i in range(0,NUMBER_SIMS):
        g_J_theta    = np.random.uniform(0,1)#np.random.normal(0.4,0.3) #np.random.beta(2,2)
        g_Y_theta    =np.random.uniform(0,1) #np.random.uniform(0,1)#np.random.beta(2,2)
        Topt_theta =np.random.uniform(3,6)#np.random.normal(6.5,2) #np.random.uniform(1,12) #np.random.lognormal(1,1)
        width_theta  =np.random.uniform(1,4)#np.random.normal(2,1)
        ##np.random.lognormal(1,1)
        kopt_theta    =np.random.uniform(0,1)#np.random.normal(0.5,0.4)# np.random.u(0,1)
        xi_theta     =np.random.uniform(0,0.5)#np.random.normal(0.1,0.09) #np.random.normal(0,1)#np.random.normal(0,0.5)
        m_J_theta    =np.random.uniform(0,1)#np.random.normal(0.04,0.04) # #np.random.beta(2,2)
        m_Y_theta    =np.random.uniform(0,1)#np.random.normal(0.05,0.04) #np.random.uniform(0,1) #np.random.beta(2,2)
        m_A_theta    =np.random.uniform(0,1)#np.random.normal(0.05,0.05)# np.random.uniform(0,1)#np.random.beta(2,2)
        
        PARAMS_ABC["g_J"]    = g_J_theta # sets the g_J parameter to our random guess
        PARAMS_ABC["g_Y"]    = g_Y_theta
        PARAMS_ABC["Topt"] = Topt_theta
        PARAMS_ABC["width"]  = width_theta
        PARAMS_ABC["kopt"]    = kopt_theta
        PARAMS_ABC["xi"]     = xi_theta
        PARAMS_ABC["m_J"]    = m_J_theta
        PARAMS_ABC["m_Y"]    = m_Y_theta
        PARAMS_ABC["m_A"]    = m_A_theta
        
    
        # Simulate population for new parameters
        N_J_sim, N_Y_sim, N_A_sim = simulation_population(N0,N0,N0, PARAMS_ABC, T_FINAL, temperatures) # simulates population with g_J value
        
        # Calculate the summary statistics for the simulation
        Sim_SS_adult, Sim_SS_young, Sim_SS_juv= calculate_summary_stats(N_J_sim, N_Y_sim, N_A_sim, T_FINAL)
        SS=np.hstack((Sim_SS_adult, Sim_SS_young, Sim_SS_juv))
        Obs_Sim[i+1,:]=SS
        
        param_save.append([g_J_theta, g_Y_theta, Topt_theta, width_theta, kopt_theta, xi_theta, m_J_theta,m_Y_theta, m_A_theta])
    
    return np.asarray(param_save), Obs_Sim

#########################################################################################
#return all  all parameters (library) and simulated  NSS (stats) corresponding to d ≤ δ(eps).
def compute_scores(dists, param_save, difference,Sim_SS):
    eps=0.01
    library_index, NSS_cutoff = small_percent(dists, eps)
    n                = len(library_index)
    library = np.empty((n, param_save.shape[1]))
    stats            = np.empty((n, difference.shape[1]))
    stats_SS            = np.empty((n, difference.shape[1]))
    

    for i in range(0,len(library_index)):
        j = library_index[i]
        library[i] = param_save[j]
        stats[i]   = difference[j]
        stats_SS[i]   = Sim_SS[j]
    return library, stats, NSS_cutoff, library_index, stats_SS
##########################################################################################
#computes weights for local regression

def compute_weight(kernel,t, eps, index):
     weights=np.empty(len(index))
     if (kernel == "epanechnikov"):
         for i in range(0,len(library_index)):
             j = library_index[i]
     #weights[i]= (1. - (t[j] / eps)**2)
             weights[i]=(1. - (t[j] / eps)**2)
     elif(kernel == "rectangular"):
          for i in range(0,len(library_index)):
              j = library_index[i]
              weights[i]=t[j] / eps
     elif (kernel == "gaussian"):
          for i in range(0,len(library_index)):
              j = library_index[i]
              weights[i]= 1/np.sqrt(2*np.pi)*np.exp(-0.5*(t[j]/(eps/2))**2)
            
     elif (kernel == "triangular"):
          for i in range(0,len(library_index)):
              j = library_index[i]
              weights[i]= 1 - np.abs(t[j]/eps)
     elif (kernel == "biweight"):
          for i in range(0,len(library_index)):
              j = library_index[i]
              weights[i]=(1 - (t[j]/eps)**2)**2
     else:
          for i in range(0,len(library_index)):
              j = library_index[i]
              weights[i]= np.cos(np.pi/2*t[j]/eps)
     return weights
############################################################################################
def actual_params(PARAMS):
    PARAMS["g_J"]   = np.random.uniform(0,1)#np.random.normal(0.4,0.3) #np.random.beta(2,2)
    PARAMS["g_Y"]    =np.random.uniform(0,1) #np.random.uniform(0,1)#np.random.beta(2,2)
    PARAMS["Topt"]  =np.random.uniform(3,6)#np.random.normal(6.5,2) #np.random.uniform(1,12) #np.random.lognormal(1,1)
    PARAMS["width"]  =np.random.uniform(1,4)#np.random.normal(2,1)
    ##np.random.lognormal(1,1)
    PARAMS["kopt"]     =np.random.uniform(0,1)#np.random.normal(0.5,0.4)# np.random.u(0,1)
    PARAMS["xi"]     =np.random.uniform(0,0.5)#np.random.normal(0.1,0.09) #np.random.normal(0,1)#np.random.normal(0,0.5)
    PARAMS["m_J"]     =np.random.uniform(0,1)#np.random.normal(0.04,0.04) # #np.random.beta(2,2)
    PARAMS["m_Y"]   =np.random.uniform(0,1)#np.random.normal(0.05,0.04) #np.random.uniform(0,1) #np.random.beta(2,2)
    PARAMS["m_A"]   =np.random.uniform(0,1)#np.random.normal(0.05,0.05)# np.random.uniform(0,1)#np.random.beta(2,2)
    PARAMS["delta_t"]   =0.1
    PARAMS["K"]   =100
    return PARAMS
##########################################################################################


def sum_stats(Obs_Sim, param_save, NUMBER_SIMS):
    dists = np.zeros((NUMBER_SIMS,1))
    #Obs_Sim_scale=np.nan_to_num(sst.zscore(Obs_Sim, axis=0,ddof=1),copy=True)
    Obs_Sim_scale=np.nan_to_num(preprocessing.normalize(Obs_Sim, axis=0),copy=True)
    #Substract each row of teh array from row 1
    Sim_SS=Obs_Sim_scale[1:NUMBER_SIMS+1,: ]
    Obs_SS=Obs_Sim_scale[0,:]
    difference=Obs_Sim_scale[1:NUMBER_SIMS+1,: ]-Obs_Sim_scale[0,:]
    #c=np.std(Obs_Sim_scale[1:NUMBER_SIMS+1,: ], axis=1)
    # compute the norm 2 of each row
    dists = np.linalg.norm(difference, axis=1)

    library, stats, NSS_cutoff, library_index, stats_SS = compute_scores(dists, param_save, difference,Sim_SS)
    # print(library)
    return library, dists, stats,stats_SS,   NSS_cutoff, library_index
###################################################################################################

def do_regression(library, stats, PARAMS):

    # REJECTION
    print('\nDo a rejection ABC:')
    do_rejection(library, PARAMS)
    do_local_linear(stats, library, weights,KK)
    #print('\nStats:', stats.shape)
    #print('\nStats:', stats)
    #print('\nLibar:', library.shape)
    #print('\nLibar:', library)

    do_kernel_ridge(stats, library)
    do_ridge(stats, library)
##################################################################################################
def do_goodness_fit(result,HPDR, actual, n, i):
    for j in range(0,n):
        if HPDR[j][0]<=actual[j]<=HPDR[j][1]:
           coverage[i,j]=1
        else:
           coverage[i,j]=0
    resultsbias[i,:] = (result - actual)/actual
    return coverage,resultsbias

#############################################################################################

if __name__ == '__main__':
    ############################################################################################
    # exact parameter values
    PARAMS = {"g_J": 0.4, "g_Y": 0.3, "Topt": 5, "width": 2, "kopt": 0.6,"xi":0.1, "m_J": .05, "m_Y": .05, "m_A": .05, "delta_t": 0.1, "K":100}
    #final time
    param_bound=np.array([[0,1],[0,1],[3,6],[1,4],[0,1],[0,0.5],[0,1],[0,1],[0,1]])
    T_FINAL = 30
    no_patches=10
   
    #number of patches
    #initial abundance in each patch and for each stage
    N0 = 20
    #Number of iteration
    rSize   = len(PARAMS)-2
    NUMBER_SIMS = 200000
    N_Species  = 100
    resultsbias = np.empty((N_Species, rSize))
    coverage=np.empty((N_Species, rSize))
    for i in range(N_Species ):
        param_actual=actual_params(PARAMS)
        print(param_actual)
        actual=[param_actual["g_J"], param_actual["g_Y"], param_actual["Topt"], param_actual["width"], param_actual["kopt"],param_actual["xi"], param_actual["m_J"], param_actual["m_Y"], param_actual["m_A"]]
    #############################################################################
    #simulating summary statistics and retaining a matrix with first row observed summar (OS) statistics and the remaining rows simulated summary (SS) statistics for NUMBER_SIMS iterations.It equally retain the simulated parameters. i'e retain all (theta_i, S_i) for i=0:NUMBER_SIMS.  theta_i and s_i from the joint distribution.
        param_save, Obs_Sim         = run_sim(param_actual)
    ######################################################################################################
#normalize the rows of Obs_sim to have NOS in row 1 and NSS in the remaining rows. Substract rows i=2:NUMBER_SIMS from row 1 of Obs_sim (whic contain OS).Compute the eucleadean distance (d) between NSS and NOS then use it along side tolerance (δ), to determine all parameters and NSS corresponding to d ≤ δ.Choose δ such that δ × 100% of the NUMBER_SIMS simulated parameters and NSS are selected. retain the parameters that made this threshold (library), the weights ot be used in local linear regression and the NSS that meets the threshold (stats)
        library, dists, stats,stats_SS,  NSS_cutoff, library_index   = sum_stats(Obs_Sim, param_save, NUMBER_SIMS)
        result_rej, HPDR_rej =do_rejection(library)
        library_reg=do_logit_transformation(library, param_bound)
        result_reg, HPDR_reg=do_kernel_ridge(stats, library_reg, param_bound)
        coverage_rej,resultsbias_rej=do_goodness_fit(result_rej,HPDR_rej, actual, len(PARAMS)-2, i)
        coverage_reg,resultsbias_reg=do_goodness_fit(result_reg,HPDR_reg, actual, len(PARAMS)-2, i)
        coverage_rej_percen=(np.array(coverage_rej).sum(axis=0)/N_Species*100)
        coverage_reg_percen=(np.array(coverage_reg).sum(axis=0)/N_Species*100)
    print("The Coverage probabilityfrom rejection  is:", coverage_rej_percen)
    print("The Coverage probabilityfrom regression  is:", coverage_reg_percen)
    import plot
    box_plot_rej=plot.do_BiasBoxplot(resultsbias_rej)
    box_plot_rej.savefig('box_plot_rej.png', bbox_inches='tight')
    box_plot_reg=plot.do_BiasBoxplot(resultsbias_reg)
    box_plot_reg.savefig('box_plot_reg.png', bbox_inches='tight')
    #print(library)
    #print(np.average(library, axis=0))
    #print(pymc3.stats.hpd(library))
    ################################################################################################
    ###library_reg=do_logit_transformation(library, param_bound)
    
    #please include a function for weights here.
    #kernel, can be "epanechnikov",  "rectangular", "gaussian", "triangular", "biweight", "cosine"
    ###weights=compute_weight("epanechnikov",dists, NSS_cutoff, library_index)
    #######################################
#m, h1=do_rejection(library, PARAMS)
###print("True parameter values:", PARAMS["g_J"], PARAMS["g_Y"],PARAMS["Topt"], PARAMS["width"], PARAMS["kopt"], PARAMS["xi"], PARAMS["m_J"], PARAMS["m_Y"], PARAMS["m_A"])
    # parameter_estimate,HPDR=do_local_linear(stats, library, weights,stats_SS, Obs_SS)
    #print(library_reg)
#results,h=do_regression_manual(library, weights, stats)
# do_kernel_ridge(stats, library_reg,weights, param_bound)

#do_local_linear(stats, library_reg, weights,stats_SS, param_bound)
#do_regression_manual(library, weights, stats, param_bound)

