# this script simulates stage-structured population sizes in space and time for given parameters and forcin
# functions
import numpy as np

import sys
import pandas as pd
#import matplotlib.pyplot as plt
import matplotlib.pyplot as plt



####################################################################

def temp_dependence(temperature, Topt, width, kopt):
    """ compute growth rate as a function of temperature, were kopt is the optimal growth rate, Topt, optimal temperature, width, the standard deviation from the optimal temperature.
        """
    #theta = -width*(temperature-Topt)*(temperature-Topt) + kopt
    theta = kopt*np.exp(-0.5*np.square((temperature-Topt)/width))
    #theta=((temperature-Tmin)*(temperature-Tmax))/(((temperature-Tmin)*(temperature-Tmax))-(temperature-Topt))
    return theta


def pop_dynamics(N_J, N_Y, N_A, params, alpha):
    """ Intake population sizes for the three population data structure
        for the parameter values; alph(parameter for beta distribution. With uniform priors, we do not need alph), alpha, the temperature dependent growth rate(output of the temp_dependence), fecudity is input separately. N_B is larvae, N_J is juvenille, and N_A is adults. [N_b(t+1)]=[birth]-[conversion to juvenile]. [N_J(t+1)]=[N_B becoming N_J]-[death]-[coversion to N_A]. [N_A(t+1)]=[fraction(f_s) from N_J and those that did not die that stays]-[fraction that leaves to another patch]
    """
    #recruits = beta_defs(alph,params["g_B"])
    #gJval = beta_defs(alph,params["g_J"])
    #nJ_coef = (1 - gJval - beta_defs(alph,params["m_J"]))
    L_bJ=params["L_inf"]-(params["L_inf"]-params["L_J"])*np.exp(alpha)
    L_bY=params["L_inf"]-(params["L_inf"]-params["L_Y"])*np.exp(alpha)
    g_J=(params["L_J"]-L_bJ)/(params["L_J"]-params["L_0"])
    g_Y=(params["L_Y"]-L_bY)/(params["L_Y"]-params["L_J"])
    nextN_J=np.random.poisson(lam=max(0,N_J+params["r"]*N_A-g_J*N_J-params["m_J"]*N_J))
    nextN_Y=np.random.poisson(lam=max(0,N_Y+g_J*N_J-g_Y*N_Y-params["m_Y"]*N_Y))
    nextN_A=N_A+g_Y*N_Y-params["m_A"]*N_A
    return nextN_J, nextN_Y, nextN_A


def movement(pop1, pop2, N_A11, N_A12, f_s):
    """ Takes population sizes in two patches, in which a fraction, f_s, of each stays and outputs
        the population sizes in each patch after movement """
    next_pop1 =np.random.poisson(lam=max(0,pop1+f_s*(N_A12-N_A11)))
    next_pop2 =np.random.poisson(lam=max(0,pop2+f_s*(N_A11-N_A12)))
    
    return next_pop1, next_pop2

def simulation_population(N_J0, N_Y0, N_A0, params, T_FINAL, temperatures):
    """ Takes in the initial population sizes and simulates the population size moving forward """
    # Set starting numbers for population and allocate space for population sizes
    N_J = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_J[0] = N_J0
    N_Y = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_Y[0] = N_Y0
    N_A = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_A[0] = N_A0
    
    for t in range(0,T_FINAL):
        alpha1 = temp_dependence(temperatures[t], params["Topt"], params["width"], params["kopt"])
        alpha2 = temp_dependence(temperatures[t] + params["delta_t"], params["Topt"], params["width"], params["kopt"])
        
        N_J[t+1][0], N_Y[t+1][0], N_A1 = pop_dynamics(N_J[t][0], N_Y[t][0], N_A[t][0], params, alpha1)
        N_J[t+1][1], N_Y[t+1][1], N_A2 = pop_dynamics(N_J[t][1], N_Y[t][1], N_A[t][1], params, alpha2)
        
        N_A[t+1][0], N_A[t+1][1] = movement(N_A1,N_A2,N_A[t][0],N_A[t][1], params["xi"])
    
    return N_J, N_Y, N_A
        #[ 1.03263107 19.96321086  6.48787238  2.01984375  0.6417505   0.1439831
#0.28646419  0.04950342  0.04908494  0.05274505]

#[[ 0.69011816  1.38961694]
# [19.68944234 20.17913029]
#[ 6.35327963  6.62652322]
#[ 1.63088357  2.39646953]
#[ 0.49409055  0.77331812]
#[ 0.08268608  0.19668854]
#[ 0.18576476  0.39646504]
#[ 0.03248923  0.06059008]
#  [ 0.03429762  0.06500064]
#      [ 0.04195951  0.06919994]]
#July05
    #[ 1.06402926 19.98138475  6.48427334  2.00034996  0.65461781  0.14649388
#0.27604168  0.05076452  0.04931323  0.05404805]
#Estimated highest probability density region is: [[ 0.74086423  1.54555436]
#[19.73091646 20.29536518]
#[ 6.27183936  6.58344704]
# [ 1.58253993  2.45125329]
# [ 0.49440783  0.79536053]
# [ 0.0774596   0.19276257]
# [ 0.18481513  0.38714599]
# [ 0.03474082  0.06755558]
# [ 0.02822922  0.06164972]
#[ 0.0414099   0.07177836]]
#[ 1.09984182 19.98832107  6.5031215   2.03169404  0.63936771  0.14099061
# 0.28641003  0.05055422  0.04978082  0.05285009]
#Estimated highest probability density region is: [[ 0.7014861   1.44045231]
# [19.62303235 20.2354013 ]
# [ 6.38680282  6.63615638]
# [ 1.684186    2.48705642]
# [ 0.50991387  0.8015727 ]
# [ 0.08564919  0.19430034]
# [ 0.20404485  0.38662092]
# [ 0.03967348  0.0646247 ]
#[ 0.03948555  0.0652615 ]
# [ 0.03418267  0.06616083]]
#[ 1.0730431  19.96985411  6.50220821  1.99982902  0.64951188  0.14172961
# 0.27682299  0.05077767  0.04898334  0.05369266]
#Estimated highest probability density region is: [[ 0.69439618  1.49372004]
# [19.73068632 20.21862593]
#  [ 6.37826278  6.6212128 ]
#[ 1.58464058  2.45124621]
# [ 0.49655186  0.77567662]
# [ 0.08890053  0.20225728]
# [ 0.1982723   0.36301934]
# [ 0.04085255  0.06397965]
#[ 0.03077858  0.0642111 ]
#[ 0.03740848  0.06970474]]


if __name__ == '__main__':
    # Sets parameters
    
    PARAMS = {"L_0": 1, "L_inf": 20,"L_J": 5,"L_Y": 10, "Topt": 6.5, "width": 2, "kopt": 0.6,"xi":0.1,"r":0.3, "m_J": .04, "m_Y": .05, "m_A": .05, "delta_t": 2}
    PARAMS1 = {"L_0":1.03263107, "L_inf": 19.96321086,"L_J": 5,"L_Y": 10, "Topt": 6.48787238 , "width": 2.01984375, "kopt": 0.6417505 ,"xi":0.1439831,"r":0.28646419, "m_J":0.04950342, "m_Y": 0.04908494, "m_A": 0.05274505, "delta_t": 2}
    T_FINAL = 19
#print(PARAMS["g_J"])
#LANDSCAPE_LEN = 2
    N0 = 5
    temperatures = np.linspace(0, 13,T_FINAL)
    N_J, N_Y, N_A = simulation_population(N0, N0, N0, PARAMS, T_FINAL, temperatures)
    N_J1, N_Y1, N_A1 = simulation_population(N0, N0, N0, PARAMS1, T_FINAL, temperatures)
    #N_J1, N_Y1, N_A1 = simulation_population(N0, N0, N0, LB, T_FINAL, temperatures)
    #N_J2, N_Y2, N_A2 = simulation_population(N0, N0, N0, UB, T_FINAL, temperatures)
    
    
    
    ######################
    #######################
    #total_adult = N_A.sum(axis=1)[10:] # total population in each stage, summed over space
    #total_young = N_Y.sum(axis=1)[10:]
    #total_juv   = N_J.sum(axis=1)[10:]
    #total_adult1 = N_A1.sum(axis=1)[10:]  # total population in each stage, summed over space
    #total_young1 = N_Y1.sum(axis=1)[10:]
    #total_juv1   = N_J1.sum(axis=1)[10:]
    #total_adult2 = N_A2.sum(axis=1)[10:]  # total population in each stage, summed over space
    # total_young2 = N_Y2.sum(axis=1)[10:]
    #total_juv2   = N_J2.sum(axis=1)[10:]
    #############################
    ###############################
    #Obs_adult=pd.Series(total_adult,index=pd.Series(range(10,21)))
    Obs_adult1=pd.Series(N_A[:,0],index=pd.Series(range(1,21)))
    Obs_adult2=pd.Series(N_A[:,1],index=pd.Series(range(1,21)))
    Obs_young1=pd.Series(N_Y[:,0],index=pd.Series(range(1,21)))
    Obs_young2=pd.Series(N_Y[:,1],index=pd.Series(range(1,21)))
    Obs_juv1=pd.Series(N_J[:,0],index=pd.Series(range(1,21)))
    Obs_juv2=pd.Series(N_J[:,1],index=pd.Series(range(1,21)))
    pre_adult1=pd.Series(N_A1[:,0][10:],index=pd.Series(range(11,21)))
    pre_adult2=pd.Series(N_A1[:,1][10:],index=pd.Series(range(11,21)))
    pre_young1=pd.Series(N_Y1[:,0][10:],index=pd.Series(range(11,21)))
    pre_young2=pd.Series(N_Y1[:,1][10:],index=pd.Series(range(11,21)))
    pre_juv1=pd.Series(N_J1[:,0][10:],index=pd.Series(range(11,21)))
    pre_juv2=pd.Series(N_J1[:,1][10:],index=pd.Series(range(11,21)))
    
    #######################
    #####################
    fig, ax=plt.subplots()
    plt.plot(Obs_adult1.index, Obs_adult1, 'k', linewidth=2)
    plt.plot(pre_adult1.index, pre_adult1, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax.set_ylabel('Number of adults in patch 1', fontsize=18)
    ax.set_xlabel('Time (years)',fontsize=18)
    ax.tick_params(width = 2, direction = "out")
    fig.savefig('adult_patch1sp3.png')
    plt.close()
    ##############################
    fig1, ax1=plt.subplots()
    plt.plot(Obs_young1.index, Obs_young1, 'k', linewidth=2)
    plt.plot(pre_young1.index, pre_young1, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax1.set_ylabel('Number of large juveniles in patch 1', fontsize=18)
    ax1.set_xlabel('Time (years)',fontsize=18)
    ax1.tick_params(width = 2, direction = "out")
    fig1.savefig('young_patch1spe3.png')
    plt.close()
    ##########################
    ###########################
    fig2, ax2=plt.subplots()
    plt.plot(Obs_juv1.index, Obs_juv1, 'k', linewidth=2)
    plt.plot(pre_juv1.index, pre_juv1, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax2.set_ylabel('Number of juveniles in patch 1', fontsize=18)
    ax2.set_xlabel('Time (years)',fontsize=18)
    ax2.tick_params(width = 2, direction = "out")
    fig2.savefig('juv_patch1spe3.png')
    plt.close()
    #################################
    ####################################
    fig3, ax3=plt.subplots()
    plt.plot(Obs_adult2.index, Obs_adult2, 'k', linewidth=2)
    plt.plot(pre_adult2.index, pre_adult2, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax3.set_ylabel('Number of adults in patch 2', fontsize=18)
    ax3.set_xlabel('Time (years)',fontsize=18)
    ax3.tick_params(width = 2, direction = "out")
    fig3.savefig('adult_patch2sp3.png')
    plt.close()
    ##############################
    fig4, ax4=plt.subplots()
    plt.plot(Obs_young2.index, Obs_young2, 'k', linewidth=2)
    plt.plot(pre_young2.index, pre_young2, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax4.set_ylabel('Number of large juveniles in patch 2', fontsize=18)
    ax4.set_xlabel('Time (years)',fontsize=18)
    ax4.tick_params(width = 2, direction = "out")
    fig4.savefig('young_patch2spe3.png')
    plt.close()
    ##########################
    ###########################
    fig5, ax5=plt.subplots()
    plt.plot(Obs_juv2.index, Obs_juv2, 'k', linewidth=2)
    plt.plot(pre_juv2.index, pre_juv2, 'r', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax5.set_ylabel('Number of juveniles in patch 2', fontsize=18)
    ax5.set_xlabel('Time (years)',fontsize=18)
    ax5.tick_params(width = 2, direction = "out")
    fig5.savefig('juv_patch2spe3.png')
    plt.close()

