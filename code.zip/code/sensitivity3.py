# this script simulates stage-structured population sizes in space and time for given parameters and forcin
# functions
import numpy as np

import sys
import pandas as pd
#import matplotlib.pyplot as plt
import matplotlib.pyplot as plt



####################################################################

def temp_dependence(temperature, Topt, width, kopt):
    """ compute growth rate as a function of temperature, were kopt is the optimal growth rate, Topt, optimal temperature, width, the standard deviation from the optimal temperature.
        """
    #theta = -width*(temperature-Topt)*(temperature-Topt) + kopt
    theta = kopt*np.exp(-0.5*np.square((temperature-Topt)/width))
    #theta=((temperature-Tmin)*(temperature-Tmax))/(((temperature-Tmin)*(temperature-Tmax))-(temperature-Topt))
    return theta


def pop_dynamics(N_J, N_Y, N_A, params, alpha):
    """ Intake population sizes for the three population data structure
        for the parameter values; alph(parameter for beta distribution. With uniform priors, we do not need alph), alpha, the temperature dependent growth rate(output of the temp_dependence), fecudity is input separately. N_B is larvae, N_J is juvenille, and N_A is adults. [N_b(t+1)]=[birth]-[conversion to juvenile]. [N_J(t+1)]=[N_B becoming N_J]-[death]-[coversion to N_A]. [N_A(t+1)]=[fraction(f_s) from N_J and those that did not die that stays]-[fraction that leaves to another patch]
    """
    #recruits = beta_defs(alph,params["g_B"])
    #gJval = beta_defs(alph,params["g_J"])
    #nJ_coef = (1 - gJval - beta_defs(alph,params["m_J"]))
    L_bJ=params["L_inf"]-(params["L_inf"]-params["L_J"])*np.exp(alpha)
    L_bY=params["L_inf"]-(params["L_inf"]-params["L_Y"])*np.exp(alpha)
    g_J=(params["L_J"]-L_bJ)/(params["L_J"]-params["L_0"])
    g_Y=(params["L_Y"]-L_bY)/(params["L_Y"]-params["L_J"])
    nextN_J=np.random.poisson(lam=max(0,N_J+params["r"]*N_A-g_J*N_J-params["m_J"]*N_J))
    nextN_Y=np.random.poisson(lam=max(0,N_Y+g_J*N_J-g_Y*N_Y-params["m_Y"]*N_Y))
    nextN_A=N_A+g_Y*N_Y-params["m_A"]*N_A
    return nextN_J, nextN_Y, nextN_A


def movement(pop1, pop2, N_A11, N_A12, f_s):
    """ Takes population sizes in two patches, in which a fraction, f_s, of each stays and outputs
        the population sizes in each patch after movement """
    next_pop1 =np.random.poisson(lam=max(0,pop1+f_s*(N_A12-N_A11)))
    next_pop2 =np.random.poisson(lam=max(0,pop2+f_s*(N_A11-N_A12)))
    
    return next_pop1, next_pop2

def simulation_population(N_J0, N_Y0, N_A0, params, T_FINAL, temperatures):
    """ Takes in the initial population sizes and simulates the population size moving forward """
    # Set starting numbers for population and allocate space for population sizes
    N_J = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_J[0] = N_J0
    N_Y = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_Y[0] = N_Y0
    N_A = np.ndarray(shape=(T_FINAL+1, 2), dtype=float, order='F')
    N_A[0] = N_A0
    
    for t in range(0,T_FINAL):
        alpha1 = temp_dependence(temperatures[t], params["Topt"], params["width"], params["kopt"])
        alpha2 = temp_dependence(temperatures[t] + params["delta_t"], params["Topt"], params["width"], params["kopt"])
        
        N_J[t+1][0], N_Y[t+1][0], N_A1 = pop_dynamics(N_J[t][0], N_Y[t][0], N_A[t][0], params, alpha1)
        N_J[t+1][1], N_Y[t+1][1], N_A2 = pop_dynamics(N_J[t][1], N_Y[t][1], N_A[t][1], params, alpha2)
        
        N_A[t+1][0], N_A[t+1][1] = movement(N_A1,N_A2,N_A[t][0],N_A[t][1], params["xi"])
    
    return N_J, N_Y, N_A


if __name__ == '__main__':
    # Sets parameters
    percentchange=0.01
    PARAMS = {"L_0": 1, "L_inf": 20,"L_J": 5,"L_Y": 10, "Topt": 6.5, "width": 2, "kopt": 0.6,"xi":0.1,"r":0.3, "m_J": .04, "m_Y": .05, "m_A": .05, "delta_t": 2}
    PARAMS1 = {"L_0": 1, "L_inf": 20,"L_J": 5,"L_Y": 10, "Topt": 6.5, "width": 2, "kopt": 0.6,"xi":0.1,"r":0.3, "m_J": .04, "m_Y": .05, "m_A": .05*(1+percentchange), "delta_t": 2}
    PARAMS2 = {"L_0": 1, "L_inf": 20,"L_J": 5,"L_Y": 10, "Topt": 6.5, "width": 2, "kopt": 0.6,"xi":0.1,"r":0.3, "m_J": .04, "m_Y": .05, "m_A": .05*(1-percentchange), "delta_t": 2}
    
    T_FINAL = 19
    h=percentchange*PARAMS["m_A"]
#print(PARAMS["g_J"])
#LANDSCAPE_LEN = 2
    N0 = 5
    temperatures = np.linspace(0, 13,T_FINAL)
    N_J, N_Y, N_A = simulation_population(N0, N0, N0, PARAMS, T_FINAL, temperatures)
    N_J1, N_Y1, N_A1 = simulation_population(N0, N0, N0, PARAMS1, T_FINAL, temperatures)
    N_J2, N_Y2, N_A2 = simulation_population(N0, N0, N0, PARAMS2, T_FINAL, temperatures)
    
    #############################
    ###############################
    deriv_adult=(N_A1[12]-N_A2[12])/(2*h)
    deriv_young=(N_Y1[12]-N_Y2[12])/(2*h)
    deriv_juv=(N_J1[12]-N_J2[12])/(2*h)
    sens_adult=np.true_divide(deriv_adult*PARAMS["m_A"],(N_A[12]))
    sens_young=np.true_divide(deriv_young*PARAMS["m_A"],(N_Y[12]))
    sens_juv=np.true_divide(deriv_juv*PARAMS["m_A"],(N_J[12]))
    print("Sensitivty of adult:", sens_adult)
    print("Sensitivty of large juveniles:", sens_young)
    print("Sensitivty of juveniles:", sens_juv)
    pat1_adult=pd.Series(N_A[:,0],index=pd.Series(range(1,21)))
    pat1_adult1=pd.Series(N_A1[:,0],index=pd.Series(range(1,21)))
    pat1_adult2=pd.Series(N_A2[:,0],index=pd.Series(range(1,21)))
    pat1_young=pd.Series(N_Y[:,0],index=pd.Series(range(1,21)))
    pat1_young1=pd.Series(N_Y1[:,0],index=pd.Series(range(1,21)))
    pat1_young2=pd.Series(N_Y2[:,0],index=pd.Series(range(1,21)))
    pat1_juv=pd.Series(N_J[:,0],index=pd.Series(range(1,21)))
    pat1_juv1=pd.Series(N_J1[:,0],index=pd.Series(range(1,21)))
    pat1_juv2=pd.Series(N_J2[:,0],index=pd.Series(range(1,21)))
    pat2_adult=pd.Series(N_A[:,1],index=pd.Series(range(1,21)))
    pat2_adult1=pd.Series(N_A1[:,1],index=pd.Series(range(1,21)))
    pat2_adult2=pd.Series(N_A2[:,1],index=pd.Series(range(1,21)))
    pat2_young=pd.Series(N_Y[:,1],index=pd.Series(range(1,21)))
    pat2_young1=pd.Series(N_Y1[:,1],index=pd.Series(range(1,21)))
    pat2_young2=pd.Series(N_Y2[:,1],index=pd.Series(range(1,21)))
    pat2_juv=pd.Series(N_J[:,1],index=pd.Series(range(1,21)))
    pat2_juv1=pd.Series(N_J1[:,1],index=pd.Series(range(1,21)))
    pat2_juv2=pd.Series(N_J2[:,1],index=pd.Series(range(1,21)))
    ###########################
    ############################
    #######################
    #####################
    fig, ax=plt.subplots()
    plt.plot(pat1_adult.index, pat1_adult, 'k', linewidth=2)
    plt.plot(pat1_adult1.index, pat1_adult1, 'r', linewidth=2)
    plt.plot(pat1_adult2.index, pat1_adult2, 'g', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax.set_ylabel('Number of adults in patch 1', fontsize=18)
    ax.set_xlabel('Time (years)',fontsize=18)
    ax.tick_params(width = 2, direction = "out")
    fig.savefig('pat1_adult3.png')
    plt.close()
    ###############
    ###############
    ############
    fig1, ax1=plt.subplots()
    plt.plot(pat2_adult.index, pat2_adult, 'k', linewidth=2)
    plt.plot(pat2_adult1.index, pat2_adult1, 'r', linewidth=2)
    plt.plot(pat2_adult2.index, pat2_adult2, 'g', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax1.set_ylabel('Number of adults in patch 2', fontsize=18)
    ax1.set_xlabel('Time (years)',fontsize=18)
    ax1.tick_params(width = 2, direction = "out")
    fig1.savefig('pat2_adult3.png')
    plt.close()
    #########################
    #########################
    #####################
    fig2, ax2=plt.subplots()
    plt.plot(pat1_young.index, pat1_young, 'k', linewidth=2)
    plt.plot(pat1_young1.index, pat1_young1, 'r', linewidth=2)
    plt.plot(pat1_young2.index, pat1_young2, 'g', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax2.set_ylabel('Number of large juv in patch 1', fontsize=18)
    ax2.set_xlabel('Time (years)',fontsize=18)
    ax2.tick_params(width = 2, direction = "out")
    fig2.savefig('pat1_young3.png')
    plt.close()
    ###############
    ###############
    ############
    fig3, ax3=plt.subplots()
    plt.plot(pat2_young.index, pat2_young, 'k', linewidth=2)
    plt.plot(pat2_young1.index, pat2_young1, 'r', linewidth=2)
    plt.plot(pat2_young2.index, pat2_young2, 'g', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax3.set_ylabel('Number of adults in patch 2', fontsize=18)
    ax3.set_xlabel('Time (years)',fontsize=18)
    ax3.tick_params(width = 2, direction = "out")
    fig3.savefig('pat2_young3.png')
    plt.close()
    #####################
    #####################
    fig4, ax4=plt.subplots()
    plt.plot(pat1_juv.index, pat1_juv, 'k', linewidth=2)
    plt.plot(pat1_juv1.index, pat1_juv1, 'r', linewidth=2)
    plt.plot(pat1_juv2.index, pat1_juv2, 'g', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax4.set_ylabel('Number of large juv in patch 1', fontsize=18)
    ax4.set_xlabel('Time (years)',fontsize=18)
    ax4.tick_params(width = 2, direction = "out")
    fig4.savefig('pat1_juv3.png')
    plt.close()
    ###############
    ###############
    ############
    fig5, ax5=plt.subplots()
    plt.plot(pat2_juv.index, pat2_juv, 'k', linewidth=2)
    plt.plot(pat2_juv1.index, pat2_juv1, 'r', linewidth=2)
    plt.plot(pat2_juv2.index, pat2_juv2, 'g', linewidth=2)
    #plt.fill_between(pred_adult1.index, pred_adult1 , pred_adult2,color='b', alpha=0.2)
    ax5.set_ylabel('Number of juv in patch 2', fontsize=18)
    ax5.set_xlabel('Time (years)',fontsize=18)
    ax5.tick_params(width = 2, direction = "out")
    fig5.savefig('pat2_juv3.png')
    plt.close()

